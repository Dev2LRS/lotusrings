-- phpMyAdmin SQL Dump
-- version 2.11.11.3
-- http://www.phpmyadmin.net
--
-- Host: 118.139.179.94
-- Generation Time: Sep 12, 2013 at 11:42 AM
-- Server version: 5.0.96
-- PHP Version: 5.1.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `information_schema`
--
CREATE DATABASE `information_schema` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `information_schema`;

-- --------------------------------------------------------

--
-- Table structure for table `CHARACTER_SETS`
--

CREATE TEMPORARY TABLE `CHARACTER_SETS` (
  `CHARACTER_SET_NAME` varchar(64) NOT NULL default '',
  `DEFAULT_COLLATE_NAME` varchar(64) NOT NULL default '',
  `DESCRIPTION` varchar(60) NOT NULL default '',
  `MAXLEN` bigint(3) NOT NULL default '0'
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `CHARACTER_SETS`
--

INSERT INTO `CHARACTER_SETS` VALUES('big5', 'big5_chinese_ci', 'Big5 Traditional Chinese', 2);
INSERT INTO `CHARACTER_SETS` VALUES('dec8', 'dec8_swedish_ci', 'DEC West European', 1);
INSERT INTO `CHARACTER_SETS` VALUES('cp850', 'cp850_general_ci', 'DOS West European', 1);
INSERT INTO `CHARACTER_SETS` VALUES('hp8', 'hp8_english_ci', 'HP West European', 1);
INSERT INTO `CHARACTER_SETS` VALUES('koi8r', 'koi8r_general_ci', 'KOI8-R Relcom Russian', 1);
INSERT INTO `CHARACTER_SETS` VALUES('latin1', 'latin1_swedish_ci', 'cp1252 West European', 1);
INSERT INTO `CHARACTER_SETS` VALUES('latin2', 'latin2_general_ci', 'ISO 8859-2 Central European', 1);
INSERT INTO `CHARACTER_SETS` VALUES('swe7', 'swe7_swedish_ci', '7bit Swedish', 1);
INSERT INTO `CHARACTER_SETS` VALUES('ascii', 'ascii_general_ci', 'US ASCII', 1);
INSERT INTO `CHARACTER_SETS` VALUES('ujis', 'ujis_japanese_ci', 'EUC-JP Japanese', 3);
INSERT INTO `CHARACTER_SETS` VALUES('sjis', 'sjis_japanese_ci', 'Shift-JIS Japanese', 2);
INSERT INTO `CHARACTER_SETS` VALUES('hebrew', 'hebrew_general_ci', 'ISO 8859-8 Hebrew', 1);
INSERT INTO `CHARACTER_SETS` VALUES('tis620', 'tis620_thai_ci', 'TIS620 Thai', 1);
INSERT INTO `CHARACTER_SETS` VALUES('euckr', 'euckr_korean_ci', 'EUC-KR Korean', 2);
INSERT INTO `CHARACTER_SETS` VALUES('koi8u', 'koi8u_general_ci', 'KOI8-U Ukrainian', 1);
INSERT INTO `CHARACTER_SETS` VALUES('gb2312', 'gb2312_chinese_ci', 'GB2312 Simplified Chinese', 2);
INSERT INTO `CHARACTER_SETS` VALUES('greek', 'greek_general_ci', 'ISO 8859-7 Greek', 1);
INSERT INTO `CHARACTER_SETS` VALUES('cp1250', 'cp1250_general_ci', 'Windows Central European', 1);
INSERT INTO `CHARACTER_SETS` VALUES('gbk', 'gbk_chinese_ci', 'GBK Simplified Chinese', 2);
INSERT INTO `CHARACTER_SETS` VALUES('latin5', 'latin5_turkish_ci', 'ISO 8859-9 Turkish', 1);
INSERT INTO `CHARACTER_SETS` VALUES('armscii8', 'armscii8_general_ci', 'ARMSCII-8 Armenian', 1);
INSERT INTO `CHARACTER_SETS` VALUES('utf8', 'utf8_general_ci', 'UTF-8 Unicode', 3);
INSERT INTO `CHARACTER_SETS` VALUES('ucs2', 'ucs2_general_ci', 'UCS-2 Unicode', 2);
INSERT INTO `CHARACTER_SETS` VALUES('cp866', 'cp866_general_ci', 'DOS Russian', 1);
INSERT INTO `CHARACTER_SETS` VALUES('keybcs2', 'keybcs2_general_ci', 'DOS Kamenicky Czech-Slovak', 1);
INSERT INTO `CHARACTER_SETS` VALUES('macce', 'macce_general_ci', 'Mac Central European', 1);
INSERT INTO `CHARACTER_SETS` VALUES('macroman', 'macroman_general_ci', 'Mac West European', 1);
INSERT INTO `CHARACTER_SETS` VALUES('cp852', 'cp852_general_ci', 'DOS Central European', 1);
INSERT INTO `CHARACTER_SETS` VALUES('latin7', 'latin7_general_ci', 'ISO 8859-13 Baltic', 1);
INSERT INTO `CHARACTER_SETS` VALUES('cp1251', 'cp1251_general_ci', 'Windows Cyrillic', 1);
INSERT INTO `CHARACTER_SETS` VALUES('cp1256', 'cp1256_general_ci', 'Windows Arabic', 1);
INSERT INTO `CHARACTER_SETS` VALUES('cp1257', 'cp1257_general_ci', 'Windows Baltic', 1);
INSERT INTO `CHARACTER_SETS` VALUES('binary', 'binary', 'Binary pseudo charset', 1);
INSERT INTO `CHARACTER_SETS` VALUES('geostd8', 'geostd8_general_ci', 'GEOSTD8 Georgian', 1);
INSERT INTO `CHARACTER_SETS` VALUES('cp932', 'cp932_japanese_ci', 'SJIS for Windows Japanese', 2);
INSERT INTO `CHARACTER_SETS` VALUES('eucjpms', 'eucjpms_japanese_ci', 'UJIS for Windows Japanese', 3);

-- --------------------------------------------------------

--
-- Table structure for table `CLIENT_STATISTICS`
--

CREATE TEMPORARY TABLE `CLIENT_STATISTICS` (
  `CLIENT` varchar(64) NOT NULL default '',
  `TOTAL_CONNECTIONS` bigint(21) NOT NULL default '0',
  `CONCURRENT_CONNECTIONS` bigint(21) NOT NULL default '0',
  `CONNECTED_TIME` bigint(21) NOT NULL default '0',
  `BUSY_TIME` bigint(21) NOT NULL default '0',
  `CPU_TIME` bigint(21) NOT NULL default '0',
  `BYTES_RECEIVED` bigint(21) NOT NULL default '0',
  `BYTES_SENT` bigint(21) NOT NULL default '0',
  `BINLOG_BYTES_WRITTEN` bigint(21) NOT NULL default '0',
  `ROWS_FETCHED` bigint(21) NOT NULL default '0',
  `ROWS_UPDATED` bigint(21) NOT NULL default '0',
  `TABLE_ROWS_READ` bigint(21) NOT NULL default '0',
  `SELECT_COMMANDS` bigint(21) NOT NULL default '0',
  `UPDATE_COMMANDS` bigint(21) NOT NULL default '0',
  `OTHER_COMMANDS` bigint(21) NOT NULL default '0',
  `COMMIT_TRANSACTIONS` bigint(21) NOT NULL default '0',
  `ROLLBACK_TRANSACTIONS` bigint(21) NOT NULL default '0',
  `DENIED_CONNECTIONS` bigint(21) NOT NULL default '0',
  `LOST_CONNECTIONS` bigint(21) NOT NULL default '0',
  `ACCESS_DENIED` bigint(21) NOT NULL default '0',
  `EMPTY_QUERIES` bigint(21) NOT NULL default '0'
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `CLIENT_STATISTICS`
--

-- in use (#1227 - Access denied; you need the PROCESS,SUPER privilege for this operation)

-- --------------------------------------------------------

--
-- Table structure for table `COLLATIONS`
--

CREATE TEMPORARY TABLE `COLLATIONS` (
  `COLLATION_NAME` varchar(64) NOT NULL default '',
  `CHARACTER_SET_NAME` varchar(64) NOT NULL default '',
  `ID` bigint(11) NOT NULL default '0',
  `IS_DEFAULT` varchar(3) NOT NULL default '',
  `IS_COMPILED` varchar(3) NOT NULL default '',
  `SORTLEN` bigint(3) NOT NULL default '0'
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `COLLATIONS`
--

INSERT INTO `COLLATIONS` VALUES('big5_chinese_ci', 'big5', 1, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('big5_bin', 'big5', 84, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('dec8_swedish_ci', 'dec8', 3, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('dec8_bin', 'dec8', 69, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('cp850_general_ci', 'cp850', 4, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('cp850_bin', 'cp850', 80, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('hp8_english_ci', 'hp8', 6, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('hp8_bin', 'hp8', 72, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('koi8r_general_ci', 'koi8r', 7, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('koi8r_bin', 'koi8r', 74, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('latin1_german1_ci', 'latin1', 5, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('latin1_swedish_ci', 'latin1', 8, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('latin1_danish_ci', 'latin1', 15, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('latin1_german2_ci', 'latin1', 31, '', 'Yes', 2);
INSERT INTO `COLLATIONS` VALUES('latin1_bin', 'latin1', 47, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('latin1_general_ci', 'latin1', 48, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('latin1_general_cs', 'latin1', 49, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('latin1_spanish_ci', 'latin1', 94, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('latin2_czech_cs', 'latin2', 2, '', 'Yes', 4);
INSERT INTO `COLLATIONS` VALUES('latin2_general_ci', 'latin2', 9, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('latin2_hungarian_ci', 'latin2', 21, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('latin2_croatian_ci', 'latin2', 27, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('latin2_bin', 'latin2', 77, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('swe7_swedish_ci', 'swe7', 10, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('swe7_bin', 'swe7', 82, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('ascii_general_ci', 'ascii', 11, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('ascii_bin', 'ascii', 65, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('ujis_japanese_ci', 'ujis', 12, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('ujis_bin', 'ujis', 91, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('sjis_japanese_ci', 'sjis', 13, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('sjis_bin', 'sjis', 88, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('hebrew_general_ci', 'hebrew', 16, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('hebrew_bin', 'hebrew', 71, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('tis620_thai_ci', 'tis620', 18, 'Yes', 'Yes', 4);
INSERT INTO `COLLATIONS` VALUES('tis620_bin', 'tis620', 89, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('euckr_korean_ci', 'euckr', 19, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('euckr_bin', 'euckr', 85, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('koi8u_general_ci', 'koi8u', 22, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('koi8u_bin', 'koi8u', 75, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('gb2312_chinese_ci', 'gb2312', 24, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('gb2312_bin', 'gb2312', 86, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('greek_general_ci', 'greek', 25, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('greek_bin', 'greek', 70, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('cp1250_general_ci', 'cp1250', 26, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('cp1250_czech_cs', 'cp1250', 34, '', 'Yes', 2);
INSERT INTO `COLLATIONS` VALUES('cp1250_croatian_ci', 'cp1250', 44, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('cp1250_bin', 'cp1250', 66, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('gbk_chinese_ci', 'gbk', 28, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('gbk_bin', 'gbk', 87, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('latin5_turkish_ci', 'latin5', 30, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('latin5_bin', 'latin5', 78, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('armscii8_general_ci', 'armscii8', 32, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('armscii8_bin', 'armscii8', 64, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('utf8_general_ci', 'utf8', 33, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('utf8_bin', 'utf8', 83, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('utf8_unicode_ci', 'utf8', 192, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('utf8_icelandic_ci', 'utf8', 193, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('utf8_latvian_ci', 'utf8', 194, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('utf8_romanian_ci', 'utf8', 195, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('utf8_slovenian_ci', 'utf8', 196, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('utf8_polish_ci', 'utf8', 197, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('utf8_estonian_ci', 'utf8', 198, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('utf8_spanish_ci', 'utf8', 199, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('utf8_swedish_ci', 'utf8', 200, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('utf8_turkish_ci', 'utf8', 201, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('utf8_czech_ci', 'utf8', 202, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('utf8_danish_ci', 'utf8', 203, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('utf8_lithuanian_ci', 'utf8', 204, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('utf8_slovak_ci', 'utf8', 205, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('utf8_spanish2_ci', 'utf8', 206, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('utf8_roman_ci', 'utf8', 207, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('utf8_persian_ci', 'utf8', 208, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('utf8_esperanto_ci', 'utf8', 209, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('utf8_hungarian_ci', 'utf8', 210, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_general_ci', 'ucs2', 35, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('ucs2_bin', 'ucs2', 90, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('ucs2_unicode_ci', 'ucs2', 128, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_icelandic_ci', 'ucs2', 129, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_latvian_ci', 'ucs2', 130, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_romanian_ci', 'ucs2', 131, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_slovenian_ci', 'ucs2', 132, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_polish_ci', 'ucs2', 133, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_estonian_ci', 'ucs2', 134, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_spanish_ci', 'ucs2', 135, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_swedish_ci', 'ucs2', 136, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_turkish_ci', 'ucs2', 137, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_czech_ci', 'ucs2', 138, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_danish_ci', 'ucs2', 139, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_lithuanian_ci', 'ucs2', 140, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_slovak_ci', 'ucs2', 141, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_spanish2_ci', 'ucs2', 142, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_roman_ci', 'ucs2', 143, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_persian_ci', 'ucs2', 144, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_esperanto_ci', 'ucs2', 145, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_hungarian_ci', 'ucs2', 146, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('cp866_general_ci', 'cp866', 36, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('cp866_bin', 'cp866', 68, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('keybcs2_general_ci', 'keybcs2', 37, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('keybcs2_bin', 'keybcs2', 73, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('macce_general_ci', 'macce', 38, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('macce_bin', 'macce', 43, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('macroman_general_ci', 'macroman', 39, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('macroman_bin', 'macroman', 53, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('cp852_general_ci', 'cp852', 40, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('cp852_bin', 'cp852', 81, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('latin7_estonian_cs', 'latin7', 20, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('latin7_general_ci', 'latin7', 41, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('latin7_general_cs', 'latin7', 42, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('latin7_bin', 'latin7', 79, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('cp1251_bulgarian_ci', 'cp1251', 14, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('cp1251_ukrainian_ci', 'cp1251', 23, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('cp1251_bin', 'cp1251', 50, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('cp1251_general_ci', 'cp1251', 51, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('cp1251_general_cs', 'cp1251', 52, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('cp1256_general_ci', 'cp1256', 57, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('cp1256_bin', 'cp1256', 67, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('cp1257_lithuanian_ci', 'cp1257', 29, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('cp1257_bin', 'cp1257', 58, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('cp1257_general_ci', 'cp1257', 59, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('binary', 'binary', 63, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('geostd8_general_ci', 'geostd8', 92, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('geostd8_bin', 'geostd8', 93, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('cp932_japanese_ci', 'cp932', 95, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('cp932_bin', 'cp932', 96, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('eucjpms_japanese_ci', 'eucjpms', 97, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('eucjpms_bin', 'eucjpms', 98, '', 'Yes', 1);

-- --------------------------------------------------------

--
-- Table structure for table `COLLATION_CHARACTER_SET_APPLICABILITY`
--

CREATE TEMPORARY TABLE `COLLATION_CHARACTER_SET_APPLICABILITY` (
  `COLLATION_NAME` varchar(64) NOT NULL default '',
  `CHARACTER_SET_NAME` varchar(64) NOT NULL default ''
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `COLLATION_CHARACTER_SET_APPLICABILITY`
--

INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('big5_chinese_ci', 'big5');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('big5_bin', 'big5');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('dec8_swedish_ci', 'dec8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('dec8_bin', 'dec8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp850_general_ci', 'cp850');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp850_bin', 'cp850');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('hp8_english_ci', 'hp8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('hp8_bin', 'hp8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('koi8r_general_ci', 'koi8r');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('koi8r_bin', 'koi8r');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin1_german1_ci', 'latin1');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin1_swedish_ci', 'latin1');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin1_danish_ci', 'latin1');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin1_german2_ci', 'latin1');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin1_bin', 'latin1');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin1_general_ci', 'latin1');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin1_general_cs', 'latin1');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin1_spanish_ci', 'latin1');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin2_czech_cs', 'latin2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin2_general_ci', 'latin2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin2_hungarian_ci', 'latin2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin2_croatian_ci', 'latin2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin2_bin', 'latin2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('swe7_swedish_ci', 'swe7');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('swe7_bin', 'swe7');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ascii_general_ci', 'ascii');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ascii_bin', 'ascii');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ujis_japanese_ci', 'ujis');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ujis_bin', 'ujis');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('sjis_japanese_ci', 'sjis');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('sjis_bin', 'sjis');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('hebrew_general_ci', 'hebrew');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('hebrew_bin', 'hebrew');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('tis620_thai_ci', 'tis620');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('tis620_bin', 'tis620');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('euckr_korean_ci', 'euckr');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('euckr_bin', 'euckr');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('koi8u_general_ci', 'koi8u');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('koi8u_bin', 'koi8u');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('gb2312_chinese_ci', 'gb2312');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('gb2312_bin', 'gb2312');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('greek_general_ci', 'greek');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('greek_bin', 'greek');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp1250_general_ci', 'cp1250');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp1250_czech_cs', 'cp1250');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp1250_croatian_ci', 'cp1250');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp1250_bin', 'cp1250');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('gbk_chinese_ci', 'gbk');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('gbk_bin', 'gbk');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin5_turkish_ci', 'latin5');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin5_bin', 'latin5');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('armscii8_general_ci', 'armscii8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('armscii8_bin', 'armscii8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_general_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_bin', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_unicode_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_icelandic_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_latvian_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_romanian_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_slovenian_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_polish_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_estonian_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_spanish_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_swedish_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_turkish_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_czech_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_danish_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_lithuanian_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_slovak_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_spanish2_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_roman_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_persian_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_esperanto_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_hungarian_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_general_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_bin', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_unicode_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_icelandic_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_latvian_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_romanian_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_slovenian_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_polish_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_estonian_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_spanish_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_swedish_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_turkish_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_czech_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_danish_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_lithuanian_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_slovak_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_spanish2_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_roman_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_persian_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_esperanto_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_hungarian_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp866_general_ci', 'cp866');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp866_bin', 'cp866');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('keybcs2_general_ci', 'keybcs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('keybcs2_bin', 'keybcs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('macce_general_ci', 'macce');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('macce_bin', 'macce');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('macroman_general_ci', 'macroman');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('macroman_bin', 'macroman');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp852_general_ci', 'cp852');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp852_bin', 'cp852');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin7_estonian_cs', 'latin7');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin7_general_ci', 'latin7');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin7_general_cs', 'latin7');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin7_bin', 'latin7');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp1251_bulgarian_ci', 'cp1251');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp1251_ukrainian_ci', 'cp1251');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp1251_bin', 'cp1251');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp1251_general_ci', 'cp1251');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp1251_general_cs', 'cp1251');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp1256_general_ci', 'cp1256');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp1256_bin', 'cp1256');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp1257_lithuanian_ci', 'cp1257');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp1257_bin', 'cp1257');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp1257_general_ci', 'cp1257');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('binary', 'binary');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('geostd8_general_ci', 'geostd8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('geostd8_bin', 'geostd8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp932_japanese_ci', 'cp932');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp932_bin', 'cp932');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('eucjpms_japanese_ci', 'eucjpms');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('eucjpms_bin', 'eucjpms');

-- --------------------------------------------------------

--
-- Table structure for table `COLUMNS`
--

CREATE TEMPORARY TABLE `COLUMNS` (
  `TABLE_CATALOG` varchar(512) default NULL,
  `TABLE_SCHEMA` varchar(64) NOT NULL default '',
  `TABLE_NAME` varchar(64) NOT NULL default '',
  `COLUMN_NAME` varchar(64) NOT NULL default '',
  `ORDINAL_POSITION` bigint(21) NOT NULL default '0',
  `COLUMN_DEFAULT` longtext,
  `IS_NULLABLE` varchar(3) NOT NULL default '',
  `DATA_TYPE` varchar(64) NOT NULL default '',
  `CHARACTER_MAXIMUM_LENGTH` bigint(21) default NULL,
  `CHARACTER_OCTET_LENGTH` bigint(21) default NULL,
  `NUMERIC_PRECISION` bigint(21) default NULL,
  `NUMERIC_SCALE` bigint(21) default NULL,
  `CHARACTER_SET_NAME` varchar(64) default NULL,
  `COLLATION_NAME` varchar(64) default NULL,
  `COLUMN_TYPE` longtext NOT NULL,
  `COLUMN_KEY` varchar(3) NOT NULL default '',
  `EXTRA` varchar(20) NOT NULL default '',
  `PRIVILEGES` varchar(80) NOT NULL default '',
  `COLUMN_COMMENT` varchar(255) NOT NULL default ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `COLUMNS`
--

INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CHARACTER_SETS', 'CHARACTER_SET_NAME', 1, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CHARACTER_SETS', 'DEFAULT_COLLATE_NAME', 2, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CHARACTER_SETS', 'DESCRIPTION', 3, '', 'NO', 'varchar', 60, 180, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(60)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CHARACTER_SETS', 'MAXLEN', 4, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'CLIENT', 1, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'TOTAL_CONNECTIONS', 2, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'CONCURRENT_CONNECTIONS', 3, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'CONNECTED_TIME', 4, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'BUSY_TIME', 5, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'CPU_TIME', 6, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'BYTES_RECEIVED', 7, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'BYTES_SENT', 8, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'BINLOG_BYTES_WRITTEN', 9, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'ROWS_FETCHED', 10, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'ROWS_UPDATED', 11, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'TABLE_ROWS_READ', 12, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'SELECT_COMMANDS', 13, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'UPDATE_COMMANDS', 14, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'OTHER_COMMANDS', 15, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'COMMIT_TRANSACTIONS', 16, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'ROLLBACK_TRANSACTIONS', 17, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'DENIED_CONNECTIONS', 18, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'LOST_CONNECTIONS', 19, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'ACCESS_DENIED', 20, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'EMPTY_QUERIES', 21, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLLATIONS', 'COLLATION_NAME', 1, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLLATIONS', 'CHARACTER_SET_NAME', 2, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLLATIONS', 'ID', 3, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(11)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLLATIONS', 'IS_DEFAULT', 4, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLLATIONS', 'IS_COMPILED', 5, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLLATIONS', 'SORTLEN', 6, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLLATION_CHARACTER_SET_APPLICABILITY', 'COLLATION_NAME', 1, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLLATION_CHARACTER_SET_APPLICABILITY', 'CHARACTER_SET_NAME', 2, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'TABLE_CATALOG', 1, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'TABLE_SCHEMA', 2, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'TABLE_NAME', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'COLUMN_NAME', 4, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'ORDINAL_POSITION', 5, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'COLUMN_DEFAULT', 6, NULL, 'YES', 'longtext', 4294967295, 4294967295, NULL, NULL, 'utf8', 'utf8_general_ci', 'longtext', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'IS_NULLABLE', 7, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'DATA_TYPE', 8, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'CHARACTER_MAXIMUM_LENGTH', 9, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'CHARACTER_OCTET_LENGTH', 10, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'NUMERIC_PRECISION', 11, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'NUMERIC_SCALE', 12, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'CHARACTER_SET_NAME', 13, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'COLLATION_NAME', 14, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'COLUMN_TYPE', 15, NULL, 'NO', 'longtext', 4294967295, 4294967295, NULL, NULL, 'utf8', 'utf8_general_ci', 'longtext', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'COLUMN_KEY', 16, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'EXTRA', 17, '', 'NO', 'varchar', 20, 60, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'PRIVILEGES', 18, '', 'NO', 'varchar', 80, 240, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(80)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'COLUMN_COMMENT', 19, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMN_PRIVILEGES', 'GRANTEE', 1, '', 'NO', 'varchar', 81, 243, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(81)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMN_PRIVILEGES', 'TABLE_CATALOG', 2, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMN_PRIVILEGES', 'TABLE_SCHEMA', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMN_PRIVILEGES', 'TABLE_NAME', 4, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMN_PRIVILEGES', 'COLUMN_NAME', 5, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMN_PRIVILEGES', 'PRIVILEGE_TYPE', 6, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMN_PRIVILEGES', 'IS_GRANTABLE', 7, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_BUFFER_POOL_CONTENT', 'BLOCK_NUM', 1, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_BUFFER_POOL_CONTENT', 'SPACE', 2, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_BUFFER_POOL_CONTENT', 'OFFSET', 3, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_BUFFER_POOL_CONTENT', 'RECORDS', 4, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_BUFFER_POOL_CONTENT', 'DATASIZE', 5, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_BUFFER_POOL_CONTENT', 'FLUSH_TYPE', 6, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_BUFFER_POOL_CONTENT', 'FIX_COUNT', 7, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_BUFFER_POOL_CONTENT', 'LRU_POSITION', 8, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_BUFFER_POOL_CONTENT', 'PAGE_TYPE_ID', 9, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_BUFFER_POOL_CONTENT', 'PAGE_TYPE', 10, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_BUFFER_POOL_CONTENT', 'INDEX_NAME', 11, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_BUFFER_POOL_CONTENT', 'TABLE_SCHEMA', 12, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_BUFFER_POOL_CONTENT', 'TABLE_NAME', 13, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INDEX_STATISTICS', 'TABLE_SCHEMA', 1, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INDEX_STATISTICS', 'TABLE_NAME', 2, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INDEX_STATISTICS', 'INDEX_NAME', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INDEX_STATISTICS', 'ROWS_READ', 4, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'CONSTRAINT_CATALOG', 1, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'CONSTRAINT_SCHEMA', 2, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'CONSTRAINT_NAME', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'TABLE_CATALOG', 4, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'TABLE_SCHEMA', 5, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'TABLE_NAME', 6, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'COLUMN_NAME', 7, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'ORDINAL_POSITION', 8, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(10)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'POSITION_IN_UNIQUE_CONSTRAINT', 9, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(10)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'REFERENCED_TABLE_SCHEMA', 10, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'REFERENCED_TABLE_NAME', 11, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'REFERENCED_COLUMN_NAME', 12, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROCESSLIST', 'ID', 1, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(4)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROCESSLIST', 'USER', 2, '', 'NO', 'varchar', 16, 48, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(16)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROCESSLIST', 'HOST', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROCESSLIST', 'DB', 4, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROCESSLIST', 'COMMAND', 5, '', 'NO', 'varchar', 16, 48, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(16)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROCESSLIST', 'TIME', 6, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(7)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROCESSLIST', 'STATE', 7, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROCESSLIST', 'INFO', 8, NULL, 'YES', 'longtext', 4294967295, 4294967295, NULL, NULL, 'utf8', 'utf8_general_ci', 'longtext', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROCESSLIST', 'TIME_MS', 9, '0.000', 'NO', 'decimal', NULL, NULL, 22, 3, NULL, NULL, 'decimal(22,3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROFILING', 'QUERY_ID', 1, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROFILING', 'SEQ', 2, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROFILING', 'STATE', 3, '', 'NO', 'varchar', 30, 90, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(30)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROFILING', 'DURATION', 4, '0.000000', 'NO', 'decimal', NULL, NULL, 9, 6, NULL, NULL, 'decimal(9,6)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROFILING', 'CPU_USER', 5, NULL, 'YES', 'decimal', NULL, NULL, 9, 6, NULL, NULL, 'decimal(9,6)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROFILING', 'CPU_SYSTEM', 6, NULL, 'YES', 'decimal', NULL, NULL, 9, 6, NULL, NULL, 'decimal(9,6)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROFILING', 'CONTEXT_VOLUNTARY', 7, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROFILING', 'CONTEXT_INVOLUNTARY', 8, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROFILING', 'BLOCK_OPS_IN', 9, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROFILING', 'BLOCK_OPS_OUT', 10, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROFILING', 'MESSAGES_SENT', 11, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROFILING', 'MESSAGES_RECEIVED', 12, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROFILING', 'PAGE_FAULTS_MAJOR', 13, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROFILING', 'PAGE_FAULTS_MINOR', 14, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROFILING', 'SWAPS', 15, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROFILING', 'SOURCE_FUNCTION', 16, NULL, 'YES', 'varchar', 30, 90, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(30)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROFILING', 'SOURCE_FILE', 17, NULL, 'YES', 'varchar', 20, 60, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROFILING', 'SOURCE_LINE', 18, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'SPECIFIC_NAME', 1, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'ROUTINE_CATALOG', 2, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'ROUTINE_SCHEMA', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'ROUTINE_NAME', 4, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'ROUTINE_TYPE', 5, '', 'NO', 'varchar', 9, 27, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(9)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'DTD_IDENTIFIER', 6, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'ROUTINE_BODY', 7, '', 'NO', 'varchar', 8, 24, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(8)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'ROUTINE_DEFINITION', 8, NULL, 'YES', 'longtext', 4294967295, 4294967295, NULL, NULL, 'utf8', 'utf8_general_ci', 'longtext', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'EXTERNAL_NAME', 9, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'EXTERNAL_LANGUAGE', 10, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'PARAMETER_STYLE', 11, '', 'NO', 'varchar', 8, 24, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(8)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'IS_DETERMINISTIC', 12, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'SQL_DATA_ACCESS', 13, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'SQL_PATH', 14, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'SECURITY_TYPE', 15, '', 'NO', 'varchar', 7, 21, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(7)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'CREATED', 16, '0000-00-00 00:00:00', 'NO', 'datetime', NULL, NULL, NULL, NULL, NULL, NULL, 'datetime', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'LAST_ALTERED', 17, '0000-00-00 00:00:00', 'NO', 'datetime', NULL, NULL, NULL, NULL, NULL, NULL, 'datetime', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'SQL_MODE', 18, NULL, 'NO', 'longtext', 4294967295, 4294967295, NULL, NULL, 'utf8', 'utf8_general_ci', 'longtext', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'ROUTINE_COMMENT', 19, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'DEFINER', 20, '', 'NO', 'varchar', 77, 231, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(77)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'SCHEMATA', 'CATALOG_NAME', 1, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'SCHEMATA', 'SCHEMA_NAME', 2, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'SCHEMATA', 'DEFAULT_CHARACTER_SET_NAME', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'SCHEMATA', 'DEFAULT_COLLATION_NAME', 4, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'SCHEMATA', 'SQL_PATH', 5, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'SCHEMA_PRIVILEGES', 'GRANTEE', 1, '', 'NO', 'varchar', 81, 243, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(81)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'SCHEMA_PRIVILEGES', 'TABLE_CATALOG', 2, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'SCHEMA_PRIVILEGES', 'TABLE_SCHEMA', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'SCHEMA_PRIVILEGES', 'PRIVILEGE_TYPE', 4, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'SCHEMA_PRIVILEGES', 'IS_GRANTABLE', 5, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'STATISTICS', 'TABLE_CATALOG', 1, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'STATISTICS', 'TABLE_SCHEMA', 2, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'STATISTICS', 'TABLE_NAME', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'STATISTICS', 'NON_UNIQUE', 4, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(1)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'STATISTICS', 'INDEX_SCHEMA', 5, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'STATISTICS', 'INDEX_NAME', 6, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'STATISTICS', 'SEQ_IN_INDEX', 7, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(2)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'STATISTICS', 'COLUMN_NAME', 8, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'STATISTICS', 'COLLATION', 9, NULL, 'YES', 'varchar', 1, 3, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(1)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'STATISTICS', 'CARDINALITY', 10, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'STATISTICS', 'SUB_PART', 11, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'STATISTICS', 'PACKED', 12, NULL, 'YES', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'STATISTICS', 'NULLABLE', 13, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'STATISTICS', 'INDEX_TYPE', 14, '', 'NO', 'varchar', 16, 48, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(16)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'STATISTICS', 'COMMENT', 15, NULL, 'YES', 'varchar', 16, 48, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(16)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'TABLE_CATALOG', 1, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'TABLE_SCHEMA', 2, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'TABLE_NAME', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'TABLE_TYPE', 4, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'ENGINE', 5, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'VERSION', 6, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'ROW_FORMAT', 7, NULL, 'YES', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'TABLE_ROWS', 8, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'AVG_ROW_LENGTH', 9, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'DATA_LENGTH', 10, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'MAX_DATA_LENGTH', 11, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'INDEX_LENGTH', 12, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'DATA_FREE', 13, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'AUTO_INCREMENT', 14, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'CREATE_TIME', 15, NULL, 'YES', 'datetime', NULL, NULL, NULL, NULL, NULL, NULL, 'datetime', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'UPDATE_TIME', 16, NULL, 'YES', 'datetime', NULL, NULL, NULL, NULL, NULL, NULL, 'datetime', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'CHECK_TIME', 17, NULL, 'YES', 'datetime', NULL, NULL, NULL, NULL, NULL, NULL, 'datetime', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'TABLE_COLLATION', 18, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'CHECKSUM', 19, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'CREATE_OPTIONS', 20, NULL, 'YES', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'TABLE_COMMENT', 21, '', 'NO', 'varchar', 80, 240, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(80)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLE_CONSTRAINTS', 'CONSTRAINT_CATALOG', 1, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLE_CONSTRAINTS', 'CONSTRAINT_SCHEMA', 2, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLE_CONSTRAINTS', 'CONSTRAINT_NAME', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLE_CONSTRAINTS', 'TABLE_SCHEMA', 4, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLE_CONSTRAINTS', 'TABLE_NAME', 5, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLE_CONSTRAINTS', 'CONSTRAINT_TYPE', 6, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLE_PRIVILEGES', 'GRANTEE', 1, '', 'NO', 'varchar', 81, 243, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(81)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLE_PRIVILEGES', 'TABLE_CATALOG', 2, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLE_PRIVILEGES', 'TABLE_SCHEMA', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLE_PRIVILEGES', 'TABLE_NAME', 4, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLE_PRIVILEGES', 'PRIVILEGE_TYPE', 5, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLE_PRIVILEGES', 'IS_GRANTABLE', 6, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLE_STATISTICS', 'TABLE_SCHEMA', 1, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLE_STATISTICS', 'TABLE_NAME', 2, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLE_STATISTICS', 'ROWS_READ', 3, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLE_STATISTICS', 'ROWS_CHANGED', 4, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLE_STATISTICS', 'ROWS_CHANGED_X_INDEXES', 5, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'TRIGGER_CATALOG', 1, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'TRIGGER_SCHEMA', 2, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'TRIGGER_NAME', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'EVENT_MANIPULATION', 4, '', 'NO', 'varchar', 6, 18, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(6)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'EVENT_OBJECT_CATALOG', 5, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'EVENT_OBJECT_SCHEMA', 6, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'EVENT_OBJECT_TABLE', 7, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'ACTION_ORDER', 8, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(4)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'ACTION_CONDITION', 9, NULL, 'YES', 'longtext', 4294967295, 4294967295, NULL, NULL, 'utf8', 'utf8_general_ci', 'longtext', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'ACTION_STATEMENT', 10, NULL, 'NO', 'longtext', 4294967295, 4294967295, NULL, NULL, 'utf8', 'utf8_general_ci', 'longtext', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'ACTION_ORIENTATION', 11, '', 'NO', 'varchar', 9, 27, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(9)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'ACTION_TIMING', 12, '', 'NO', 'varchar', 6, 18, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(6)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'ACTION_REFERENCE_OLD_TABLE', 13, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'ACTION_REFERENCE_NEW_TABLE', 14, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'ACTION_REFERENCE_OLD_ROW', 15, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'ACTION_REFERENCE_NEW_ROW', 16, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'CREATED', 17, NULL, 'YES', 'datetime', NULL, NULL, NULL, NULL, NULL, NULL, 'datetime', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'SQL_MODE', 18, NULL, 'NO', 'longtext', 4294967295, 4294967295, NULL, NULL, 'utf8', 'utf8_general_ci', 'longtext', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'DEFINER', 19, NULL, 'NO', 'longtext', 4294967295, 4294967295, NULL, NULL, 'utf8', 'utf8_general_ci', 'longtext', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_PRIVILEGES', 'GRANTEE', 1, '', 'NO', 'varchar', 81, 243, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(81)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_PRIVILEGES', 'TABLE_CATALOG', 2, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_PRIVILEGES', 'PRIVILEGE_TYPE', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_PRIVILEGES', 'IS_GRANTABLE', 4, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'USER', 1, '', 'NO', 'varchar', 16, 48, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(16)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'TOTAL_CONNECTIONS', 2, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'CONCURRENT_CONNECTIONS', 3, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'CONNECTED_TIME', 4, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'BUSY_TIME', 5, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'CPU_TIME', 6, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'BYTES_RECEIVED', 7, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'BYTES_SENT', 8, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'BINLOG_BYTES_WRITTEN', 9, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'ROWS_FETCHED', 10, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'ROWS_UPDATED', 11, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'TABLE_ROWS_READ', 12, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'SELECT_COMMANDS', 13, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'UPDATE_COMMANDS', 14, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'OTHER_COMMANDS', 15, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'COMMIT_TRANSACTIONS', 16, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'ROLLBACK_TRANSACTIONS', 17, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'DENIED_CONNECTIONS', 18, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'LOST_CONNECTIONS', 19, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'ACCESS_DENIED', 20, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'EMPTY_QUERIES', 21, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'VIEWS', 'TABLE_CATALOG', 1, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'VIEWS', 'TABLE_SCHEMA', 2, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'VIEWS', 'TABLE_NAME', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'VIEWS', 'VIEW_DEFINITION', 4, NULL, 'NO', 'longtext', 4294967295, 4294967295, NULL, NULL, 'utf8', 'utf8_general_ci', 'longtext', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'VIEWS', 'CHECK_OPTION', 5, '', 'NO', 'varchar', 8, 24, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(8)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'VIEWS', 'IS_UPDATABLE', 6, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'VIEWS', 'DEFINER', 7, '', 'NO', 'varchar', 77, 231, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(77)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'VIEWS', 'SECURITY_TYPE', 8, '', 'NO', 'varchar', 7, 21, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(7)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_IO_PATTERN', 'SPACE', 1, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(11)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_IO_PATTERN', 'OFFSET', 2, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(11)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_IO_PATTERN', 'INDEX_ID', 3, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(11)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_IO_PATTERN', 'TABLE_NAME', 4, '', 'NO', 'varchar', 32, 96, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(32)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_IO_PATTERN', 'INDEX_NAME', 5, '', 'NO', 'varchar', 32, 96, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(32)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_IO_PATTERN', 'N_READ', 6, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(11)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_IO_PATTERN', 'N_WRITE', 7, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(11)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_RSEG', 'RSEG_ID', 1, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_RSEG', 'SPACE_ID', 2, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_RSEG', 'PAGE_NO', 3, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_RSEG', 'MAX_SIZE', 4, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_RSEG', 'CURR_SIZE', 5, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'fav_place', 'fpid', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'fav_place', 'name', 2, NULL, 'NO', 'varchar', 100, 100, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'fav_place', 'iconid', 3, NULL, 'NO', 'varchar', 10, 10, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'fav_place', 'address', 4, NULL, 'NO', 'varchar', 200, 200, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(200)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'fav_place', 'website', 5, NULL, 'NO', 'varchar', 200, 200, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(200)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'fav_place', 'lan', 6, NULL, 'NO', 'varchar', 30, 30, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(30)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'fav_place', 'lat', 7, NULL, 'NO', 'varchar', 30, 30, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(30)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'fav_place', 'types', 8, NULL, 'NO', 'varchar', 50, 50, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(50)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'fav_place', 'plcid', 9, NULL, 'NO', 'varchar', 100, 100, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'fav_place', 'reference', 10, NULL, 'NO', 'text', 65535, 65535, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'text', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'fav_place', 'rating', 11, NULL, 'NO', 'varchar', 25, 25, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(25)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'fav_place', 'date', 12, NULL, 'NO', 'date', NULL, NULL, NULL, NULL, NULL, NULL, 'date', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'fav_property', 'fid', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'fav_property', 'pid', 2, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'fav_property', 'name', 3, NULL, 'NO', 'varchar', 100, 100, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'fav_property', 'beds', 4, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'fav_property', 'baths', 5, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'fav_property', 'area', 6, NULL, 'NO', 'varchar', 20, 20, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(20)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'fav_property', 'price', 7, NULL, 'NO', 'varchar', 20, 20, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(20)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'fav_property', 'iconid', 8, NULL, 'NO', 'varchar', 10, 10, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'fav_property', 'location', 9, NULL, 'NO', 'varchar', 200, 200, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(200)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'fav_property', 'street', 10, NULL, 'NO', 'varchar', 200, 200, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(200)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'fav_property', 'city', 11, NULL, 'NO', 'varchar', 100, 100, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'fav_property', 'country', 12, NULL, 'NO', 'varchar', 100, 100, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'fav_property', 'zipcode', 13, NULL, 'NO', 'varchar', 20, 20, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(20)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'fav_property', 'lan', 14, NULL, 'NO', 'varchar', 30, 30, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(30)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'fav_property', 'lat', 15, NULL, 'NO', 'varchar', 30, 30, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(30)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'fav_property', 'date', 16, NULL, 'NO', 'date', NULL, NULL, NULL, NULL, NULL, NULL, 'date', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'icon', 'iconid', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'icon', 'type', 2, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'icon', 'value', 3, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'icon', 'icon', 4, NULL, 'NO', 'blob', 65535, 65535, NULL, NULL, NULL, NULL, 'blob', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'icon', 'date', 5, NULL, 'NO', 'date', NULL, NULL, NULL, NULL, NULL, NULL, 'date', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'property', 'pid', 1, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'property', 'name', 2, NULL, 'NO', 'varchar', 100, 100, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'property', 'beds', 3, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'property', 'baths', 4, NULL, 'NO', 'int', NULL, NULL, 10, 0, NULL, NULL, 'int(11)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'property', 'area', 5, NULL, 'NO', 'varchar', 20, 20, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(20)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'property', 'price', 6, NULL, 'NO', 'varchar', 20, 20, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(20)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'property', 'icontype', 7, NULL, 'NO', 'varchar', 10, 10, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'property', 'iconvalue', 8, NULL, 'NO', 'varchar', 10, 10, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(10)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'property', 'location', 9, NULL, 'NO', 'varchar', 200, 200, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(200)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'property', 'street', 10, NULL, 'NO', 'varchar', 200, 200, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(200)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'property', 'city', 11, NULL, 'NO', 'varchar', 100, 100, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'property', 'country', 12, NULL, 'NO', 'varchar', 100, 100, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'property', 'zipcode', 13, NULL, 'NO', 'varchar', 20, 20, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(20)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'property', 'lan', 14, NULL, 'NO', 'varchar', 30, 30, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(30)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'property', 'lat', 15, NULL, 'NO', 'varchar', 30, 30, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(30)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'yuigooglemap', 'property', 'date', 16, NULL, 'NO', 'date', NULL, NULL, NULL, NULL, NULL, NULL, 'date', '', '', 'select,insert,update', '');

-- --------------------------------------------------------

--
-- Table structure for table `COLUMN_PRIVILEGES`
--

CREATE TEMPORARY TABLE `COLUMN_PRIVILEGES` (
  `GRANTEE` varchar(81) NOT NULL default '',
  `TABLE_CATALOG` varchar(512) default NULL,
  `TABLE_SCHEMA` varchar(64) NOT NULL default '',
  `TABLE_NAME` varchar(64) NOT NULL default '',
  `COLUMN_NAME` varchar(64) NOT NULL default '',
  `PRIVILEGE_TYPE` varchar(64) NOT NULL default '',
  `IS_GRANTABLE` varchar(3) NOT NULL default ''
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `COLUMN_PRIVILEGES`
--


-- --------------------------------------------------------

--
-- Table structure for table `INNODB_BUFFER_POOL_CONTENT`
--

CREATE TEMPORARY TABLE `INNODB_BUFFER_POOL_CONTENT` (
  `BLOCK_NUM` bigint(21) NOT NULL default '0',
  `SPACE` bigint(21) NOT NULL default '0',
  `OFFSET` bigint(21) NOT NULL default '0',
  `RECORDS` bigint(21) NOT NULL default '0',
  `DATASIZE` bigint(21) NOT NULL default '0',
  `FLUSH_TYPE` bigint(21) NOT NULL default '0',
  `FIX_COUNT` bigint(21) NOT NULL default '0',
  `LRU_POSITION` bigint(21) NOT NULL default '0',
  `PAGE_TYPE_ID` bigint(21) NOT NULL default '0',
  `PAGE_TYPE` varchar(64) NOT NULL default '',
  `INDEX_NAME` varchar(64) NOT NULL default '',
  `TABLE_SCHEMA` varchar(64) NOT NULL default '',
  `TABLE_NAME` varchar(64) NOT NULL default ''
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `INNODB_BUFFER_POOL_CONTENT`
--

-- in use (#1227 - Access denied; you need the PROCESS privilege for this operation)

-- --------------------------------------------------------

--
-- Table structure for table `INDEX_STATISTICS`
--

CREATE TEMPORARY TABLE `INDEX_STATISTICS` (
  `TABLE_SCHEMA` varchar(64) NOT NULL default '',
  `TABLE_NAME` varchar(64) NOT NULL default '',
  `INDEX_NAME` varchar(64) NOT NULL default '',
  `ROWS_READ` bigint(21) NOT NULL default '0'
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `INDEX_STATISTICS`
--


-- --------------------------------------------------------

--
-- Table structure for table `KEY_COLUMN_USAGE`
--

CREATE TEMPORARY TABLE `KEY_COLUMN_USAGE` (
  `CONSTRAINT_CATALOG` varchar(512) default NULL,
  `CONSTRAINT_SCHEMA` varchar(64) NOT NULL default '',
  `CONSTRAINT_NAME` varchar(64) NOT NULL default '',
  `TABLE_CATALOG` varchar(512) default NULL,
  `TABLE_SCHEMA` varchar(64) NOT NULL default '',
  `TABLE_NAME` varchar(64) NOT NULL default '',
  `COLUMN_NAME` varchar(64) NOT NULL default '',
  `ORDINAL_POSITION` bigint(10) NOT NULL default '0',
  `POSITION_IN_UNIQUE_CONSTRAINT` bigint(10) default NULL,
  `REFERENCED_TABLE_SCHEMA` varchar(64) default NULL,
  `REFERENCED_TABLE_NAME` varchar(64) default NULL,
  `REFERENCED_COLUMN_NAME` varchar(64) default NULL
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `KEY_COLUMN_USAGE`
--

INSERT INTO `KEY_COLUMN_USAGE` VALUES(NULL, 'yuigooglemap', 'PRIMARY', NULL, 'yuigooglemap', 'fav_place', 'fpid', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES(NULL, 'yuigooglemap', 'PRIMARY', NULL, 'yuigooglemap', 'fav_property', 'fid', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES(NULL, 'yuigooglemap', 'PRIMARY', NULL, 'yuigooglemap', 'icon', 'iconid', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES(NULL, 'yuigooglemap', 'PRIMARY', NULL, 'yuigooglemap', 'property', 'pid', 1, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `PROCESSLIST`
--

CREATE TEMPORARY TABLE `PROCESSLIST` (
  `ID` bigint(4) NOT NULL default '0',
  `USER` varchar(16) NOT NULL default '',
  `HOST` varchar(64) NOT NULL default '',
  `DB` varchar(64) default NULL,
  `COMMAND` varchar(16) NOT NULL default '',
  `TIME` bigint(7) NOT NULL default '0',
  `STATE` varchar(64) default NULL,
  `INFO` longtext,
  `TIME_MS` decimal(22,3) NOT NULL default '0.000'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `PROCESSLIST`
--

INSERT INTO `PROCESSLIST` VALUES(392008, 'yuigooglemap', '182.50.131.34:56708', NULL, 'Query', 0, 'executing', 'SELECT * FROM `information_schema`.`PROCESSLIST`', 0.599);

-- --------------------------------------------------------

--
-- Table structure for table `PROFILING`
--

CREATE TEMPORARY TABLE `PROFILING` (
  `QUERY_ID` bigint(20) NOT NULL default '0',
  `SEQ` bigint(20) NOT NULL default '0',
  `STATE` varchar(30) NOT NULL default '',
  `DURATION` decimal(9,6) NOT NULL default '0.000000',
  `CPU_USER` decimal(9,6) default NULL,
  `CPU_SYSTEM` decimal(9,6) default NULL,
  `CONTEXT_VOLUNTARY` bigint(20) default NULL,
  `CONTEXT_INVOLUNTARY` bigint(20) default NULL,
  `BLOCK_OPS_IN` bigint(20) default NULL,
  `BLOCK_OPS_OUT` bigint(20) default NULL,
  `MESSAGES_SENT` bigint(20) default NULL,
  `MESSAGES_RECEIVED` bigint(20) default NULL,
  `PAGE_FAULTS_MAJOR` bigint(20) default NULL,
  `PAGE_FAULTS_MINOR` bigint(20) default NULL,
  `SWAPS` bigint(20) default NULL,
  `SOURCE_FUNCTION` varchar(30) default NULL,
  `SOURCE_FILE` varchar(20) default NULL,
  `SOURCE_LINE` bigint(20) default NULL
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `PROFILING`
--


-- --------------------------------------------------------

--
-- Table structure for table `ROUTINES`
--

CREATE TEMPORARY TABLE `ROUTINES` (
  `SPECIFIC_NAME` varchar(64) NOT NULL default '',
  `ROUTINE_CATALOG` varchar(512) default NULL,
  `ROUTINE_SCHEMA` varchar(64) NOT NULL default '',
  `ROUTINE_NAME` varchar(64) NOT NULL default '',
  `ROUTINE_TYPE` varchar(9) NOT NULL default '',
  `DTD_IDENTIFIER` varchar(64) default NULL,
  `ROUTINE_BODY` varchar(8) NOT NULL default '',
  `ROUTINE_DEFINITION` longtext,
  `EXTERNAL_NAME` varchar(64) default NULL,
  `EXTERNAL_LANGUAGE` varchar(64) default NULL,
  `PARAMETER_STYLE` varchar(8) NOT NULL default '',
  `IS_DETERMINISTIC` varchar(3) NOT NULL default '',
  `SQL_DATA_ACCESS` varchar(64) NOT NULL default '',
  `SQL_PATH` varchar(64) default NULL,
  `SECURITY_TYPE` varchar(7) NOT NULL default '',
  `CREATED` datetime NOT NULL default '0000-00-00 00:00:00',
  `LAST_ALTERED` datetime NOT NULL default '0000-00-00 00:00:00',
  `SQL_MODE` longtext NOT NULL,
  `ROUTINE_COMMENT` varchar(64) NOT NULL default '',
  `DEFINER` varchar(77) NOT NULL default ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ROUTINES`
--


-- --------------------------------------------------------

--
-- Table structure for table `SCHEMATA`
--

CREATE TEMPORARY TABLE `SCHEMATA` (
  `CATALOG_NAME` varchar(512) default NULL,
  `SCHEMA_NAME` varchar(64) NOT NULL default '',
  `DEFAULT_CHARACTER_SET_NAME` varchar(64) NOT NULL default '',
  `DEFAULT_COLLATION_NAME` varchar(64) NOT NULL default '',
  `SQL_PATH` varchar(512) default NULL
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `SCHEMATA`
--

INSERT INTO `SCHEMATA` VALUES(NULL, 'information_schema', 'utf8', 'utf8_general_ci', NULL);
INSERT INTO `SCHEMATA` VALUES(NULL, 'yuigooglemap', 'utf8', 'utf8_general_ci', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `SCHEMA_PRIVILEGES`
--

CREATE TEMPORARY TABLE `SCHEMA_PRIVILEGES` (
  `GRANTEE` varchar(81) NOT NULL default '',
  `TABLE_CATALOG` varchar(512) default NULL,
  `TABLE_SCHEMA` varchar(64) NOT NULL default '',
  `PRIVILEGE_TYPE` varchar(64) NOT NULL default '',
  `IS_GRANTABLE` varchar(3) NOT NULL default ''
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `SCHEMA_PRIVILEGES`
--

INSERT INTO `SCHEMA_PRIVILEGES` VALUES('''yuigooglemap''@''%''', NULL, 'yuigooglemap', 'SELECT', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES('''yuigooglemap''@''%''', NULL, 'yuigooglemap', 'INSERT', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES('''yuigooglemap''@''%''', NULL, 'yuigooglemap', 'UPDATE', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES('''yuigooglemap''@''%''', NULL, 'yuigooglemap', 'DELETE', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES('''yuigooglemap''@''%''', NULL, 'yuigooglemap', 'CREATE', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES('''yuigooglemap''@''%''', NULL, 'yuigooglemap', 'DROP', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES('''yuigooglemap''@''%''', NULL, 'yuigooglemap', 'INDEX', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES('''yuigooglemap''@''%''', NULL, 'yuigooglemap', 'ALTER', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES('''yuigooglemap''@''%''', NULL, 'yuigooglemap', 'CREATE TEMPORARY TABLES', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES('''yuigooglemap''@''%''', NULL, 'yuigooglemap', 'LOCK TABLES', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES('''yuigooglemap''@''%''', NULL, 'yuigooglemap', 'EXECUTE', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES('''yuigooglemap''@''%''', NULL, 'yuigooglemap', 'CREATE VIEW', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES('''yuigooglemap''@''%''', NULL, 'yuigooglemap', 'SHOW VIEW', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES('''yuigooglemap''@''%''', NULL, 'yuigooglemap', 'CREATE ROUTINE', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES('''yuigooglemap''@''%''', NULL, 'yuigooglemap', 'ALTER ROUTINE', 'NO');

-- --------------------------------------------------------

--
-- Table structure for table `STATISTICS`
--

CREATE TEMPORARY TABLE `STATISTICS` (
  `TABLE_CATALOG` varchar(512) default NULL,
  `TABLE_SCHEMA` varchar(64) NOT NULL default '',
  `TABLE_NAME` varchar(64) NOT NULL default '',
  `NON_UNIQUE` bigint(1) NOT NULL default '0',
  `INDEX_SCHEMA` varchar(64) NOT NULL default '',
  `INDEX_NAME` varchar(64) NOT NULL default '',
  `SEQ_IN_INDEX` bigint(2) NOT NULL default '0',
  `COLUMN_NAME` varchar(64) NOT NULL default '',
  `COLLATION` varchar(1) default NULL,
  `CARDINALITY` bigint(21) default NULL,
  `SUB_PART` bigint(3) default NULL,
  `PACKED` varchar(10) default NULL,
  `NULLABLE` varchar(3) NOT NULL default '',
  `INDEX_TYPE` varchar(16) NOT NULL default '',
  `COMMENT` varchar(16) default NULL
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `STATISTICS`
--

INSERT INTO `STATISTICS` VALUES(NULL, 'yuigooglemap', 'fav_place', 0, 'yuigooglemap', 'PRIMARY', 1, 'fpid', 'A', 43, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES(NULL, 'yuigooglemap', 'fav_property', 0, 'yuigooglemap', 'PRIMARY', 1, 'fid', 'A', 12, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES(NULL, 'yuigooglemap', 'icon', 0, 'yuigooglemap', 'PRIMARY', 1, 'iconid', 'A', 22, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES(NULL, 'yuigooglemap', 'property', 0, 'yuigooglemap', 'PRIMARY', 1, 'pid', 'A', 115, NULL, NULL, '', 'BTREE', '');

-- --------------------------------------------------------

--
-- Table structure for table `TABLES`
--

CREATE TEMPORARY TABLE `TABLES` (
  `TABLE_CATALOG` varchar(512) default NULL,
  `TABLE_SCHEMA` varchar(64) NOT NULL default '',
  `TABLE_NAME` varchar(64) NOT NULL default '',
  `TABLE_TYPE` varchar(64) NOT NULL default '',
  `ENGINE` varchar(64) default NULL,
  `VERSION` bigint(21) default NULL,
  `ROW_FORMAT` varchar(10) default NULL,
  `TABLE_ROWS` bigint(21) default NULL,
  `AVG_ROW_LENGTH` bigint(21) default NULL,
  `DATA_LENGTH` bigint(21) default NULL,
  `MAX_DATA_LENGTH` bigint(21) default NULL,
  `INDEX_LENGTH` bigint(21) default NULL,
  `DATA_FREE` bigint(21) default NULL,
  `AUTO_INCREMENT` bigint(21) default NULL,
  `CREATE_TIME` datetime default NULL,
  `UPDATE_TIME` datetime default NULL,
  `CHECK_TIME` datetime default NULL,
  `TABLE_COLLATION` varchar(64) default NULL,
  `CHECKSUM` bigint(21) default NULL,
  `CREATE_OPTIONS` varchar(255) default NULL,
  `TABLE_COMMENT` varchar(80) NOT NULL default ''
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `TABLES`
--

INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'CHARACTER_SETS', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 576, 0, 8388288, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=14563', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 354, 0, 8388384, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=23696', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'COLLATIONS', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 423, 0, 8388513, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=19831', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'COLLATION_CHARACTER_SET_APPLICABILITY', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 387, 0, 8388225, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=21675', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'COLUMNS', 'SYSTEM VIEW', 'MyISAM', 0, 'Dynamic', NULL, 0, 0, 281474976710655, 1024, 0, NULL, '2013-09-12 10:42:51', '2013-09-12 10:42:51', NULL, 'utf8_general_ci', NULL, 'max_rows=2178', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'COLUMN_PRIVILEGES', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 2565, 0, 8387550, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=3270', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'INNODB_BUFFER_POOL_CONTENT', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 845, 0, 8388315, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=9927', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'INDEX_STATISTICS', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 588, 0, 8388408, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=14266', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 4637, 0, 8388333, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=1809', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'PROCESSLIST', 'SYSTEM VIEW', 'MyISAM', 0, 'Dynamic', NULL, 0, 0, 281474976710655, 1024, 0, NULL, '2013-09-12 10:42:51', '2013-09-12 10:42:51', NULL, 'utf8_general_ci', NULL, 'max_rows=11699', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'PROFILING', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 356, 0, 8388428, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=23563', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'ROUTINES', 'SYSTEM VIEW', 'MyISAM', 0, 'Dynamic', NULL, 0, 0, 281474976710655, 1024, 0, NULL, '2013-09-12 10:42:51', '2013-09-12 10:42:51', NULL, 'utf8_general_ci', NULL, 'max_rows=2293', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'SCHEMATA', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 3656, 0, 8386864, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=2294', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'SCHEMA_PRIVILEGES', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 2179, 0, 8386971, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=3849', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'STATISTICS', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 2679, 0, 8387949, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=3131', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'TABLES', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 3641, 0, 8385223, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=2303', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'TABLE_CONSTRAINTS', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 2504, 0, 8388400, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=3350', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'TABLE_PRIVILEGES', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 2372, 0, 8387392, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=3536', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'TABLE_STATISTICS', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 411, 0, 8388510, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=20410', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'TRIGGERS', 'SYSTEM VIEW', 'MyISAM', 0, 'Dynamic', NULL, 0, 0, 281474976710655, 1024, 0, NULL, '2013-09-12 10:42:51', '2013-09-12 10:42:51', NULL, 'utf8_general_ci', NULL, 'max_rows=1913', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'USER_PRIVILEGES', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 1986, 0, 8386878, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=4223', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 210, 0, 8388450, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=39945', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'VIEWS', 'SYSTEM VIEW', 'MyISAM', 0, 'Dynamic', NULL, 0, 0, 281474976710655, 1024, 0, NULL, '2013-09-12 10:42:51', '2013-09-12 10:42:51', NULL, 'utf8_general_ci', NULL, 'max_rows=3768', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'INNODB_IO_PATTERN', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 235, 0, 8388560, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=35696', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'INNODB_RSEG', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 41, 0, 8388600, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=204600', '');
INSERT INTO `TABLES` VALUES(NULL, 'yuigooglemap', 'fav_place', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 43, 433, 18628, 281474976710655, 2048, 0, 44, '2012-09-05 16:28:01', '2013-05-15 16:36:05', '2012-11-20 19:40:24', 'latin1_swedish_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES(NULL, 'yuigooglemap', 'fav_property', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 12, 101, 1212, 281474976710655, 2048, 0, 13, '2012-09-05 11:44:47', '2013-05-14 17:56:10', '2012-11-20 19:40:24', 'latin1_swedish_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES(NULL, 'yuigooglemap', 'icon', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 22, 1196, 26328, 281474976710655, 2048, 0, 32, '2012-09-05 16:27:53', '2012-09-10 10:20:49', '2012-11-20 19:40:24', 'latin1_swedish_ci', NULL, '', '');
INSERT INTO `TABLES` VALUES(NULL, 'yuigooglemap', 'property', 'BASE TABLE', 'MyISAM', 10, 'Dynamic', 115, 94, 10812, 281474976710655, 4096, 0, 182, '2012-09-05 11:43:36', '2012-09-05 11:44:00', '2012-11-20 19:40:24', 'latin1_swedish_ci', NULL, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `TABLE_CONSTRAINTS`
--

CREATE TEMPORARY TABLE `TABLE_CONSTRAINTS` (
  `CONSTRAINT_CATALOG` varchar(512) default NULL,
  `CONSTRAINT_SCHEMA` varchar(64) NOT NULL default '',
  `CONSTRAINT_NAME` varchar(64) NOT NULL default '',
  `TABLE_SCHEMA` varchar(64) NOT NULL default '',
  `TABLE_NAME` varchar(64) NOT NULL default '',
  `CONSTRAINT_TYPE` varchar(64) NOT NULL default ''
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `TABLE_CONSTRAINTS`
--

INSERT INTO `TABLE_CONSTRAINTS` VALUES(NULL, 'yuigooglemap', 'PRIMARY', 'yuigooglemap', 'fav_place', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES(NULL, 'yuigooglemap', 'PRIMARY', 'yuigooglemap', 'fav_property', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES(NULL, 'yuigooglemap', 'PRIMARY', 'yuigooglemap', 'icon', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES(NULL, 'yuigooglemap', 'PRIMARY', 'yuigooglemap', 'property', 'PRIMARY KEY');

-- --------------------------------------------------------

--
-- Table structure for table `TABLE_PRIVILEGES`
--

CREATE TEMPORARY TABLE `TABLE_PRIVILEGES` (
  `GRANTEE` varchar(81) NOT NULL default '',
  `TABLE_CATALOG` varchar(512) default NULL,
  `TABLE_SCHEMA` varchar(64) NOT NULL default '',
  `TABLE_NAME` varchar(64) NOT NULL default '',
  `PRIVILEGE_TYPE` varchar(64) NOT NULL default '',
  `IS_GRANTABLE` varchar(3) NOT NULL default ''
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `TABLE_PRIVILEGES`
--


-- --------------------------------------------------------

--
-- Table structure for table `TABLE_STATISTICS`
--

CREATE TEMPORARY TABLE `TABLE_STATISTICS` (
  `TABLE_SCHEMA` varchar(64) NOT NULL default '',
  `TABLE_NAME` varchar(64) NOT NULL default '',
  `ROWS_READ` bigint(21) NOT NULL default '0',
  `ROWS_CHANGED` bigint(21) NOT NULL default '0',
  `ROWS_CHANGED_X_INDEXES` bigint(21) NOT NULL default '0'
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `TABLE_STATISTICS`
--

INSERT INTO `TABLE_STATISTICS` VALUES('yuigooglemap', 'fav_property', 12, 0, 0);
INSERT INTO `TABLE_STATISTICS` VALUES('yuigooglemap', 'property', 115, 0, 0);
INSERT INTO `TABLE_STATISTICS` VALUES('yuigooglemap', 'icon', 22, 0, 0);
INSERT INTO `TABLE_STATISTICS` VALUES('yuigooglemap', 'fav_place', 43, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `TRIGGERS`
--

CREATE TEMPORARY TABLE `TRIGGERS` (
  `TRIGGER_CATALOG` varchar(512) default NULL,
  `TRIGGER_SCHEMA` varchar(64) NOT NULL default '',
  `TRIGGER_NAME` varchar(64) NOT NULL default '',
  `EVENT_MANIPULATION` varchar(6) NOT NULL default '',
  `EVENT_OBJECT_CATALOG` varchar(512) default NULL,
  `EVENT_OBJECT_SCHEMA` varchar(64) NOT NULL default '',
  `EVENT_OBJECT_TABLE` varchar(64) NOT NULL default '',
  `ACTION_ORDER` bigint(4) NOT NULL default '0',
  `ACTION_CONDITION` longtext,
  `ACTION_STATEMENT` longtext NOT NULL,
  `ACTION_ORIENTATION` varchar(9) NOT NULL default '',
  `ACTION_TIMING` varchar(6) NOT NULL default '',
  `ACTION_REFERENCE_OLD_TABLE` varchar(64) default NULL,
  `ACTION_REFERENCE_NEW_TABLE` varchar(64) default NULL,
  `ACTION_REFERENCE_OLD_ROW` varchar(3) NOT NULL default '',
  `ACTION_REFERENCE_NEW_ROW` varchar(3) NOT NULL default '',
  `CREATED` datetime default NULL,
  `SQL_MODE` longtext NOT NULL,
  `DEFINER` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `TRIGGERS`
--


-- --------------------------------------------------------

--
-- Table structure for table `USER_PRIVILEGES`
--

CREATE TEMPORARY TABLE `USER_PRIVILEGES` (
  `GRANTEE` varchar(81) NOT NULL default '',
  `TABLE_CATALOG` varchar(512) default NULL,
  `PRIVILEGE_TYPE` varchar(64) NOT NULL default '',
  `IS_GRANTABLE` varchar(3) NOT NULL default ''
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `USER_PRIVILEGES`
--

INSERT INTO `USER_PRIVILEGES` VALUES('''yuigooglemap''@''%''', NULL, 'USAGE', 'NO');

-- --------------------------------------------------------

--
-- Table structure for table `USER_STATISTICS`
--

CREATE TEMPORARY TABLE `USER_STATISTICS` (
  `USER` varchar(16) NOT NULL default '',
  `TOTAL_CONNECTIONS` bigint(21) NOT NULL default '0',
  `CONCURRENT_CONNECTIONS` bigint(21) NOT NULL default '0',
  `CONNECTED_TIME` bigint(21) NOT NULL default '0',
  `BUSY_TIME` bigint(21) NOT NULL default '0',
  `CPU_TIME` bigint(21) NOT NULL default '0',
  `BYTES_RECEIVED` bigint(21) NOT NULL default '0',
  `BYTES_SENT` bigint(21) NOT NULL default '0',
  `BINLOG_BYTES_WRITTEN` bigint(21) NOT NULL default '0',
  `ROWS_FETCHED` bigint(21) NOT NULL default '0',
  `ROWS_UPDATED` bigint(21) NOT NULL default '0',
  `TABLE_ROWS_READ` bigint(21) NOT NULL default '0',
  `SELECT_COMMANDS` bigint(21) NOT NULL default '0',
  `UPDATE_COMMANDS` bigint(21) NOT NULL default '0',
  `OTHER_COMMANDS` bigint(21) NOT NULL default '0',
  `COMMIT_TRANSACTIONS` bigint(21) NOT NULL default '0',
  `ROLLBACK_TRANSACTIONS` bigint(21) NOT NULL default '0',
  `DENIED_CONNECTIONS` bigint(21) NOT NULL default '0',
  `LOST_CONNECTIONS` bigint(21) NOT NULL default '0',
  `ACCESS_DENIED` bigint(21) NOT NULL default '0',
  `EMPTY_QUERIES` bigint(21) NOT NULL default '0'
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `USER_STATISTICS`
--

-- in use (#1227 - Access denied; you need the PROCESS,SUPER privilege for this operation)

-- --------------------------------------------------------

--
-- Table structure for table `VIEWS`
--

CREATE TEMPORARY TABLE `VIEWS` (
  `TABLE_CATALOG` varchar(512) default NULL,
  `TABLE_SCHEMA` varchar(64) NOT NULL default '',
  `TABLE_NAME` varchar(64) NOT NULL default '',
  `VIEW_DEFINITION` longtext NOT NULL,
  `CHECK_OPTION` varchar(8) NOT NULL default '',
  `IS_UPDATABLE` varchar(3) NOT NULL default '',
  `DEFINER` varchar(77) NOT NULL default '',
  `SECURITY_TYPE` varchar(7) NOT NULL default ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `VIEWS`
--


-- --------------------------------------------------------

--
-- Table structure for table `INNODB_IO_PATTERN`
--

CREATE TEMPORARY TABLE `INNODB_IO_PATTERN` (
  `SPACE` bigint(11) NOT NULL default '0',
  `OFFSET` bigint(11) NOT NULL default '0',
  `INDEX_ID` bigint(11) NOT NULL default '0',
  `TABLE_NAME` varchar(32) NOT NULL default '',
  `INDEX_NAME` varchar(32) NOT NULL default '',
  `N_READ` bigint(11) NOT NULL default '0',
  `N_WRITE` bigint(11) NOT NULL default '0'
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `INNODB_IO_PATTERN`
--

-- in use (#1227 - Access denied; you need the PROCESS privilege for this operation)

-- --------------------------------------------------------

--
-- Table structure for table `INNODB_RSEG`
--

CREATE TEMPORARY TABLE `INNODB_RSEG` (
  `RSEG_ID` bigint(21) NOT NULL default '0',
  `SPACE_ID` bigint(21) NOT NULL default '0',
  `PAGE_NO` bigint(21) NOT NULL default '0',
  `MAX_SIZE` bigint(21) NOT NULL default '0',
  `CURR_SIZE` bigint(21) NOT NULL default '0'
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `INNODB_RSEG`
--

-- in use (#1227 - Access denied; you need the PROCESS privilege for this operation)
--
-- Database: `yuigooglemap`
--
CREATE DATABASE `yuigooglemap` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `yuigooglemap`;

-- --------------------------------------------------------

--
-- Table structure for table `fav_place`
--

CREATE TABLE `fav_place` (
  `fpid` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL,
  `iconid` varchar(10) NOT NULL,
  `address` varchar(200) NOT NULL,
  `website` varchar(200) NOT NULL,
  `lan` varchar(30) NOT NULL,
  `lat` varchar(30) NOT NULL,
  `types` varchar(50) NOT NULL,
  `plcid` varchar(100) NOT NULL,
  `reference` text NOT NULL,
  `rating` varchar(25) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY  (`fpid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=44 ;

--
-- Dumping data for table `fav_place`
--

INSERT INTO `fav_place` VALUES(1, 'Granada Laundry ', '7', '16105 Victory Boulevard, Van Nuys, CA, United States', '', '-118.483877', '34.186776', 'laundry,establishment', '5ebdee162e4fc526799ec619f9c1c10ced253efd', 'CoQBegAAAGBtx3gRv9w4POcT-UYf89unTa1eTMRlJR7B-QonMAxOk5zXRYVEs3EFhZHvVeaJIwkcTUBwxGGDpAQf9diiqA5WQxzu6J-cnykrfmgDQbkxfmnDccRk4mKwPQMbA6u4vXMK3QZb2q_lFMUmUKuql3Bicfd3a9YVjlZCbd_YaCsiEhDG6u0k4TtgvJBHzDVdRVctGhQm7ZwszKRJpdJxN4vm8A9e39ADQQ', '', '2012-09-05');
INSERT INTO `fav_place` VALUES(2, 'Hows Market', '3', '3035 Huntington Drive, Pasadena, CA, United States', 'http://www.howsmarkets.com/', '-118.09034400000001', '34.127403', 'grocery_or_supermarket,food,store,establishment', '9061d161ec83c51bac750cb18dc4280e8a8a8297', 'CnRoAAAAr_hN97LXMkJ14mAafbv2oBB31vReVwPgiAY0VnvDb79XX0uq3gjncICzRLW5vfOTaYvfHD8_d982WqUKhLqFuT5v_VGg2ND7eqOGinF-sCPKK2iHRcN4MqGUpwRM9hVZ2-OuyL9BhF5N9e27KFnvtRIQGfZfF1RBDIF1zOfX4pfMwBoUCUT4TylqbqnYF0fa8N9nZC3b71Q', '', '2012-09-07');
INSERT INTO `fav_place` VALUES(3, 'Food 4 Less', '3', '1329 North Lake Avenue, Pasadena, CA, United States', 'http://www.food4less.com/', '-118.13339500000001', '34.168321', 'grocery_or_supermarket,food,store,establishment', '29bfa3f15817e9fa592d9fea316bb532ec664fbc', 'CnRpAAAAS25NMcuptr19v94DyAHUtPR7breXaH3rsYyCThm5Dp1pN-eAzOFH7wJOSUVL5GvXY2rQPS-xZxe1SsDEgP0NNyFmJpCn6wvoZsdp3798DYohORAeYDyk1I7Or_QsxA9iJRCRxfJAY5svbVBhXSZ3XhIQ8A0i62rOcH9Y1JAFaMH6yxoUF63PgXp9EDPPtAJ3wybHz2D7Db4', '2.8', '2012-09-07');
INSERT INTO `fav_place` VALUES(4, 'Walgreens', '4', '617 W. 7th Street, Los Angeles, CA, United States', 'http://www.walgreens.com/locator/Walgreens-617-W-7TH-ST-LOS-ANGELES-CA-90017/id=12460', '-118.25738100000001', '34.048', 'pharmacy,store,health,establishment', 'b9bc2a11beab03466f4dccf31267e102820285c0', 'CnRnAAAAiOud4VpTXihyAYqQfBAeqD-LcUgtD2E4-lABihXYwXnOKaJYzpEj36NsN0Fa9Lsy8m9KV3m6sTOm3_ngwQvEOc3BwyUJfIHY_qRVeUEWAieNhWrWDFrmKzDfp1-a1u5fDNpQ1m6dfYFBIlO2RNlbsRIQHon4YYHnFjNnlu3HfsVnpRoU67BHkoG0q2CxXpHIH5Sj6OjWbzg', '', '2012-09-08');
INSERT INTO `fav_place` VALUES(5, 'Farmacia Million Dollar', '4', '301 South Broadway, Los Angeles, CA, United States', '', '-118.24825900000002', '34.050948', 'pharmacy,store,health,establishment', '6bc65d02031112bfbb6fdf4ab669f8e3bb2a4193', 'CoQBdQAAAIGsung6CYSWrsF3jvzk64Za6UTtpwI-5N5oKU4l3HRpeZ30s5vso9ly4l4LxVtCFA0BByJV3a5efU74eExaGqYHLCj_9jpmjvyacRMuV6VmF8-2EDMC6as9G5b2t76WECNCYG9C6m71R8_CB8sQkwd_iw9MNnwOfS8JPvIm-uODEhC4Id7xbQuU803Y1gl4lID0GhQIMO7vfybqLikDUr1vi-DGVB7ieA', '', '2012-09-08');
INSERT INTO `fav_place` VALUES(6, 'Uptown Drug and Gift Shop', '4', 'Suite 100, 444 South Flower Street, Los Angeles, CA, United States', 'http://www.uptowndrugs.com/', '-118.25552900000002', '34.051975', 'pharmacy,store,health,establishment', '74a5ebd282b6ecd004a51c0cfa02acd6cf0a1994', 'CoQBdgAAABF01lCusRVeDH2X5wwPWPIs2A0FXmo4ArtehseCvYE2t3lMuozJXtMe1Ed1EsHIYGxG0jNdYRI65bJZQEGRI2QPTyFSJdRRRQl69zXOKkzBq-b6noGVfsqUngR0Gliu9jgzYD1WMAsR2mP2MuZ1whhqj1y_MMgHft7M2VwSkpiXEhD51J8moyQj85yZmnOqG8SQGhRpttPsyUgfG-lq8DifjI1eSzMbPQ', '', '2012-09-09');
INSERT INTO `fav_place` VALUES(7, 'Rendezvous', '5', '22505 8th Street, Newhall, CA, United States', '', '-118.52808099999999', '34.380096', 'night_club,bar,establishment', '5bc835ffd04707e26653e4c6357df9d3bd616135', 'CnRnAAAAaZXEH_FLzYaVy2zgA8XUBSyTasWsCy5IJfvUjIGX7YHjH99EtoJfU1FebxXANNSk1jCnRBDmMtsNA8RvtcLjDHkPZkUH9AkduKsZM4wZS77YHJcoN9r4peaBGWhg-WLLKVtFMlz88Hr-cbhcBPZ9uhIQz_hjNVLfp1udPb0C-4UFFxoUybUpf8PyfA62JXwUsWqsJuS0jvQ', '', '2012-09-09');
INSERT INTO `fav_place` VALUES(8, 'Young\\''s Coin Laundry ', '26', '9154 South Western Avenue, Los Angeles, CA, United States', '', '-118.30884100000003', '33.952875', 'laundry,establishment', '4416d3c51535cfd97ccbfc327a471b4c76ca916f', 'CoQBewAAAFGgeekZTNqcOicNLosG24yCJgC3_Yz9D9dfvynPyFsp-PMCmJ1sWGX_BH4tt_s3TuV8UxOW_YGZgUKw2jj6WESKNVJ2j6kC_G7BZRlKn1s-cnTBil34EDTYSSXnfRP_3lXN4H9jeNWqY7zBP2T7BkNXIYQ7z888rojkqezJx_jiEhBSmI3MpJjyHXq5mqHQsndFGhQkNuRyxK6t3HOu4b1_PqEheeFAYA', '', '2012-09-10');
INSERT INTO `fav_place` VALUES(9, 'Bubble Bubble Laundry', '26', '303 West Manchester Boulevard, Inglewood, CA, United States', '', '-118.35992399999998', '33.961857', 'laundry,establishment', '4ef46ab631b3472479a65bf32026236462d4a16d', 'CoQBcgAAANRk47rd56Ekhg4zAZ8CqK2fHD17els1xHZTfGwMnvZcLpwcEvtu6jf_GpbPvvR3y4SibYmsusnCeh0sNA5wweNSPqOaeUCoXYQLIAFtKC1-RH-Q8LtK082yld9b-Iy9E3tBIt6RbgmRu7e2iRrJv2GPIteDPGWw_EePTkvIgyTmEhB5A9A7Y4r2elxyOYfGIZU0GhTs7nKY4_ceEQs8-eEubXOfC5kNeA', '', '2012-09-10');
INSERT INTO `fav_place` VALUES(10, 'BJ\\''s Restaurant ', '26', '6424 Canoga Avenue, San Fernando Valley, CA, United States', 'http://www.bjsrestaurants.com/locations/ca/woodland-hills', '-118.59714200000002', '34.187265', 'restaurant,food,establishment', '70c8b04ca039853ad67c480a491f8eafb7d0157e', 'CoQBeQAAALn6hF36_qGlpf0Y3X0pGuM7GHkAFPC-i7s3XFzUOX-WN_kUsnpCL5z0ekvK0bB-muyGH-TaX_91XNh3Z56nGyPd9hNe8MPYcnG53Q8KNNTZCywI7B_OyBsTbwaiKhUnuZv8l9022ApYeBY049WxtFDAyemf4UNN3QS8FV5iIUPaEhBZG_ahB1LiZ_5MCABJpdYSGhTHsmUhvtW-Y7LN-v6kiimKA3CrOg', '3.7', '2012-09-10');
INSERT INTO `fav_place` VALUES(11, 'Palms Elementary School', '8', 'Los Angeles, CA, United States', 'http://notebook.lausd.net/portal/page?_pageid=33,54194', '-118.40785599999998', '34.026678', 'school,establishment', 'fabd4ad927aed0ac495033c8c50eb2c185518aea', 'CoQBdAAAAIV5ElHB69DmO2_P0Z942anC1jcQa5T-kIWXjaXsIXSIf3wyqXOkQ-4QFrYHWAnDRWxcTqM1s4BLkoJFMmmtqqko5nM24aColWsZtmWFrCpt2yyOENKh76B3BgH1z6yMLTn3ktSxzRF6uzZYV5JUcfQ4s59VAQ81OLsWQWS5BUbXEhDLSOD_NnyNxPwpvTK4SDzsGhTTHzedPh2VcCBoiqN9GhaYNi14xA', '', '2012-09-10');
INSERT INTO `fav_place` VALUES(12, 'Mar Vista Elementary School', '8', 'Los Angeles, CA, United States', 'http://marvistaes-lausd-ca.schoolloop.com/', '-118.43424500000003', '34.016122', 'school,establishment', '5ba3143343bb425c44b0f65adf922932dfeed9f9', 'CoQBeAAAANOv1h5PkCJ-o4vI9LpTL58rhP4Ql6zDG3odnTp9ZpVFjry4ve1KrUSfDBSP3jSyuU16UR0liFrqMs_ElSZusYj5x6sRasY-Orto3dPii3bXxiuWRTpKCiWjuPuf1x5EDRrKOh-ddGcYTB9pzuoD69gDDiciDiSEhuo-2qKqkxKUEhANG4s-2LawV1tKiymJbCDRGhSZn6rGVzIqeAOjeCxBW0fFSq7PWg', '', '2012-09-10');
INSERT INTO `fav_place` VALUES(13, 'Marymount High School', '8', '10643 Sunset Boulevard, Los Angeles, CA, United States', 'http://www.mhs-la.org/', '-118.44523400000003', '34.075431', 'school,establishment', 'ed3808bfe84ea01fac047a53cbaa19a21b2969e0', 'CoQBdAAAACdFIzg2qY6EECMA1A2CkKu9fjKDVDEzI45-ByAwNBmf8AxJL7FeFqU5wEGtKUC1sXxwj-RGxQG3yG_v0zD8RlINyiNSyBg4quOsFYHjrCy0ZoRI23ayV5slbkbL7cSJmBoTRIWz_pz9LIkp7E-1nDK7mhIckyVZhoB4mTLzBYvsEhAQXYZ_XyMwxZgNOtQqgUEXGhTDrCVykyTcKWeWbVdmjoDFnaRvuQ', '', '2012-09-11');
INSERT INTO `fav_place` VALUES(14, 'Miken Community High School of Stephen Wise Temple', '8', '15800 Zeldins Way, Los Angeles, CA, United States', 'http://www.milkenschool.org/', '-118.478185', '34.125762', 'school,establishment', '2d0c0bea3201c69920af4d98ce15f79ccc1feb03', 'CqQBkQAAADgTSJyXxAbShgkSbUSEGofQHkdygCEYNzcCE0eQkC4sM4_U_NHQVrXedF8okSpvCMqFyCmcyRWe_-PrHSM387Hx2wrFRH4ILLiT5E8HLggX5eadXLmGsRmuPfosWxkLdDOWlugAih6jhL9AtYqT5AcoaJzgK9HpdZAXNqZi0qKPVhrUkTlk7i8h8g45H78s-ZjdY995vR9GeKApMX4qzEgSEI1nHR2M5EwBoUxqmBqxfeEaFLtpl8ITGXO4z38vANHi0noTqUB7', '', '2012-09-11');
INSERT INTO `fav_place` VALUES(15, 'Giamela\\''s Lamplighter', '31', '9110 De Soto Avenue, Chatsworth, CA, United States', 'http://www.giamelaslamplighter.com/', '-118.58803599999999', '34.235996', 'establishment', 'cc1bec1cc74ef9dd1ac21ab01ed91e08886e8800', 'CoQBcwAAABPKlaaN8hb8ZBNZXLDpFMUPzu-riUSPV3E6bMGI6FxCG7oNkmGWsU8pfOLq_SpRMaIKkFDDnEJ_dCs7yhe_t_xqgdZZpRLSthPm1D9YQO4KGdkby6L0vBDUS9E61oKeD3MDKyDTmS-ONFnIalTX3SxYSzYStVL4TRONt1OJ2fAOEhBiskvMTpvmMZ-G-fpAHARCGhSfz4d38JPiQbMsFoKQ_-inoOTFdQ', '4', '2012-09-11');
INSERT INTO `fav_place` VALUES(16, 'Starbucks', '31', '6066 West Olympic Boulevard, Los Angeles, CA, United States', 'http://www.starbucks.com/', '-118.363745', '34.057977', 'cafe,restaurant,food,establishment', '6daaa76af23aabe5e812660d324a71b59b1c599b', 'CnRnAAAAbDO-4V2Z-TjXYGKUtePsCUliVGoFd57CDyCUTRoWaMq7LjGiXt_i8iwZSOIW9UIYSrQ-jNDs5yJVhI2PjDET6g-lssCS25mLbtYZUnQSmo5htZIURN0l7JcNFm7_zRUIa7Z3NEsYKpAAi3sLR94jPxIQo2UWTPq0XnibciDcuN_TyBoUXnz4OcrvuBcViSBWQoJoGmkLUbo', '4.8', '2012-09-11');
INSERT INTO `fav_place` VALUES(17, 'Toast Bakery Cafe', '31', '8221 West 3rd Street, Los Angeles, CA, United States', 'http://order.toastbakerycafe.net/', '-118.36873700000001', '34.072685', 'bakery,store,cafe,restaurant,food,establishment', '8f616ce688dccc7600231dff309f0b50e60c16bb', 'CnRvAAAAkgjVsfU4ipWFr8qg3qqL5YGDByBES24p-qIKOcl2aC0QI-5-K8nYlbFI5IGrhgyaNAbah26ApBYtKboMgrKZ8ImQZBvKX1tbbHzR2w7C1vDyGaOzK7clTKFHmuen589lJtrnr2L6DhX8Ruh6G9zrNRIQEIYQD9ALwd10WOvIhoWCgxoUcqLXCUX1WsCe16R7OlNE_93II20', '3.6', '2012-09-11');
INSERT INTO `fav_place` VALUES(18, 'Holy Transfiguration Russian Orthodox Church', '26', '5432 Fernwood Avenue, Los Angeles, CA, United States', 'http://www.russianchurch.org/', '-118.30814399999997', '34.095655', 'church,place_of_worship,establishment', '59bc6d71864df4e1779bcb2a5c87e27f1ef39272', 'CpQBiwAAAPCM7SPA2_gqf8d-pgwqT48CPfMTGgPqXKxNt_PyX3KNmfLV1qZFHUd9YVho2wQcQj5A-cFRm_9h_X5sRrO00gwSeuZQgnb9hYlGTags64oFQ5kbOgX19XMEelRXiNsJF9ju-Dke2rn8bsQ7f-EOzooYwDsZjTvXmsy-4HUD78WeqPTheiG8JDNGh759xX0KFRIQEqqEoajcTJaOUpQfZ3HHXhoUlFoBuaNVI82RsWIYmbaRwFXm5Ew', '', '2012-09-12');
INSERT INTO `fav_place` VALUES(19, 'Coffee Fix', '4', '12508 Moorpark Street, Studio City, CA, United States', '', '-118.40563099999997', '34.150255', 'cafe,restaurant,food,establishment', '2796a13ac2f0d52f94c6de5ae89f9784532e3928', 'CnRnAAAAYdD51FL5-ZGAVZsuK5yZPJW3EPoPnxJQ6JBWVKH5TCMlKxIdVZehEZIJWDQKqAwb4eIscjn4UjVb3iu0oDjCYITBiIu659XoOsso5M-2R-FeQkOA5Wl9aOcBlXuh7S_Ax-VXJ6aAFhmBYwoahSK4IRIQnqxMMRwYOLRW1q-DYnR8PRoUUNa4NsB6oEdlA8JzWL71mJg8E3M', '', '2012-09-13');
INSERT INTO `fav_place` VALUES(20, 'Argyle Salon and Spa', '6', '8358 Sunset Boulevard, West Hollywood, CA, United States', 'http://www.argylela.com/', '-118.37223', '34.095244', 'beauty_salon,lodging,hair_care,establishment', '71f6e0fdf55271666b23e5f5b60b69ef6899bd7a', 'CoQBcgAAAGDgkmIN_X57mMnogZH0lUxQ8VV560wne0vBTYmh2Ak5AYef31Xx8wDUCtODDcrINT3bnF2CW1WgrjgOIoKrGwtIJG8-XY7J2C3yYywZ6OjuU8OrYCmMg8srFrOwATmES9RCt69x1S1KOP2s_1yGJ9gBk9CZdnDLog_UBiQ_WQV6EhARMwyIGmaTkqNZa_oD2Jr6GhS4EDOv0X2kcmQQIOFAqI5oHStZpw', '4.9', '2012-09-14');
INSERT INTO `fav_place` VALUES(21, 'Smart ', '21', '7817 Van Nuys Blvd, Panorama City, CA, United States', 'http://www.smartandfinal.com/', '-118.44873999999998', '34.214003', 'convenience_store,food,store,establishment', 'e536faa335e462cae7b5ee1c100d03c86a081c5c', 'CnRrAAAAlMK_8wc721vJ_sXoLorZBjh6CZUTw4VS_w-21QnesNW7nzYxUPsTnwv-wG48epc7uqHUQAvbX5EBn6ZfKnljQ3Rm4hpEfW_xfXb464_hmg5iBGdjLWWoq6z0tGMklz4qTbx8jNMUoh0U6qYGyw2JsRIQKFb609HKirkf1drxeMHh9BoU2pDWgVtD8K1Gsov6PbY_iZUQgj4', '', '2012-09-17');
INSERT INTO `fav_place` VALUES(22, 'Laurence School', '8', '13639 Victory Boulevard, Van Nuys, CA, United States', 'http://www.laurenceschool.com/', '-118.430431', '34.187079', 'school,establishment', 'e0f78253ebd44fcc711ac3903e60051226c6e633', 'CnRuAAAAMFEK7eG2_SPNu4IbnTq7YARhsd5viHUo8cGf1C89jjuRuSlsfW5wm6G36TLfmJS3_v6Nfn2PQhn7xCbCX12dbCPen3hnUxJxcWg0DYdmQ1Y5NT-WhaikrA2Ek1D8q_-_SFz9rJI-2dNJvQSBqk8rnBIQicvnVuseF-A9WuOndT0FEBoU1-osc35_wJ8jo-6ZuDvWJARE2ZM', '', '2012-09-17');
INSERT INTO `fav_place` VALUES(23, 'Mulholland Middle School', '8', 'Los Angeles, CA, United States', 'http://www.mulhollandms.org/', '-118.50702899999999', '34.193894', 'school,establishment', '79f40c61aec876e00dde75553cd537b08ea9b9f7', 'CoQBdwAAAKQ_W0SymDcUDLOZDIjLF1C5Q-SP4RBC_EdazF2fDrMvUMhle_PSQBPmqeF0qBJAjrZUUjE-yXGb0T02r2C4yIqLJKNXflBCGvPsuVSLSEXxqFzANwvAbhiVRpjBNorZlfxywdnrkzr86oISySYLKSsctpUy_k84QFv0QnP7EOdzEhCRQhsFrW6O3f5TlJTp-TqhGhT445EOS9O9Lfi7OXYibhJZiwMuSQ', '', '2012-09-17');
INSERT INTO `fav_place` VALUES(24, 'Parlour', '24', '216 North Glendora Avenue, Glendora, CA, United States', 'http://www.theparlourwine.com/', '-117.86528800000002', '34.138939', 'restaurant,food,establishment', 'c2ee80270c1b7041c3cf94b7b08d0cab63d79555', 'CnRmAAAAv4P1rPdvAYrGNuXs1EQnh5XodMDCpozYonYLESJ72rzATnDGCbyRGm1WZTALmkD_cn6gTZky9gkRJWgMJBWmx5HQ1VONFYuGTEbzF6RY8UX8WMYxcd6-xo9F8BEmw49ZD-FDWAjd0USRtCFFLZuwjhIQKA4q9LcqjNkVmljxLPk_sBoUylnepH3EdsKiQFzPm0nv7Vk7MyI', '', '2012-09-25');
INSERT INTO `fav_place` VALUES(25, 'Chili\\''s', '23', '1371 East Gladstone Street, Glendora, CA, United States', 'http://www.chilis.com/', '-117.83516700000001', '34.11618', 'bar,restaurant,food,establishment', '70da65728b0a784c11d5663c95797a107aa8a0a5', 'CnRlAAAAhRH9uG20BXAtw2CEvdCuYeELDudPsSx2DMIi0Y9cGPz3OU-xr9i47MHIQ8-MiGib64SNyEixD-7BWUE-lS3CIYcU7tCamKsHh9TqxWKEsDMKDl_fjGiZxl-qqngemrPdVomqIKtH7F0NmaV4uyxhgRIQab5_NYeelXWntQtQ2fQmxxoUswYOiHXOAA3qMmO6qvnyUY0MYYo', '2.5', '2012-09-25');
INSERT INTO `fav_place` VALUES(26, 'Bergie\\''s Steakhouse', '5', '16404 Delone Street, Canyon Country, CA, United States', '', '-118.42267600000002', '34.424197', 'bar,establishment', '25b139d8544414905c318cd7bf64283659d11d23', 'CoQBcQAAADM1zj4FH_e2nRWdwUbAq-NnZtkTvUe0Uz6RlKB6GZpiSanHQj_xJJWBg4UosoUFnqr8BSiGXS-W0zmHj-JPH4fUGEnoVTi3QWpg8Z9YIYBvkOGK4W0TN_rZMX6-uBHS-qKCZ-0dQ5sPWkaqSqugW96TfhMJa_hOAcRUQLv5c3YAEhAEali5aUGY6X8-LigPPp6dGhTzTtIi6PFnx6HwLg58h3OD9Y5CYQ', '', '2012-09-25');
INSERT INTO `fav_place` VALUES(27, 'The Federal Bar', '27', '5303 Lankershim Boulevard, Los Angeles, CA, United States', 'http://www.thefederalbar.com/', '-118.37617499999999', '34.167202', 'bar,restaurant,food,establishment', '234abe290922433a9da3aedfed214c1fa2b24be5', 'CnRtAAAAKwtoCrE0B38Nv-ff5qzSEDj9XfWrVv7OhJOxfm6UoAUqDdjTJnzqErb1CbWZE69gVAChHzc1DPOk_IYVoxvi6pE9lGqcCXSDX8tfbr6urn-5P7eYEfB4CMtiVi7yi0gkLwD6R0Bxc8sxrbHmUU00NxIQNcmh8hj5vZgcVm1Mf3U4JRoUDb3D7zY5uUBCjiNi5ON3R1uSi2Q', '4.3', '2012-09-25');
INSERT INTO `fav_place` VALUES(28, 'C S Entertainment Inc', '24', '4901 Huntington Drive North, Los Angeles, CA, United States', '', '-118.17596600000002', '34.087434', 'night_club,bar,establishment', '2e5f6fb40b8bc0aa712090bcddcb1fdbb1e0bb2f', 'CoQBcwAAALgxV2fXA9puoWt_4DNUHk-Q-57I6LZvABz_BI3VwZaS9ClioqfxeE3-jPujLYT-4lJ74TIvxmcwLT1hMdEsVxOYroVGQSahuVUlb5nuShsXZV5qVWaf6EdBLpkEJ2_KQGd-XnbvQSXQYLDDqZPG8tvmv7i6WK_QQEKmwWV4SUYtEhBXpsz7Z06--OmugeaJmpKiGhQpaMCFi5iuRbS3Qfb97ROqCXSpyw', '', '2012-09-26');
INSERT INTO `fav_place` VALUES(29, 'Mulligans Restaurant and Bar', '25', '25848 Tournament Road, Valencia, CA, United States', 'http://mulligans2008.com/', '-118.562364', '34.392063', 'bar,restaurant,food,establishment', '9db9562ed7a0b7b03b8a543e9d4594205e38b41e', 'CoQBeQAAADYOj26LfgPuKVCHfia0MaA3gWTBkbr7TRtsFjOB-wFvInCt8WXgN1kbSOEmG-RQk9An2nQTCnZPECAk-RkdzZYzKqVNNNxRHQbspMGlJubwMiZ0h_vJCNG30UoNo9vyrYKDJWcQIKR4euozCnZClw9CMaC1siDl2m6cC5PlancXEhDhXifptuOyBkIkF-1nig21GhRrpX4Jt_REw3Rma8FvUpa1vIYxQA', '3.3', '2012-09-26');
INSERT INTO `fav_place` VALUES(30, 'Curbside Cafe Mobile Espresso', '31', '15410 Runnymede Street, Van Nuys, CA, United States', 'http://www.thecurbsidecafe.com/', '-118.468819', '34.205641', 'cafe,food,establishment', 'fbfdac52a62bdca24ed630e083c1d5ff35acc65d', 'CoQBewAAAAAmBgGVmVMywePNChUDG6OLYJ8_w53pwRBfRSv20lqkTEHUISU5Vz9gU0yn2Ex4YxI1cFzjGb5uzOddfbUV9DV4o9yoh_qYL6qujlZCh0JMoTcc5mwQG8fBFFxEvoOuUHwmMIM5Dxw3hV8P7j7slgt-WX93pFvZ4S4o94CPzqJ2EhD6LawzQ1hRZgGZbYmoZ-Y8GhTgb7R6ZSzgX2zY8W8CkDZHtIzypA', '', '2012-09-26');
INSERT INTO `fav_place` VALUES(31, 'Cheremoya Ave Elementary School', '8', 'Los Angeles, CA, United States', 'http://cheremoya-lausd-ca.schoolloop.com/', '-118.32063199999999', '34.10612', 'school,establishment', 'cfc1ca8aeab870c283359ac317738567c9cecc98', 'CoQBfQAAAIf2yXSy0coANLfUP0SmE5s8EcWk76aYz4ybIZHZ1vWT_8TrYwXr-5hM2CPL-9BUIy69qB4dfpiNmen1vKsIa6aDriv0GA1y1pzeqvaI5LWEpiBW-DWgMzvDQSpY-XH0BBGDL_JkP-7GQ6VApzWVw5dCtnV5gIX8zoacK0Pv_p_HEhAi0Vq7uHPNMBaaE1_KCpIkGhTX2Crc1dRe_UY0xR2TgFou_6npJQ', '', '2012-10-01');
INSERT INTO `fav_place` VALUES(32, 'N101', '21', '6252 Romaine Street, Los Angeles, CA, United States', 'http://www.n101.com/', '-118.32793300000003', '34.088855', 'health,grocery_or_supermarket,food,store,establish', '4fcb6a5799c173494d84c4549abf2b3ed04c2567', 'CnRiAAAA2a07sW01Q0Fljq2q9ZLoZg7wDVqdfS3VT-5fkZKasEBYt3UCqQrtRbPQ7205GmtXdzo1Xy3Hwk34fzBhfbxIKsfIhc3--8xN9ieGXPrFdAWStEwPc9QfprsVRJtT9Gf5LIPKxaasYypKZ45jxaTAQxIQ85iMNtSUhYh4E6-QMd-bJBoUsqrhL3TfHqkLFVUt9TbfYspUY_Q', '', '2012-10-01');
INSERT INTO `fav_place` VALUES(33, 'Bahama Mama\\''s', '8', '24801 Sunnymead Boulevard, Moreno Valley, CA, United States', '', '-117.229672', '33.938821', 'bar,establishment', '9f348efe5ef722ffe69282c44f9ed5da4c12406a', 'CnRrAAAARiZgZMmHUjOeIORdJkM0Eq8bTmBqFV2jB7VIkk8GZCNUQgt85BSqrGFugw8lBymxOastceFJ3knDeu0cL0CbnTYsTn3fsSfu_ZqYBUTyCc_tTfKA4WJH0ypgYx7rKJS5CIQPC1KSIvV7hx4zpumOXRIQIpnM0dLddhtAgNQyLy8s_BoU5U42ohhmG6cFS6wr-F8NdGIhpZ8', '3.8', '2012-11-08');
INSERT INTO `fav_place` VALUES(34, 'Las Islas Maria 7', '27', '24489 Sunnymead Boulevard, Moreno Valley, CA, United States', '', '-117.23469', '33.938953', 'bar,restaurant,food,establishment', '422e68c5541ddcbdc66831a5f38053fdbef46a09', 'CnRvAAAA2yHm6kONuq-vL1fJM3IvqMTUWdrcqFnDfwZ31ZxsuNufY-nX7c92GVYAAbj5H7WVvemf5f5OmrQB99ybpUDZW_XwOg8g93etGbE205sZLUXwVt0GlTmubuM1d2i3hZX3BavYIj7Fz0btXBihKTVXTBIQ7GrD33c9nRCJPsmz8sIr6BoUVcuMXMqFaoup0asU9_B6HbwniJ0', '3.8', '2012-11-08');
INSERT INTO `fav_place` VALUES(35, 'Panera Bread', '31', '15224 Rosecrans Avenue, La Mirada, CA, United States', 'http://www.panerabread.com/', '-118.00667499999997', '33.898598', 'bakery,store,cafe,establishment,food', 'efc5cfaada86ea48d9980097715847059a94168e', 'CnRrAAAA_68RipAPA4K11-1rj9_nnAzDXw-AVJKspq3VbKDEQKHR5XJO35s5wiKZ5Nclq_e4fwLLN_eITzYBfDjCAgTvL2tDiLm7P0vjL4zyZbHrl9V9bcrLautJB_-Ly4YwSjnNsPYto2H7sunQF-943L2fBBIQvkNqEwsKjrOfsdKQ43oVGRoU2yaodr2-VcKc13NxjPQA2DPNVNU', '3.8', '2013-05-15');
INSERT INTO `fav_place` VALUES(36, 'Tanner\\''s Coffee Co.', '31', '200 Culver Boulevard, Playa del Rey, CA, United States', '', '-118.44824900000003', '33.958931', 'cafe,food,establishment', '02c5fede3538717dc78afd4504b91fc0019d8c46', 'CoQBcQAAAAFHLPR0OS9H7X_DbuogP_SQZFY--Tv-Z5jfaNJYQpNPEuG7R4wDBA-DPR7xnWPSGEVoBXHkcKJg0CUv1lbQ2PwQ1h14bd2s5uYo8tyhZZgyDu1sxJq0i6KyzpJkt77g2fArFfPMhAjNgMy_yV1QqiFCilZxaUWpRK83WBZFbs1KEhCJesUtVmyZ1kZZ_-aHKyW_GhRJjRAixBOCe1F-t8tBOKv_3jenCA', '4.3', '2013-05-15');
INSERT INTO `fav_place` VALUES(37, 'Panini Coffee ', '31', '4325 Glencoe Avenue C8, Marina del Rey, CA, United States', 'http://paninicoffeecafela.com/', '-118.43986999999998', '33.985767', 'store,meal_takeaway,cafe,restaurant,food,establish', 'c4aeee4c7b453e2ce988c2d46329dcd33b18ac46', 'CoQBcgAAAK2Pj1Jnrv72RaDrrIkBxWK8-5UZS6LcBjTBqTf7Rdy1dRcrIEaOlGQhAi8vs7-PPOzC70lcJdDRNTO4pFeWek6hC49rIRT5WeM2DAoo77GX9N6CO-zGEpcVAHZjng73lIKvwreFvqoZ4DWgDa69kVKNqWhmEkbi6rgCsXxIp5X3EhDMbiynv0RmRP_AdUoqEmf9GhQn715AnqLson1evT_DyObMgsJGqw', '3.8', '2013-05-15');
INSERT INTO `fav_place` VALUES(38, 'Coffee Bean ', '1', '19732 Ventura Boulevard, Woodland Hills, CA, United States', 'http://www.coffeebean.com/', '-118.56360699999999', '34.172318', 'cafe,food,establishment', '1b07a549a3a1194927e73666f60ed60ab554aeb3', 'CoQBcwAAANzl8bT47SF-ddhSR2gzDL693HZvgmgkaGgIpYuFHvO8zqLw7jHmVqFjKN-ow1b0pGwKeYmsUrbqD9kiPxrnms35hU6KFauj9cc7fHftzq-NRWtmPshsbXcV8EiFNNjN6njfwjC5XWgSVzjqjljADKGIi9F7oBxCk871va3VsG_DEhDQ_6KKLJ_RKKHMAAYqGOP2GhSmM9Ywz7_W33-AVj9j5xji-ws5WA', '', '2013-05-15');
INSERT INTO `fav_place` VALUES(39, 'Michael D\\''s Cafe ', '31', '23130 Ventura Boulevard, Woodland Hills, California, United States', '', '-118.62969199999998', '34.162932', 'cafe,restaurant,food,establishment', '73709704de04ef55eb62f613cde995d02aa46658', 'CoQBeAAAAMiJumnnMKMtav5mIW2WW0I9YfGBF8vDz8XaQ445kd_bs0g-wFJQo9oIRLEluSXb-f1NU4UoKy6F8goKIduhLyn6vZJSsHZ4m0JrFgOv8njgOUepDXWxBTVcfuf0p6aZBi74vQh5v0o2m4FaNGrAe8frCpcp2g-b0lm-vBCPzGCeEhDRTTgT0PUyplyCiP6PsMhyGhTrKPYARRFwnPMSZb7rqDnBs5rajQ', '5', '2013-05-15');
INSERT INTO `fav_place` VALUES(40, 'The Coffee Bean ', '1', '13020 Pacific Promenade ', '', '', '', '', '', '', '', '2013-05-15');
INSERT INTO `fav_place` VALUES(41, 'Mobil', '1', '25357 Chiquella Lane, Stevenson Ranch, CA, United States', 'http://www.mobil.com/', '-118.56721600000003', '34.378896', 'atm,store,cafe,car_repair,food,finance,gas_station', '30274b70937dd5f905074dda7a767fabc362140d', 'CnRjAAAAdQkAaWm3R8cgKUj1kSxoY5_f0bj2quJe6e5-13niXZJTCF-TdWQwSUn1u2Xq9pLOrd3gqyFmBtmWH37sps1XxDCqxuF6wTfphoPLON40fruPV3oXxSGgDicVirBCrMyywqldTk6BVupubZPyyd-8FhIQCc2SfdIjENjJcIx3J3shmRoU5boywXf9w3vlZqzC3ap8BPlahxs', '', '2013-05-15');
INSERT INTO `fav_place` VALUES(42, 'Mobil', '1', '25357 Chiquella Lane, Stevenson Ranch, CA, United States', 'http://www.mobil.com/', '-118.56721600000003', '34.378896', 'atm,store,cafe,car_repair,food,finance,gas_station', '30274b70937dd5f905074dda7a767fabc362140d', 'CnRjAAAAdQkAaWm3R8cgKUj1kSxoY5_f0bj2quJe6e5-13niXZJTCF-TdWQwSUn1u2Xq9pLOrd3gqyFmBtmWH37sps1XxDCqxuF6wTfphoPLON40fruPV3oXxSGgDicVirBCrMyywqldTk6BVupubZPyyd-8FhIQCc2SfdIjENjJcIx3J3shmRoU5boywXf9w3vlZqzC3ap8BPlahxs', '', '2013-05-15');
INSERT INTO `fav_place` VALUES(43, 'Krispy Kreme Doughnuts', '31', '1548 South Azusa Avenue, City of Industry, CA, United States', 'http://www.krispykreme.com/', '-117.93083999999999', '33.994914', 'bakery,store,meal_takeaway,cafe,restaurant,establi', 'b05b6fca62b155dd270e502f444df20fe2bcb891', 'CoQBdQAAACTOINbricoF7NTw2fXqB0IfZ2ed8C0jRCirCzj6H-acUed4oJHR94CaksP2hH4JrENW9yrH61lHgKQmSzr2pAIBQb4nXoPHxEu6u6nYAEO8ZjwzTLag33fDqcuBsc-pD97g9cYy7xyKCmypBtm5d8wlznzDgOzzYnIWstgDcBewEhAp9EPtc2txKB9Vv0VZ045PGhSW87DWzcDwXz2Ed-5QKBSYkOq3Dw', '4.6', '2013-05-15');

-- --------------------------------------------------------

--
-- Table structure for table `fav_property`
--

CREATE TABLE `fav_property` (
  `fid` int(11) NOT NULL auto_increment,
  `pid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `beds` int(11) NOT NULL,
  `baths` int(11) NOT NULL,
  `area` varchar(20) NOT NULL,
  `price` varchar(20) NOT NULL,
  `iconid` varchar(10) NOT NULL,
  `location` varchar(200) NOT NULL,
  `street` varchar(200) NOT NULL,
  `city` varchar(100) NOT NULL,
  `country` varchar(100) NOT NULL,
  `zipcode` varchar(20) NOT NULL,
  `lan` varchar(30) NOT NULL,
  `lat` varchar(30) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY  (`fid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `fav_property`
--

INSERT INTO `fav_property` VALUES(1, 52, 'Los Alimos St, Los Angeles, CA 91344, USA', 6, 1, '', '', '', '', '', '', '', '', '-118.4994676', '34.2656049', '2012-09-05');
INSERT INTO `fav_property` VALUES(2, 59, 'Victory Blvd & Kester Ave, Los Angeles, CA 91411, USA', 7, 11, '', '', '', '', '', '', '', '', '-118.457448', '34.186656', '2012-09-05');
INSERT INTO `fav_property` VALUES(3, 150, '600 S Spring St, Los Angeles, CA 90014, USA', 8, 7, '', '', '', '', '', '', '', '', '-118.250881', '34.045516', '2012-09-08');
INSERT INTO `fav_property` VALUES(4, 115, 'N Avon St, Burbank, CA, USA', 6, 13, '', '', '', '', '', '', '', '', '-118.3480923', '34.1802978', '2012-09-13');
INSERT INTO `fav_property` VALUES(5, 31, '17621 Pauline Ct, Canyon Country, CA 91387, USA', 8, 0, '', '', '', '', '', '', '', '', '-118.443257', '34.413091', '2012-11-08');
INSERT INTO `fav_property` VALUES(6, 179, '1241 S Greenwood Ave, Montebello, CA 90640, USA', 8, 0, '', '', '', '', '', '', '', '', '-118.123303', '33.989917', '2013-01-13');
INSERT INTO `fav_property` VALUES(7, 41, '20655 Vanowen St, Canoga Park, CA 91303, USA', 8, 16, '', '', '', '', '', '', '', '', '-118.6081036', '34.1937458', '2013-05-14');
INSERT INTO `fav_property` VALUES(8, 157, 'Loynes Dr & Bixby Village Dr, Long Beach, CA 90803, USA', 7, 7, '', '', '', '', '', '', '', '', '-118.1137658', '33.7682237', '2013-05-14');
INSERT INTO `fav_property` VALUES(9, 56, '22893 Adrienne Ave, Moreno Valley, CA 92553, USA', 8, 1, '', '', '', '', '', '', '', '', '-117.263293', '33.917936', '2013-05-14');
INSERT INTO `fav_property` VALUES(10, 43, '17800 Colima Rd, Rowland Heights, CA 91748, USA', 8, 7, '', '', '', '', '', '', '', '', '-117.917402', '33.989419', '2013-05-14');
INSERT INTO `fav_property` VALUES(11, 135, '9128 Burke St, Pico Rivera, CA 90660, USA', 8, 7, '', '', '', '', '', '', '', '', '-118.102705', '33.9690686', '2013-05-14');
INSERT INTO `fav_property` VALUES(12, 53, '125 S Sierra Madre Blvd, Pasadena, CA 91107, USA', 8, 7, '', '', '', '', '', '', '', '', '-118.1018065', '34.1435931', '2013-05-14');

-- --------------------------------------------------------

--
-- Table structure for table `icon`
--

CREATE TABLE `icon` (
  `iconid` int(11) NOT NULL auto_increment,
  `type` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  `icon` blob NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY  (`iconid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `icon`
--

INSERT INTO `icon` VALUES(1, 2, 1, 0x89504e470d0a1a0a0000000d494844520000002000000025080600000023b7eb470000000467414d410000afc837058ae90000001974455874536f6674776172650041646f626520496d616765526561647971c9653c000003624944415478dac4583b6f1341109e5b9f1d635f10148448106890a04a64254d808222522891404850404f414b892869f807bc2414a4880251212a1a48932802d144088524148180029163fbec3b2f3bab9968bd76ee618e64a4d1ee9ed7fb7d378ff58c9da9a92950e228cd91e68d393ecf42a4d290b465cca54b2038169416490b44406444a04d804da50d529c072e01216049e9411a078854961228f595d6946eb165984091c08f0821e6822000c771404a096aad47547c86ba6357292311cdbdad560b7cdf07cff3260dab680be48940497d616ea8300dc3de2528e54e66fafab57005d69b2fe1f3c6ecdce0e0e028b9c117860b06c23084e142f6e02878a63ebb841ed62ed671268c8877d16426f8bdd95cd7c89a746d93705d1d5aec7a4dc0e168377d669360b97b35ec9a9bcfdebe901debae7468b779aab163d3cc3ecc2664cb852b4ec71e7bbffd921da96647f5ccfd76d7b8b420e1f4b8d3b5a7d7e748dedccb182609378addf53bd9dc43512e11b0cf2292be811d7c69d65156165131f03fc4c6d873174466c16e62a752da755416ec7b10ba59a655dc25159b05bdaee23d4dc3bdc882542e88bac1fadd1f790ff4e302efd03eba60f4bc03d337d225928de1f643a0acaac7cbb7051c3be54051153843c705bc7926e1cb47f96f2e482adbaaa65d9a971a9cd7cb9f64df169054a1ea0a38a9fc5a07a85701aabf01367f60a593fa2a6e7359ce5d4a80e53856af498ad28d6f121edc0aa1a96adba32792052f9e8d856f2e970b1857181d8b8f753b96ceb8314efefc040d8ef27d552602c7b3c9023e61862ef56a7854ad5c2e4f62ddbe567c05f97cbee38091e24d1839702dd19baed59fc36afdc94e73832317a3cacd93d41d21668b5dd0e076899a066ecd1c6e50d581ef3491181208be527b8c40e7c8e7681ea9d6766bd6600bb00b38301a5673ea52cf30a148cc479140f0b5c653049f20cb06a4bb35a7216741608cbed1ac3001b4485191a8a8b75bec45c278f38a5ad6b9f5b208f46ccfc1000fce1e7eedf3a1ef372f3a06014f47ad10635fb71f7d304920f872f521763d6364e22aa94f674ae3cce43f46f845f585c07eaed2a8a2482cf25acd11bc1207def35ea07f4862ef0fcb12d8ca7bd56a7541ff2079de38816e99e064d94c2a227691798bb514f0195a63406d93051283a72dc94c123c77ad7f3f9a69c051fe0a300076e6a40d08505ae60000000049454e44ae426082, '2012-09-05');
INSERT INTO `icon` VALUES(2, 3, 1, 0x89504e470d0a1a0a0000000d494844520000002000000025080600000023b7eb470000000467414d410000afc837058ae90000001974455874536f6674776172650041646f626520496d616765526561647971c9653c000003784944415478dac458cd6b1341147f33d9a431d98a1eac05ad5e043d55427ba97af010a8474111f4a0770f5e3d8a472ffe077e81281411f1249e44d082b41445902252db7aa856a9966d924d7633ce5bde94c96433bb29dbf6c1633e323bbfdfbef766f6bdb06ab50a5298d41c695eebe37c1622a486a42dad2f1c02c1b620b5485a20023c23026d026c4a6d90623f700808014b52f7523b40a4b29440aa2fb526755d5946112812f801cef9741004c018032104c871d4a2e21ceaa65d85b022ea6b5bad16f8be0faeeb4e6856892c90270225f9c0f450611286ddf350ca1dcdf4f56be122ac345fc0d7d5a9e9c1c1c1517283cf35170c846108c385ecc15170cf68ef127a38727114675c8b78074da683df9eca75b54ad38e4d128e138596727d4480a968d77d66925072eb52d8d5d7e7de3c131de3aee3d06eab6e849d78cccccd4c42a69cbdc83ad698ebcd97ec386a66543fb9d3ee6ae767051c1f635d6be27e47f2fa5a85a193706cecaedccce61eb2b984c32e0b4ffb0666f0f533b65999db62603bc4c4d87117584f412f318f52bf63db29d8f52074b23c56499754e22988bb8a77f418eec429e8cb05b61b6cabebadf7405a17b8fbd2cd6d8b0b46cf3098bcca13e7d25e444e5a026599315eb8c1e1d031064599d40c1de6f0f6b980b12aeb987bfd58c0b74f626b2eb0c986cc63e7674404a4c65f3e88aeb985cfa26f0b08ca50a30cd8267f5600ea1e80f71760ed176637f1732983b0add27255a504988e63f6da2b295dfd21e0eef5109a329f3d7884f59cb365c698f8e672b940e172ad62f1316fc7d41917c6c9bfdf1001a1fc5c123de76c693959c027ccd0a15a0db7a895cbe509ccdb978b2f219fcf776c3052bc06237b2ea78a97e5fa5358aa3fdc2c6eb055c9a874f304554788d9522e68a872898a06559a3155a0ca0ddf4544124820f862ed01029d269fa359841c9ba559435940b9400546c3284e1daa19c62589191b09045f6e3c42f071b26c40daab380dd52908b4d6d78a1545002d5294242af2ede6e248686f5e91c3ba2abd0c02b1e53968e0c1a9fdaf7cb5e9fbb5734c23e04651cbf9c9ef1bf73fea24107cc1bb8755cf4932b147ead39e42db33fdc7081f940f04e6bc3c461549624e8d651fc12b49e0b1f702fd4392f811332c81a5bceb79de6cf42172dd31025dd7c1c9b2996444ca45fa2dd692c027688c01b54116480dde6f4aa693507dc7f8f7a3d90f38ca7f010600a23ac6e2fb4e4a1a0000000049454e44ae426082, '2012-09-05');
INSERT INTO `icon` VALUES(3, 3, 1, 0x89504e470d0a1a0a0000000d494844520000002000000025080600000023b7eb470000000467414d410000afc837058ae90000001974455874536f6674776172650041646f626520496d616765526561647971c9653c000003764944415478dac458cd6b1341147f33d9a431d98a1eac05ad5e043db584f652f5e021508f8222e841ef1ebc7a148f5efc0ffc02a95044c4937812410bd25214418a486deba15aa55ad2249bec669c37bc2993c9763feada3e78cc4766e7f7dbf7e6cdbe1756ad56410a939a23cd1b7d9ccf4284d480b46df4854320d816a416490b44806744a043802da94d52ecfb0e01216049ea5e6afb885496e24bf5a4d6a5ae6bcb680245023fc0399ff67d1f186320840039562d2acea16eda55884844736dbbdd06cff3c075dd71c32aca02792250920f4c0f142660d03d07a5dcd14c5fbf1e2cc24aeb197c5e9d9aeeefef1f263778dc70415f10043058c81e1c05f7547b97d0c3cac5ea9c71e3c43b683213fcd654aea7d59a746c93701c75b4b4eb1501a64fbbe9339b84969b17839ebe39f7ea89e81af78443a7a3bb0a3b36cceccd6c42b69cb9c0bad6d8ebed97ec0a35fb544fdeeef4b4f3b3028e8fb29e3561bf237973adc630493851ec2edfc8e61e8a7209875d169ef40decc397661c65651e7506fe87d8183bee82c828d84aec504a3b8e8a825d3f844e9661157749c54641d855bca361b8135190ca055137d876d747de03712e70f76d7fee9f5d307c9ac1c415beadb9280c278e4059668ae7af7338748c41512633038739bc7e2a60b4ca62e75e3e12f0e58348ee8230d990f9ebfc8c509beaf1a77722d1dcc24791c802823254950187c9af1580460da0f61b60ed076635c9e7220e6147a7e5ba4af1311dc7ecd54e4a57bf09b8732d8096cc630f1e61a9e6eccc1813df5c2ee76b5c6e542c1ee6ed983ae34253fefc04b529caf725916ace4ecbc9021e61060ed56af858bd5c2e8f63debe5c7c0ef97cbe6b83a1e25518da732951682d371ec352e3c1667183ad4e46a59bc7a93a42ccb6764153974b5434e8d28ce902556ef84611892181e08bf5fb08748a7c8ea610726c97664d6d01ed027d309a5671ea50cd302649cc449140f0e5e643041f23cbfaa45b15a7818e02df683da358d104d0224549a222df6e2e8c84f1e615396ce8d2cb22105a9e8301ee9fdcffc2d39bbe5d3bcb0c02ae3ab59c8f7cddb8f7de2481e00bb5bb58f58c90896ba41eed298c3d937f8cf041f9806fcfcb30aa4812737a2cfb085e89030ffd38d13f24b11f31cb1258cabbb55a6d567d7c5c779440d74d70b26c2619917691798bb525f0091ae381da200b24064f9b92992474dfb1fefd68a50147f92bc000a2f3e9b7a755cf070000000049454e44ae426082, '2012-09-05');
INSERT INTO `icon` VALUES(4, 3, 1, 0x89504e470d0a1a0a0000000d494844520000002000000025080600000023b7eb470000000467414d410000afc837058ae90000001974455874536f6674776172650041646f626520496d616765526561647971c9653c000003924944415478dac458cd6b1351109fdd6cd234dd1a3f6b416b41043db584d643d5430f817af420821eeac5ffc18b201efd0fbcd48f8b4211299ec493085ad0a6c5834a51d0b4975aad8d255f9bece639b39d575e5ed24d62d77660781f79fb7ebf9d79f37626463a9d06140335c21a55fa341f8608548fb5aaf485c520d4c650e3ac3126608644a0c68015d4322bf55d8b81083081ba8fdb2e2615a6b8a80e6a1175435a46128833f811d334675dd705c33040080138f65b529a23ddb2ab108188eada6ab50a8ee3806ddb638a557c0b449940021f98ed8b4d40bf7d091291c1505fbfe86561a532035f7e4ecff6f6f60eb11b1c53714197e779d01f0b1f9c84f6f4f74e90877d17fbe7cc544ebc452653c1ef4c471a5aa9ed8e751296e51f2de97a9f80214fbbea339d8494db57bc86be3af7eaa9a81b378443ad26bb3e76cb30d337d309e9327ed9a85ba3afd75fb22ed4f453fdf86eada15dcc08383d6234ac69f63b9157d74a0c958415c4eedacd70eea1209798b0c762b6fb06fae1eb641c646533e80cfc0fd13176dd058151b09de8a1d4e938280af6fc105a618655ab4baa651434bb8a77350c77230a3a7241d00df6afeb03ef01f5477b7fe3c361cf6deb82a10b064c4cd607485873ba9beb5c904c2661f29609c74e1910c7c4a5efb809af9f0918491ba1cd39f7462193c934b7402e9783c539e12f262960eefaf99d08756e7e7ebec1028233543f035e5b0128e501f23980f555ca6020d439c50584290cac8c92d839887a08d3f1f7e327a7c0aa0e420573d6a3270cf8b12420797873939dce75f765e1e5a71b108944ce22de1aea6f53a9581ccadbbfaece40ae90f529d206247f7e6d6eb093394acb3f666764a4398ce9595cabd163c59e9e9e31cadb97e3cf211a8dd6f96a207e1d06baafb6751f2c979ec052e9e1567143ad4c46d1cd635c1d1166d5620b9465b9c445832ccd0c59a0e2866f7c222d481078b6f88080cef3dd42a61038d64bb3b2b48074813c1865ad38b5b866184512734124087cb9fc88c047d9b22eeb76c5a927a3c0555a4729562401b2481c49a4f0ed169a9150de3c85c3922cbd34024dcb7350c0dd73075e3872d3b7eb170d85804d0f21c0f0f7c2fd0f2a0902ff969fa2aa67984d9c6775784fa1ecd9fec7881ec4075c7d1ec328852416e418fb049e6a05def4e3c4ff90b4fc886996a052decee7f3fe9d8a25f708836ea8e06cd9503222e922f516ab22f0191ed3812ab005da06ef34255349c8bea5fdfb51e9049ce4af000300c96518fe0967fc490000000049454e44ae426082, '2012-09-05');
INSERT INTO `icon` VALUES(5, 1, 1, 0x89504e470d0a1a0a0000000d494844520000002000000025080600000023b7eb470000000467414d410000afc837058ae90000001974455874536f6674776172650041646f626520496d616765526561647971c9653c000004184944415478dabc585d68144910ae9d99cdae9bdd55a38951e13089c688316135882192432f7a1750c11f38953bf0491011141fc5174585e09bcffe3c8906f1de0ee3f9f3a439c47313a38822f8877f81f327ae9b9d9d991dbbda6aed19b3bb33664c41d1ddb3dbfd7d5dd55d5335a1aeae2e601262aa9286a53e3e0f426ca616a921f56d8d40b0ad601a25ad20024a40040a0498679a23c5bea9111002c69826a98d10a920c564aa33cd321d11961104a2045ead284abf699a100a85c0b66d6063dea2e233d42f76b5ed9288f27f0dc3005dd7211e8fb74b56e116081381189bd05f3f5583c6aa284c89aa816eff5dce82076f4c483ffebf3f9148b4901b74457241c4b22c06ae15058fc693b07afb7e50340dba771e84392dcb3c13c03571ed580c3dcc5dcccf99229d780d4d560c3c31bd16b61c3805b39b5250302d48b2716d43b32f2be0da9ac68f9670bd2a6e81e2f6992cb50d0bf98e8524ab67c2db974f213eadc6ff752814040e62863c5d33195cb8e2f5a37b60e4467d13706fd241a0dca91632736e33b740cd9c46ff11c985a19562577417ec6a3ebd73037299f7e3be1dbe235dbaef2c0cf4f5f2fef0e3fb134fe0e18d2be3021cf71948fdfafbf8de4a2e0cc5efa4fab69f7f9c058ac9fbe1e75f27282ad4a53a26d602f7aff739c62d2b3704f68ef044e0d1e075c7b86a761d8423938227502c0e8c8ebc857cf6a3e3d982e5ddc11328750b86aefee5bc0ddd5b27ce0528b72f9f774e64d1b06a565db0b7a05c281eb8d8eb18cf6f5ff5f505559984b5bb7b20124bfc1817a00cfe73ce316eeaf80d16ad5c0f9d7fec06d3c8f3b7e4babd47bfff1a962350b04cb874fcb0e359db9a3fa1617127b4fcb201ce1dda01f1a9d5306fe98a6003912ccfeedee4ea96d6559b604aed4ff0f7b17db07cf32e985c3dcbb3056cca50f9c1f222974e1c61d6b0be79be764f0f4f549e0cfd0bf54b3acb5900316d45aa524c4cc7317bf5104fa1f7e076decaa26a6158ba6e1b5c39d903e90b67c6cc8cadcfc44d81ab49158b8e793ba6ce8d5550362dc7e07472ef46df69395940274c4ec0a01c3d5b5959d98e79fbbd57510887c3cef83fa3029a6b229ec0ee0ceb30f84aff52dc608bc928b9b99daa23c434840572a25ca2a24194662151a0b205af615b8e04820fbccc215007f9dce6be561477699673bb401c8c9cab38d5a8666863246e962281e0b75fe711bc8d2c6b92162b4e39019bfe644b05a4ea228088514622c576971e8b84b4f3141e11517ab9088c599e83046e6e5d94d0c5a2a7873e842402719cc4005ad32f46076512087eeb7916ab9e5632718654a7356d694def8188260aab8845b3aaaaa618090e8c8a7d069e2a073e665ca02f24655f622e4b60291fcf6432ffe18face45e42a023323859b6a478fd08212c214731830137d1180fd447b28067703f04dc24445f737dfdc8fb0147f924c000e5daae0cd3dcb66f0000000049454e44ae426082, '2012-09-05');
INSERT INTO `icon` VALUES(6, 1, 1, 0x89504e470d0a1a0a0000000d494844520000002000000025080600000023b7eb470000000467414d410000afc837058ae90000001974455874536f6674776172650041646f626520496d616765526561647971c9653c000005124944415478dab458d94e233b10754260d8f75dec20f645e1f24084101202f1c40b02fe80afe20ff8041ee0012e61472c020402214062df06080949c8f529b97a3c3de974d0cd9454b2dbe976954f9d2adb710c0d0d09290ea9494a93b53ec6132111a961a541ad1f7129236853a4a62a4d510e3813e4c09732f829d5af14fd904b1982c174a9d9aafda19c4aa484a406a4faa4fe6464d8815465bcc8e9747a43a19070381c22128908f94c2d14635003d74824a645fddd603028028180c8ccccf468a81002c9ca8174f981b7b1b151b4b7b78bbcbcbc842effe9e949eceded89b5b5356f565656a70a43c0a985e047381cfe2bc621981373a7a723c21462e2995363bc0b90fd0de3ba132e17518b434f0e3898ed7acccc820f474747456f6f2f3d17151589eeee6eeab7b6b68adada5aea3737378bf1f171c43a7a3a7c7d71976cc7cd74903129294954555589d3d353d1d3d34346363737c901c8ebeb2bf5b110b5d298c414e63c8fc5eacfcf4fb1bbbb4bfdfefe7e327e777747cf474747e4e0c0c000193e3b3b13cfcfcfd12b92c9862b96772c151515a2a5a5c5f81d4860a2adad2d7adedfdf17d5d5d5222d2dcd08cff0f0b0b8b8b810878787b1918d07fecbcb4b22506e6eeeafaa226b85cfe7fba30f013a781f8ed8892d0710f3f3f373313333636448474787282d2d25c2edececd03b050505e2eded4d78bd5e23ef13c281cece4e313939290a0b0b695228880736a3680195aeae2e7a1721e177108eb1b131313131215252522c6dd886e0e0e0805aa41c7b8f9532f1060707c9d8d5d515290b9c0221913120b01502962100bc959595c60758e9c8c88840b56422727d80e4e4e410f1f4a203292e2ea6710e0fef29b60e80f9e6aa989d9d6d89144aac2ab3bf89acfb46ab87c2d681c5c54582168cf6783c14f3858505034e70c2ed761bef9f9c9c10dc0c735f5f1f7d8fda717d7d4dbba11e8aa81cd0a1f1fbfd44a69a9a1aa3d8dcdcdcd0188a0c975e141d08c2f5fefe4ebf3f3e3e8aeded6d1ac77b2f2f2f1402db3a6066281cc22ae039d28da5aeae8e380147e4f64a690a78919e2c18bbbfbfa771abb26c5b07e0d0ececacf18cfacffc80609578076d79793939c60718c8dcdc9c6d1d88ab1423051b1a1afed81b782ff8f8f8a0d5a23871689878f3f3f3f15742abcd08b51e7063c2a6a6261a03b4f5f5f5e2f8f8980809e33afcb7b7b7e2e1e1212aaafa42e3da0d4148309cd310ac86b4b5b51908e9e3f9f9f9444e90ef5ba5389620c7cbcaca08eea5a5258378bcf90021a4294281e7929292b8b7e3883aa11281ac04bb1d0ca3c5eeb7b1b1619469101563987c7575957641462306025f7c2ce75b4a0893208fadce85d896f5633643ace738fa56398fb951ca65190fb15da7766309e0dc8ea3b3d5569a8863b94220a06c865deaae8633ba2f2323c383733bca677272f26f13a006e8a53796605b4681e2cb0d5a3e8cca307bd4ed0836831c023f5f97d4a581af660ebea0ca09ff456be7048c8307d2509f8a39381691cfe6ab999f11e0103031fca6cba94bdd197aa413ebb19c80f1f5f57518ef51c886945a5d4ec39c0521ad0d689715760088a44a27dc72755bd19cd0568e1f3ef8ea657220eaf55c68c643535353019e747a7adaa1399049ac753abb565656b67527607c7979199b4e9782f84d6940cd19d1e68cbf10a90f19159ed427d3c82d9d20c350f4a571b79df1a87541fd436227662450933365be6fa84af88f32fa5337ae90fd7fc7725388f42a1694869b797394faae1088dbf8771c303bc17d97e9df8fcfef1887fc27c00016519c5858d301390000000049454e44ae426082, '2012-09-05');
INSERT INTO `icon` VALUES(7, 1, 1, 0x89504e470d0a1a0a0000000d494844520000002000000025080600000023b7eb470000000467414d410000afc837058ae90000001974455874536f6674776172650041646f626520496d616765526561647971c9653c000006744944415478dab4587b6c144518ffeddedef5dabb3e68697ba577a5a50a4504ac54a480684263084fa980e81f2a4208f8004d4850245289f10f6262fd8304457924828ab53582a0d26a02d102629a825624425acaf55d68cb5d7b8fbd5b6786d975ef7abdbbc63a972fbb333b33bf6fbed77cdf09656565204d2064e064d4bdd3f1b1680aa10027bfee5d9138087d9a089939993803e2183110e4803e421e4ef45d963810054c2294c29f099ca9b16c32212fa1414203aa645406cc1c3c5314c57a5996210802144501e9b327253a464993aba24445d4cff5fbfdf07abdb05aada53aa93009183903496441bd73be8ce6323fdcb9ca981edfe214905f9b04e5db3bf5c9c9c933b81abca24e05098140e07f01a78dee49f74e4aa21a662a667626e92c5ea2228b063ec354883d699b31db741fd2442bb15e81cb32885bc101fce469c01b7d1fe29aec1c91094992a8ea345c917b8118ae337d4b175370def6111a6c079067b031f055dd3b71cefb073e77d76257df016488a928364dc6d50947f15dd67be478916d38180caaaf0c3ba69bcd499806676e0d92852464de5c86ee601fce7b9b503d74469bf3cec061b4c89da8f35cc4e4b66730dd58884efb71144ab9510d13e17e1e6ed545d2449ccddecb44bcac7b3b2ca2197313eec713dd3b866dfc746f05d65b96a29530f264cf4e5885445cca39c4a4170d438ac65dbd6d1f6a06ef9ef44ace11dc5106f18bf77774066f0d6380aae346a0134e7b0d52040b0ebb4fa1c83891a9eedeb6b5234a78c46053396e2b7c8a1f6b7ade62fd6c311dedf6aff190a908b7eda7d01ee845a6211576290b4d399f225fb291784b8c8cd8568673095cc1216607fd8eefb1ceb21807dd2723e28c68039bac2bb0a5ef03ad3f8f88be2fe842526b195674bf8e0bbe26b2bd44361030959c3451482081c4cc3c83320b166b65ec755563cfb8cda3b381f2c405ec345fb8ebb46f1b93973350dace781bf17cefbbb8e26fc104c3f8900dafcaad782d658dd6afe83f40ec205533c8701b882881b596325cf5b7868c51cb3e39742e66c099662cc01cd334ad4f55d141d445d51053026a7318b28605136acd177c7fc615f5720d99217d6a2fd34d93627b81da5249a0a1feafe49d0df58aec7d71316033a40f5b7bdb73277e2fe827c646ddafbce74d6dcce3f8118f75bdc2dc4dcf50b3dc4e62c0dbdad88bd695d895ba0ed9cee5da1875c541c513db0b54fdb406ba864531cad46cd3d498a77f9084e38e40689cb013955cf65d8fcd80aa1f1adf271b1d21132ff9af6171e21cc413bacffa1ab53e8d053643c6e8e2008df3d4bf9fb22cd4c68eba4fe3616edd0b1266e250c60e16e916981fc0bef46d98659ac2be4d91f270d0f52fd8eeb40de4a6ecd78c3aaa17e83fee771f4765da16ad4f5d3055b460d0518bdaac4a3c9a507cf784828425897371cef621dc8ed3ecdef84bbea19d7e6bf26aece8db1f5f28d6bbc8cbb7dec7b3f64538367e37ebaf489c8fee401faecb6d28eddc14d1085b72abd8b33bf7048eb87f60126a0bf460bfeb9b100cfd41a56837d5ec8e8db83ce13006831ee43957b1b19bf66a3848fc6f95bb42e62e3497c046427072ebe398440cb831e720498383b03bcbe3bf8ec3db15b9058f74be44c46c445d762549e86576e71fcbd83d6ceec7e9db99da1c52369b3ba87831bdfd399629453ba4c88b0696a6d00c38d2359bef5c0d8fe243374b32ecccd2f5065a91fa022612e025e6b92c236af237c3d1561e3135d34920a8a6e56a9522d3749c66afe17921bdff4b3a366839610609cb9f6554b05c8e454cf2eb2596fe2b09d5655daf8e9813d2bd69e26b3018641557d2552c5e9ab7e7d7268e98195ff25dc3a2ae6dff212d37820bc0cb3119037e9ea30f5a2c96d220c9db4beacc301a8d211bfcbdd28fe6a581b8c0f24f1850582d69c50d7daac928517329af8e28a65f9580472d9778d1a09666825aa0920d7fa6cf584c50f0495f1948ba2bcce33aa7a25408707869e60957816a189eb0e254e235430961e262342628f83d3546baaa844b56e6345271ca1850f8244557401ac218a0123113268ac9e91a2231a19e9caca02172482dbdc21888589e43072ed77ee2f1aa9b96ad370b3a06ac741111e5cc822aa551cf0405cfff5280288933b9885d9cbc7c4f45b7677c59316d74215920878f13372a2ea84283da2fa812499167288e051eb182e6ff90c46ae192a0d586d5e572fd463f92927b16071dd08373c9466df1fe09a1aa481fc5fc04b888f7a941b9b904e2061f0d03e14ca8ef52d8bf1fbed180d3f68f0003008968b4b7d79f11eb0000000049454e44ae426082, '2012-09-05');
INSERT INTO `icon` VALUES(8, 1, 1, 0x89504e470d0a1a0a0000000d494844520000002000000025080600000023b7eb470000000467414d410000afc837058ae90000001974455874536f6674776172650041646f626520496d616765526561647971c9653c000003de4944415478dab4584d681341147eb3d9fc981f4583582f564141102da1ad50d45bc0221e3cea41bdd47a11114f5a44d143d18320d483a0b55611c5838820f4e04929056b29c57a11ed1f688b60c59aa6d96437e37bdb9966b224d96c4c061e3bb3d99def9bf7b7ef85259349c0c1507c42fcca9ceed76370144b484e99735d80d035801212121004b43a11c80bc02c4a4608cd4d5d0011601865bdb80605a97a0e13c54049a32c49cd48022101be59d3b411d3348131069c73c0b57d25a17b246b7ae5bc22a2fa6c2e9703c330201a8d76285ab135e01704c2f8c24870cb61886d3d067aa4b9bec75f9e85ecfc2bf8f9e5c5482c16db27cc60688a0982966541a001e034684fda3b1c260bdb26b6fd4c533c5e279535025c25a1ebb66b49d3db0498f476d566e5c6f3ab3e5b6a0e877c5e4e6d6c4f61f6b8a700fcf44a6d249c872c22e0e6d50125307ffda931233930b44aec9ce3f80d6b6d7ebecfaa8b5f78ce74d707f34544ca6e8c67b9d9ad4138e8e2985ec0936d0cba8eac72be70d78285c5f2cfeed9c1208bb92f6dd4d1073adb0b2fdf3957d9090fee6530fc897bf3814aa1476366a1f8fee0655f59674dec6230f299bb46812713cc2c70fb6434de8e7148b6b2a29cd0f7320fc3931c5a763298c56797d2a5a34025e189c0d48fc2fcc19b3c0ac0f626fc98e80c82f845999ce6f0047385dfc3ae9e0834c58bd76e60a41db788f19407ba8f16bbccc95eabeabc511501b72818fa50f8fdde455f5d12515526b83690b7d5d9733f0fef26f87f01568c827226f8fa7d15b4f78ce659c59e3450ce04167e41bb6f5bb031cae0d659cdd6c4ef546d9aa81886957c60699964f5f7a979de181354930dd5792d2628a5012e2a54bb022e3528c94840023f85e1a71627a5880c5cf2b969803039c3ce68034e36a1c4b11c1f8defef6f585d4895f1e26817f87cbe76aa69501635a56331a86ea7d2991e6c0438ed2d3460084c4b17bd1ad5e8e94824d241757b68ee35f8fdfea20dd6359f86f0b6135581a5e79e417ae6d15a734357598ca2993b44774498395d682023db25d134c8d68cc90615371ca6ab1b09025f9e1e20a003c2e6e4631cd7ced62c2335204d201d23e3684e75d133b421898f954810f8caec2081b709cd9a42ca35a7968c0253b91a4ab32209904642482281a71b2f4542397902972bb2f5721028d99e83026ec60f0dad5571bfde77328540945e428096d4d4c309950481fffdd64f5d4f8b50714a8821f6e4ca9ed527227a115f309df7318c1248625cae714ee00937f0927941fc43e29a411d9aa0563e9a4aa5c6e8476cb95b05e8920a2e345b978a489a48cd623904de2dd6e450cb420355837b2dc9541272ae3bfefdc87a01a7f14f80010071499fe7b522fe8d0000000049454e44ae426082, '2012-09-05');
INSERT INTO `icon` VALUES(9, 3, 1, 0x89504e470d0a1a0a0000000d494844520000002000000025080600000023b7eb470000000467414d410000afc837058ae90000001974455874536f6674776172650041646f626520496d616765526561647971c9653c0000031e4944415478dae458bd8b1341147f3b3bf930d99c858888e26123827047301621d86840b1f1c0c65416829d958d2258d8f8579ca795622556f6226994c356f0e3ae11049b335f9bddcd386fee4d6e6e4876b3b2b9083e78eccc66777ebf7defcd9bf7e2349b4d90e248754973c618ef6721426a441a1863c10904af79a945d23c116019111811e050ea8014c7212720042c495da26b81486529a1545f6a4fea8eb68c265024f0a38cb1761886e0380e082140ced51515efa18eed2a442ca2f96c1004e0fb3e789e5737aca22c90230225f942bb70ec0a548eaf012f2f67fbf9dd2d18fe780d3f3fbf6a572a95157283cf0c1714a22882fc1cc051704d5cbb54420f2b17ab386346c47334d93cc04d129cabd0d2ae57041c1deda6cfe625a3d1480f15369b17d0cb47aed2b8c0047b9f2745752619c9c26071ec0e42182c585211b8de7052cd939253aa1878d8ea41ebf2eee387cb0236eebbe3f999932315707a9e260612f3fdddb5113456305956d4fcceb53e5caa79e3dfefdde8c285734b53df7f723b8407eb7caa0578d256dacd177b6282a3d8e0f6d63b7da24007e19e054c120b0fc2998fdc9b8fa37d5f9934ffab5db0883cc067dd05f65725cdff5917c4e681ffc205b1dbf0204ec35489c8f46b96c7b16d014115aaaa800fd002882998d1a584588e63f53a2fc1b5b1f0a51e41e132a363f1b16ec7d2791e2474594e16f00933e2d4ab618dde2b97cb75acdb8bdb6f2097cbed5be0d0f22d289d6acd04d6db7e01bdefcfc6cd0d5e75312add5ca7ee0831034e1618e876899a06dd9a39ba41950bbec76b120904ef7edb40a006f95c285f3366b766036d01ed021d1803ab39e5d433d424890f712410bcbff51cc16b64d990745a73aa08087a48180da46b11408b142589aafcbacd49248c2fafca695fb75e168189ed3918e0e1918b6f7dbde8af77571d8380a7a296b1d5ced7a79f4c1208fefbcb3a763dab64e20ea94f6b0a63cdd91311be285f08edfbaeeb5625894d3d976304af26814fcc0bf40f4962feb02c817598d7e9743ee28fb2e53e4fa03b2638593693e358bbc8cc6281043e4b730ca82e596066f054f58045428fb9f5efc7300d38ca1f01060079476264bd09331e0000000049454e44ae426082, '2012-09-05');
INSERT INTO `icon` VALUES(10, 1, 1, 0x89504e470d0a1a0a0000000d494844520000002000000025080600000023b7eb470000000467414d410000afc837058ae90000001974455874536f6674776172650041646f626520496d616765526561647971c9653c000004514944415478dabc585d681c5514fee6ceccee66763749a5c56a893fd5561f4adad028c4a8b512f1ef4d29d4bcf920e28b4f22521115c517059f7d12b1ada5558a2ff141a12a862046d7a42d8580a08d95165f36ebee76263b3fde3339377b77bb3f936637170ef3b333f7fbe63be79e73cf1a53535390c39066b2d9da39ddefc588a4056c35ed3cb218848e296919b61413103d221032e0aa34978dce7d8b8108d09136c8c73493eae5f0a579d2aad24a4a194520c3e03b841073beefc3300c445104791d1fc9e81ed9baae51d411517fb656abc1f33ce472b9094d9558019b0938f285b9c7778778666f8891615dbdcd8fe5a28199a51cce16fe9bcbe7f3a3ec064f682e48074120c17d0dbc7783e6a4b91d873c1cbb388e33a145bc4592f5035c276159716829d7c7040c15edbacffa35c270dda531b6c0168fe68f6c20d02daa7b92919a30442776dd86f3c81b701e3db6294237956cd2a3d31838f812675819cef73c81ebf39fc03b7faa7f048cf4209c436fc2def5805622ea8a0d8cbf1c9bffcf3c2adfbf87c82b258a01ab5b0c189921640fbf0b6be7689bda1435dcb76e1fc7d0f4d7f0af2ea272ee6d446ef18618d049b455400c8dc0997c1dd6adfb1aee07c53fe1fffd33dc0ba7619836af2d1fa93d4fc31e790862db6e18563a263cf4c25984a52b287f770ce1cae5ee0aac07d7e46b48ed7db65e45ae9d47f5c70f1096afae9173b643486520f8f528c4ea1fdfc25d38ceb299c83ef616ecbb0e410ceec2e0739f61756906d5d90f9329509dfd48568801d8773c2c3fb986f2ccab48ddfb2432073e86c8efecbccc2affc2bdf8a594ff1d0cbf782e8e85ca0fefc3bff2cbc682b0f6d74fa8ca60a218504bae9ddfe36bbe65647760e0c157e05d3c8dd299a352b56bc957812e8dc86c5b9bda5d49b246ea7c2890f9bc1b78c74c68df3929975ebe3d60fcc9cda6127eb0f93c60deb207e6f0dd320017e3eb95cf9f42e47bc9728695beb95ad0f0a330616ebfafae4e42f08d3edbd205a6cc0186edc0baed40df8b51cb4c18ac2ca3f8e9e1ad2fc75b315a95e348ed3c6907bc851b12c28c84d6a5f8b41d5f2ef60f9ce6a68d2ff70831aed03a168ff6ed334b565f48d09c34372be031666071af467bf46a369b9da07dfb379732b06dbb6182a3a3019edf976ccbf6d505035f2c88f5e6868e6b9bd190dc3cc1dd1161d62c56c055ed12370daa353354d29713ced204dd4810f8c9df0d09644cb2cfe33429819b5b335729a05ca002c36d6a4e2dee19c62589f94e2408fcd4a229c131cecafa6ced9ad39840c40f455a0369361120453292c498fcba02813593a87f39c6e4e575d57a351168d99e4303f7cf4cd7f3e8919396a111c8c5512bc4fe138560813ca34810f8f1df22d9f598fb59e2329bc77346da9cc937a5f4a27cc1bfa15099e69824515075f744216eb9c6ba81b7cc0bfc0f498282dfa004b5f2b972b9fc2bfd285bee830c5ad2c11b6bf4e6b6e5ca457a16ab49e0fbf99a02aac20a2406df6863a29350e756d3bf1fab1b01a7f1bf0003003117bee7071192820000000049454e44ae426082, '2012-09-05');
INSERT INTO `icon` VALUES(29, 3, 1, 0x89504e470d0a1a0a0000000d494844520000002000000025080600000023b7eb470000000467414d410000afc837058ae90000001974455874536f6674776172650041646f626520496d616765526561647971c9653c000004564944415478dabc585d6c145514fee667dbddedae1689226dac2668422252171b23c11813eb4f0c0f6268101ed0873ef8a80f1a1349507e1a8dfa40a28931114429a4f25312313131c620a12586b2a0621451417882b660775b3abb333b9e73f7de7a3bacb3b37597939ccc9dbff37d73ce9933e78cd1dddd0d1283d4921ad3d67cbc1ee2937a528bdadab725086f9b48e3529b2401b34e044a12b0403a2d95d7ae2d811830497a93dc364b52f51497d4219d229d509e5104e212fc56d334875dd7856118f07d1fb42fb6ac7c8c75c6afbe1f8aa85f5b2c16e1380e52a9d472cd2bc20331492049370c3ff958339e5999c69d1df575c0f9bf5c1c3c54c0e7072e0da7d3e9a5320c8ea985a0d9f33c026faa3b380bdb64dbc92447588458e499a965bccd2e6b04b84ec2b6857d157a41c050d9aec7ac51522a95d452609bb8c1127cc85904aa65b52ebb07cec34e0f083df8c5c5e81529806186b1ab2413b9225edb700aeb7b8fe1fbef9ec0d0b7dd58bdee28dedcfa9338af4845959a42707c641cb7b41d407b7b026e6e0d9665e6e1c1aef9629d9f7471cf92433587c48ce63660d79e7378e8d1afb1b77f057a5f5884f73ffc0df316ee47fab67df868fbef78a7ef7ef46dea44dbc204d2293b720ed8d572805ddef7f6cf7877db2fe249599e5b3f847d8317ca4f601a78e99513f8f5cc04de7b2b839e67ef102178f9d52c366fbc0fa916fbba1cd049847ae0f0914bc2e5898485a9b11e8c9c18c7e2ce2f0538db505a2894b0ed833378e4f16fca459f88b6242db4debe1fd99357a2bf0541f9f1f4df181c78181b5f5f829dfd7fe2e9558771f68ffcac6b3ccf87b239746c148bee2de7c1963796a27fc772647fb812fa168496bd177befa6ca55b6be95c230365e8065190254b7c3ebb2370caaf9932204ec8535ab3be0bae1af762801055eae60fecc13b3dcd5d182050be2f0e8f8e86507e708b8520ee936aa1208ab03c153674faf9c6da88677bf2e95b05e12b910fdfb0d69e0b7202c04c562a9f11e080bc1e89883f6b6045a6f8efdbff638ec350c23a0aae05ccfcfa91035422a7d8e7dd9a18a0ef80636248ce99bda94e2723bcedd6ba3846d73e32b6704816b6a138bc37d3bb7ce8d20a1da72e90147627a06cd86dc22a7485b7930c9e572c3f1781cb1d8ec6c7f7e5d026b7b9291c0f6ec9dc227fd5333c30d6f55334a61e6c1e432e955d2bc2d3d30adc6253934a8d1cc50032a193ccadb6a24187cc7ae49065a2163ee8b589b667034634ccfd642a012633a309cda7266e82212c7c34830f8ceddd718bc4b4ec1aed4ff1a4e05015f5ee46b03a41520c01e8913890c3d5db61209edc933b47b4d8d5e010215c77368e0ee5783f31d65f4a9556386462025b2d6343bb77f963fa59360f08f3fcdf1d4d3295d9c97ea489bbe66337a3fc037d20dd7bd12966565884456edd39ac133d5c02bd605f987a46afd08788247f9543e9f1fe19334723f2041277470e9d9b97744815f2c6ee08f47918017cb7d4ea849e981c8e0b5100892506b3bf0f7a3500b38cb3f020c002b1ad6e5fed6fdfb0000000049454e44ae426082, '2012-09-10');
INSERT INTO `icon` VALUES(28, 1, 1, 0x89504e470d0a1a0a0000000d494844520000002000000025080600000023b7eb470000000467414d410000afc837058ae90000001974455874536f6674776172650041646f626520496d616765526561647971c9653c000003fe4944415478dac4583d486341109ebcbc2412e3a1c5a160e32f5c9510924239450541c442142cb41341c446052b1b45d1426bc19fc6c65e0b3b4bcf145e3c626121a2360ab6213179e625ef7696d9b079979f97bb243730bc7d3fd9efdb99d9d999d886878781898da99dd4218df17925c4609a264d4963432510bc3a99d6913a89805221021902fc649a24c5b1ae121002ba997ea1ab8b48555274a61ad30fa651611941a08ec0bf2a8a12d2751d6c361b188601ec9e5f51f1196ad6ae86511451fe36954a81a669e0f1787a25ab700b3888809bfd20f4fafa0a2f2f2f108fc72bbafcfafa7a686b6b43d2a18686062fb941532417b8d2e97455c051704e9cdbed460f7317f33853a48857d164d5009749a82a0f2de17a4ec026a25df659b52493c98821c756a0c6625e640e8152515d918c64c2508ab1ab85d4dc05ff9d404562606d6d8d67b5dbdb5b787a7ae2dbebe6e6062e2e2ee0eded0dbc5eafe518283bdf2f2d2dc1fafa3ab85c2e7e8f60b3b3b3b0b2b2c2ef038100442211989f9f87e3e3e3f22c504a565757617777370b8e128d46616868287b1f0e87e1fdfd1d8e8e8e3851bbdd6e7d17c88229737f7f9f9b1a15d3f4dede1e389dceece184fafcfc0c3e9f2fe7597373339f63636303f060c367232323e505e1c9c9092c2e2e72df6e6f6fc3d5d55559d90e7f3b3d3d0d78b8a14c4c4c942620fb676a6a0a0e0e0eb839d19ff7f7f79c889544333e3e0e333333b0b3b303878787904824a0b1b1b13401d93f8f8f8f7876c3e4e424b4b6b6c2c2c202377f29b9bbbbe3abefebeb83f6f676d8dcdc84ebeb6b5e0fe49382bb60606000e6e6e6729ee1445843363535f198c859092b5c1c0e0777d5e9e969cebbd1d1d12c01f32e500bb900f7f3d6d616f4f4f4407f7f3f9c9f9fc3d9d999a518181c1c8487870768696981e5e5e582abff8340be44343636f657074e777777c177f2426b7e1afe5322aad6716c5085ca03a98616404c4391ba141db31656afd5129c9b768f2e7015a963d130e562e95c0d12a22c270b68849956a957c31afd837dd4cbd26828180cf23d2d0b26262cabad0802757676669b1bbc8a6294b9b997ba23c44ca96481a46897a86910ad994d34a86cc21f782d4502c13b3a3a10f43bf9dce0be5614736b961416102e1081913435a72af50c4146e267311208ded5d585c3205956272dd49c7202067d64480da4dd44002d52c748f8d9ea7ee5232156cec4cf34215a2f1381bced3948e0fae5e5a526266579df2611f0f0a855141f3b642232090447c57764e218a946731ad29cd61311fd5058454cfac1aa1c3f9e740218c7ace5f29702cf9b17cc8c0a7d67b204b6f29e582c16c697ecd80e1068540627cb1615ab45a9b0849cc5520cf81bdd6340c5c90296c1cbad8a651262ac9afefdf82c071ce5b7000300c114d7b22f6861430000000049454e44ae426082, '2012-09-10');
INSERT INTO `icon` VALUES(27, 3, 1, 0x89504e470d0a1a0a0000000d494844520000002000000025080600000023b7eb470000000467414d410000afc837058ae90000001974455874536f6674776172650041646f626520496d616765526561647971c9653c000004d24944415478dabc58eb6f145514ffdd3bb3cbb2ecb205a948424051b045b069ac0f84101f95627cc48889c19860f413097e53f9aa86901813831abf1801351292261afd60e23f4056424bc1180855ac3544a4ed5268b7b4bb3b33d773eedc2993b1dd9d291b6f72328f9d7b7fbf7b5ef79c15dddddda021482c23a9d03dbf6fc65024ae915ae85ed90684af69928c91b421209b44c03380559219237cefd8068801b3244bcd759121d5cce19054486e904c049a0908640c78ab94b2e8380e8410504a819ef59585dfb1ccea55a9ba88e16f6bb51a2a950a72b9dc969056b4065286409626147b96a4f1422e87b569aba9db1faebaf8be5c45efdfa3c57c3e7fbf314345864cb0c8755d024f371d9c07afc96b67b36c616d62ed6732e4f136ab2c09b8dcff3eac839f242261dbdab502d36b0222f0f6b0cde61de934c4baf5be8dd7b701cb6ff3efd7dc45465cd2381c3c6f963f4fabebe9f2d95dc07d1d1440e4c09605515806dc7e87ef803f7e07eff851881411daf638e46b7bfd4957c7a0c646c9bd684e8a961fba08aff7eb391d13d1388f7ab5d77f1218bd02d1b68976db3e0bae177ae645b26406caa941bef4eacd49cb57406c6887d8b8592b579d3e897a18f67c61a3c7e54bf08e7c06fcd00bebcdfdc08a568a97c5fe6fac95a949ba527ea97278e7fdf755ca2fb52abc0fdf83ba34dcd024f1924d6914eebb6ff9f74b0b100f6d0506cf0385166d1aefa30340fb66a85f4eeb6f938cc4a9563cbc0d727b3744cff3b469ca5dc607c4633b7c628de627f181ff4cbe731de4cb7ba04e9d2007717df5db144d92e4cc29c85daf40b46faa7f2a45301269400d0f919797201ed90e8ffc823d1ed91cd4c435d2c2139a90fae3b7441a4876e0107bf79dbda4eea7601d3844b3cdf4e969a8be22bc638729fc6a0d351026b1a0134f3cf8a806d7f13df43b44d7160ad58d0dc19be284e668f3af170721285189279fa67ce02e68a9fa7960be747ae820e4eed721f7bd4d9150803adb0fefd30f1644205114cc125db59a76bd13eaca6528724671f70660f59a5b2710db175329ffdaf733b0721590cb435034c4225f2f0ae29a007f0dc1fbfc63c837f6d11624bc6fbe801a3cf7ff99404fec790eead701606c04e29e7b1344b26a0e01efdb63fe09d9ba92889c891fc2b79488a2a1385ea2aaaea28b94241a089390a669d0650a57c0b1171af907eac2392a3e46c827fe5c8806bca02c0fba1487cb71ae5e63d5855caa532242694c9f05712b632e7c2dcb72025c19ea582a5cb773e9cc1f361c13d7a92099022817f00115b72c371aa8184c57506fc8253207710b3726939393c54c26839489f560ec2964b0bb6571ac9d1ebf368d2f4982e686af41314a66e6c684ab16565b3930c14cd02e99a62168cd44d0a0d28227f8da8804831f1dbfc1405b8dcdd9c7143d475b33c674ed900902c7988934a7b6e919ba88445f3d120cfed5f51906ef325db06364bee6541350e623156a20ad0801d648864874d2ee06e62211da7927570841eb152130677b8e10b8f3d3da659560d19dc3e3224420a7bd56ca8e2357a7ce864930f8e15299bb9e0ea3e2b2918a595385d68c9f8878224d70a2ef298c3a89c440f04cf70cded9087ccebc60fe2169983f229ae0563e572e97fbf9476ab91f30a0136170a3d926f405374d14ce6235026e33cfec50534603b1c1939e056112c1bd1df9f7a39a049cc7bf020c006f3af6bf6da66c830000000049454e44ae426082, '2012-09-10');
INSERT INTO `icon` VALUES(26, 1, 1, 0x89504e470d0a1a0a0000000d494844520000002000000025080600000023b7eb470000000467414d410000afc837058ae90000001974455874536f6674776172650041646f626520496d616765526561647971c9653c000003824944415478dabc584d4f224110ed190634881b39e0c50b27b351b34a164d0857c23ff157f923bc73f144fc62831bf5e25d0f5e3406908181d97e9d2ad2b430d3a3e35652991ee8e9f7baaabaa66a9c46a321a4385233a4596d8cdfd39050ea8474ac8d438f4070cd495d25cd110137250253021c491d92621c780404c0bcd41f745d2152694a20d5973a90fac6966102ab045e725df73c0802e1388e08c350c87b7585e237e8ccae611889a8cf1d8fc7c2f77d5128146a9a559405b244202f1f38dfdede167b7b7ba2582ca6bafd97971771777727aeafafcfd7d7d77f911b7c5773c1ca6432f9167008d6c4daf93c3cac5cace2ccd522de83c9be035c27e1792ab4d8f58a80c3d1aefbcc460e0e0e44b3d94c761ca6531e2aec4f47fadada9a40bcf0b8dfef5b3d676e72ee9cc745b52ea55269363e3c3cb4cf4806861bc52ece022c9b9b9be2e8e8e85396fc74a6334d5e2e97c5eeeeeeff2100a0c7c747955cccdfb3d96c24912fc700020f00b95c4e8c46a30fffc31d880f5c13c7409ce866aed7eb7371c0020be0bcefecec5859c0fa186e6d6dcd05dac6c6c6d2b9201165019d849b24e9d808e786d4837091b9210f0f0f73f75196892590341503fce9e9e94bef07cff6143c3f3fcffcfafafa2adaedb6ca05cb8e1ce6a7ea829b9b9bd9b9c718e008b6453ec73ccc499c07a25c805d5f5d5da9c57977954a45913077de6ab5d4fc545d0041f63b3b3b53018960435ed0770d829813f732d237ea25cd84bc33fd0d087010b3d975a40b92c86030480cbe2c158754a1aa0ad856eeefef6766b705372c30e5b29cbb9400e538aa579bba10a7e0f4f43471658cc23793c9048ceb6a1d8b8fba1da53326a62d5c9693057cc29c78d4aba1461fc8e8aea16ebfbdbdfd70bcaad5aa3a7636d2ed7651ffcf9a1b5cb918956eae517704cc31bb60c8ed12350ddc9a39dca0ca05db7cf6e3c0111712a84e3e478c85f2de6ccd866c01760107c6d0684e3dea19aa9244278a04c03b9d0ec0ab64d980745973aa08843429d41ac88c4100165995242a7277dd4524b49de38f776ebd0c020bdb73a18107c7c7c73e2f7a7272e268040a2a6a5d77fff2f2f2af4e02e0171717e87af6c9c43d529fd60cb535ed13113dc856e14507f218552409050cc5588257e2c017e605fa42129b3f0c4ba0952ff47abd3ff853b6dcbf09f44d0727cbdabf8c623eb104c6178fb104fe49f708a83e59c01a3c51516a90e0b1677cfd18250187fc136000295cbcbf498a8a730000000049454e44ae426082, '2012-09-10');
INSERT INTO `icon` VALUES(25, 3, 1, 0x89504e470d0a1a0a0000000d494844520000002000000025080600000023b7eb470000000467414d410000afc837058ae90000001974455874536f6674776172650041646f626520496d616765526561647971c9653c000004164944415478dab458bd4b2341147fd96c3e8cf1c022a8a0e2177885e688170bb9368d829da5ad826065656de17fe05f20166265a185d81e692e1c51110b5111b51041919864938d7bf386f7c264cd6e36baf7e031b3ce647e6fded7bc672093c980a080e020714899e3dffd204b708db8aacc2d9d40700c0b8e12874900cd2701de09b022b84c8c73532720048c09fe46638484f2934cc186e0a2e057d60c0b1025f084a66959d33421100880655920bee5888c7f43aeebd5b25c11d5bdd56a150cc380783c3ea368456a204402c4c40fb2f7f7f7707373036f6f6fbe5ebfb3b31386868650e86c57575792cc60688a0922b55acd115cbdcd6708cfc4b36331b4b034b1f4334df1781d419c6ede4add5e85d075e95a6c7a294080bdfdabb7f4140eefef3c95d89ec2acbbbb1b72b91c148b452897cb75a75419d74aa512e4f3794824129e1c13eca1e6a4e68d8d0d989a9aaa7fcfcdcdc1c3c30384422140bf19181880fdfd7db9964c26617373139696961c4da90aa17b71b4bebebe86efc3c343578d8950f36c12bd1dbb6d6d6dc1c5c505f4f7f743474707140a85ba633d3e3e422a9582e5e565d5cefe08108944e4b8babada722f0a80a6f1ea039a171fc06cd80eb945931d43fb1fa1e62680ab069ca852a9d4d3a91b45a3517bacb7d480de8e00e7e7e7707070d070137eb4301ce7e7e71bf6fbe6840c363838082b2b2bbe9a4bf362bb70382cc7e1e16198989868ba677272124647471ba2a66d0d384501db1e5f33273a3b3babcf31477c4a034e84b647babebe86bbbbbba67b70edeaea4ace6f6f6f3ff7163899607d7d1dc6c7c7617676d6f1602c36908e8e8e606d6dcd5f136029850fd0e2e2a22cad7677773fec59585890b6dfd9d9712f8fdd1e23b7a2637a7a1ab6b7b7e51c9fe6cbcbcbfa5a6f6f2fecededc9f9c9c9099c9e9efa9b889018100b56bb1f3c3d3dc1cbcb4b4bfb3b25228b2a54d79cfffcfc2ca3010fc0a2a4a1de1642f5f4f4c847a85531ab6800312d4de9524c3cc89e6e559571d5e3942d5b81e3d99831a94790b89ad2b118e86ce8cdcd845005e1ef6651e314495c96d3ba4198359d7a35d469516c9a110f49369d4e7f78d3d1073811b9392bae211066457e2770e4074a987986ba23c4aceaa48132b74bd434706b16e006551cf8bb5536e47c30323282a0bf482396b4b5a6d95bb3326b804dc08e51b635a73af50c6921c41f3721107c6c6c0ca769d2ac49ecd49cd6380a4c653494668505408d4485102971bbbfcd84e09b0b4a092e71eb6513a0697b0e0ab8797c7c6cf0a1994c26a00810975eab693fc4ab9857854070645c231517880d3ad352cef49e88e887ac153eb4180c0653f8343330ce45659c6a05de342fd82572da67d304b6f2715196e7a80ff849a0af2a3869f6eb15916222358b5505f077ce43d87b92063c83b723805d089eebb6ff7e54da0147fa27c000e241ede975acd9b40000000049454e44ae426082, '2012-09-10');
INSERT INTO `icon` VALUES(24, 2, 1, 0x89504e470d0a1a0a0000000d494844520000002000000025080600000023b7eb470000001974455874536f6674776172650041646f626520496d616765526561647971c9653c000004de4944415478dabc584d28846b143ef3cde7277f717559297fa1148985714b4252285628c4c292b252b2b040898564417e16ca46514ab140a18b722576429464c1f51763c60cef3de7f4bed367ee30a3669c3a7de79bf7e739df39e73def39632a2d2d052413b259729041a6dffd4102f95db2c3200b5d82d03318395472b05440f393021f12f00dd9269964a72e8108300c394a3e43a452fe2427b21dd98afca42ca3140895e07f6a9ab6e3743ac16432811002f09d9fc4f41bb1cbae427c8b689ceb7038c06eb743444484c56015b6409054200c17ec5c5d5dc1c5c505bcbcbcf8f5f3c3c3c32131319194de898c8ccc926eb06b061784bcbfbf07049c88f6a4bdc3c2c8c3ec628e33cd10f13a992c10e04625749d434bb99e1530a96837fa2c50f4f1f1a144c6d6e097c9fd233f29e02daafd9291dc30f4efb433524a4a0af4f4f4b04cc1dadcdccc321e2bb8bcbc84909010b8bebee6793f219f93cdfdfd3d141515c1e3e323acaeae424343836bacadad8d9f53535390959505474747fe57e0eeee0ef6f6f6a0a6a606828282a0acacecd338fd161c1c0cc3c3c3505c5cec730ce8bec60099b6b2b212f6f7f7e1e4e404eaebeb3f8d1f1c1cc0e6e626582c1656e4edededcb18302af1e529c8cdcd85f3f373b05aadcc878787b0b4b404151515505d5d0d090909aeb9939393101717c763369b0d9e9e9e78cdcdcd0db4b4b4f87e0a14555555c1d6d6160c0e0e72e6a277b3d90c2525259cd3676767616e6e0e3a3b3b3930c91af9f9f970767606b7b7b7f0fcfccceb1a1b1bd9252a783d5a19eb8158e434e47c04a05181d12c5a5b5b85bcc7f9bdb6b6562c2e2e8af5f57581261608228e8f8fc5ebebab282f2f17bdbdbdfc4ef3315e84da0b8352a0355c7bd1ef842531633d5a2036361626262658eeeeee86e8e868f63f1db58282028e763a72696969303030002b2b2b6ca5a1a1215e333d3d0dfdfdfd2cd389a0144cd6f37a0a3ce5010aacf4f4f4ff99707777974f86322fb9262a2a8ae5aeae2e565811b98fc63d91c74c4889054dea52807c494cd1bdbcbccc725f5f1f0799a2999919686f6f67994ec0c2c202cbe81e5e47fb785540119df18e8e0e181b1b838c8c0c3e11e87bc8cccc84baba3ad717d3972a1a1919818787073e39041a1f1fcfd6999f9f87a6a626dff2801aa4684e4e4ee6c5dbdbdb0cb6b1b1c1474f9d6f9ae34ed9d9d9303a3a0ae3e3e3101313c3730a0b0b39777c9998281229ee90ffa06a656d6d2da0971105237e28956577c8fffefa6de85322facdeb58930982cb14aa807fd1028429344397e2a4729caad74011ed4db584ec11185733742c76aadba9740e8412aa2c9716b04bcc775df66a54a35b7192058bc69dbcbc3cbedf8d747a7aca65b52f4440747dabe6869eaa1845375b647744980e5d5ac0a6da25d934a8d6cca41a54dcf06f7a7a5382c0298720e85fd2e77c0921b07b6b665316502e508161736b4e75d933e4a112ff7ca70481a7a6a69298272deb94fc5573ca0a083949181a48b39b02649150542207bfeec09312eacb9172905f55ebe5a680c7f61c0ce04e2c38ed865ac164502082a356d3b29392920e8d4a1038318d49133f4bb6cb3d85614fdf13915ca8aca236b5e2f59a834ab88049c6962bc71bf85777814ff9c3cd1274f1476055b42f7b835c09fa64049796f54b59ae2c61cc620e04ce90ef14502fd2023e83ffa82f705342c9badbbf1f6f3f0127fa4f80010062f25867b867e0ad0000000049454e44ae426082, '2012-09-10');
INSERT INTO `icon` VALUES(23, 2, 1, 0x89504e470d0a1a0a0000000d494844520000002000000025080600000023b7eb470000000467414d410000afc837058ae90000001974455874536f6674776172650041646f626520496d616765526561647971c9653c0000043b4944415478dab4583d482341147ed96ce25f3c2b2b41fc2baef14e3108f12ca32816568220882058888268656525086221565ad95808a2208a8222889c01b9e33cac04411104411014ff36d9b837df3013e6f6b29b8dc93d78cc64b33bdf37efbd79fbdefaa2d12831f131f50b0d28735ccf87584c934213cadcd20508c620d342a1414140cb138177011867fa261473531740002c66fa498c0582543ec5646a307d61fa282d2309140af0724dd362a66992cfe723cbb288fde62314d7a029bb5a962ba27a6f229120c33028140a4514ab700b04048162f640ece6e686aeaeaee8f9f939afdb2f2929a1aaaa2a908e9596967e116e3034c50505c964f2bf8043b026d62e2e8687b98b799c694ac4eb30990a3e3232424d4d4d7925a1eb3cb4a4eb39019f8c76d56790f2f2723a3e3ee644f225efefef72cab15d8fd9f4f4349d9e9ed2c2c202cdcdcde585807d937f11b047753c1ea7dede5ebabfbfa7f1f1715a5c5ccc3d23d93074377690cbcb4beae9e9a19d9d1d1a1a1aa2eaea6a7e4d15a738b9bbbba3bebe3ebe0127f1946c0e0e0e68626282bba2adad2dab1dafacac506767676e04202727279e4163b1186d6f6fd3dada1a9d9f9fbbc680eee61f55607a2741acecededd1e6e626d7dbdb5bd718504978b6801381b1b1315a5e5ea6878787dc4f413604b06bc8e0e0200583c10f9f820f13e8eeeea6c3c343aaafafa7adad2d2a2b2bfbd0b1f44ca0aeae2e354772dadddde524109ccdcdcd9c445151516e04d2e50188dfefa78a8a8ad4ef9999193ec2ef3862676767d4dada4aebebeb3c2740715c070606f8b36ee2e914545656a6fc7c7d7dcd8f97142499f6f6763a3a3aa28e8e0eaeaac03ac3c3c3b9b90004a4cccfcf135edbaae0d8f5f7f7ff75edf5f595bb0959530d52d73ce0e402e97f987c696929ed3d0d0d0da9d30197b4b4b4a44e8ae7187072813c01007f7a7a4a7b4f5757171f575757696a6a8a229148f62f23270230217603f33b890cb6d9d9596e81bc26a2c9c949fe5a46bde824a3a3a3b4b1b1e10aee94882c51a1f20a389d20e8b0b89b5c5c5cf0576f16a9189896a6742926ca7154af1f15447ea6ca589c2053e26a4ac762a06e47e99c0b894c65b9b080213093bae8d550a3bfb09b22ac688c85c3610a0402ff981865b51701506d6d6daab9c1288b51e6e688e88e8099d08505de64bb249a06d99af96483ca16fc8e31130980d7d4d400f49bf0b9c57dad69f6d6ec4d5a40ba4006c69bad39d545cf1066247eb89100b8485a61615953a85373ca0958e2264b6920fd3602b0482123d1c876f72b1d09b973268d8847d97ad908a46dcf490137f7f7f70db968341af52904423c6a35ed2bcb8cbf55120087e23f61e227a18658d352d6f49e88c483d22a72d11796f51a919e2530e6ace56acc049e362fd81939dd67b3045af9107b2ffcc49face56e12a08f2ab8b0acf77a20c32716d3f6c523c1803fcb1211bda7b08067f0acaa621b0939d76d5f3fe2d98043fe083000dae9e9a5324a4d050000000049454e44ae426082, '2012-09-10');
INSERT INTO `icon` VALUES(22, 2, 1, 0x89504e470d0a1a0a0000000d494844520000002000000025080600000023b7eb470000000467414d410000afc837058ae90000001974455874536f6674776172650041646f626520496d616765526561647971c9653c0000032d4944415478dac458bd6ee240105e2f26b1f83989a09352a4204071d59dd0d14469dd409f2e79092aaa48b4a9f20e79072a1a8a13cd9d4e275145919286922680cfc686bd99d52cdaf8f833c164a4d1aecd7abf6f67667767306cdb662006688234a9f5f1fd3e4480ce487dad2f4c02c1f608d4223d22027c4f04e60438057549b11f9804848029d04fd41e13a97d4a00ea813aa0afca328a8045e09f39e7bd20089861184c08c1e059b6a8f80e75615721d622ea637ddf679ee7b14c2673a159455a20490452f0416f3018b097971736994cf6bafc743acd0a850292ee65b3d9afe4068f6b2e389ecd66b180a3e09c38772a851e962e9671c6b58837d1647180eb244c53869672bd2460a868d77d1697cce773d595d89c1d58c28b7c43605354a30c87c3c5ae08eb743a65ed769b9d9f9faf3e9142187c1dbba8924c2659ad5663fd7e7feb6f763e6c1cc761ad566bf17c7a7acaaeaeaed8d9d9998cf4878707767373131f01d775d9dddddd9b778d4643ba012d51afd7e389814d321a8dd6df4aeb62e0bd727d7dcd4e4e4e64fff1f1712b0becec825c2e27778412cbb2d4292757d96c36575a402761be673fabd58601eeefef59b7db8d7717e0edd6e974fe3b236e6f6fd9f3f3f36edb30ca3980c1b62ad2a3c8de77c1bb087cf85d7088dbf0c35d10c630a312c8e7f3f1b9e010b2ec281694a1ca0cf880418898826b554a80e93866af7109ce8d892fd50812976b158b87793ba6ce719050693959c023cc9949b51ae6e80e0cba80a4b157ad56e59daecbd3d3934cabb711042a954a8be2065b958c829b2fa83a424cdf240bb8aa5ca2a2419566862a5061c21fd86e2281e0c56211412fc9e742fa9af37069e62a0b2817a8c07043c5a94935431548fc5c4702c1cbe53276ab64d9807455712a09081a24b4023211228016b180440556f77b1909b572900ae85f557a85082c2dcf99061ec015eba9496ddb3634021919b59c7f83b4fb8f4e02c151f13732f198d4a3398536e7f607117da8aca2267512894405737f058c7d28b92a9bc0979e0b6146abc6852c81a57c663c1effc21fa1e4fe4ea0af3a3859762f1991b2847e8af900fc859e31a0266481adc1a3a6643a09d53743ff7e4ca380a3fc13600019f37503693b12d10000000049454e44ae426082, '2012-09-10');
INSERT INTO `icon` VALUES(20, 3, 1, 0x89504e470d0a1a0a0000000d494844520000002000000025080600000023b7eb470000000467414d410000afc837058ae90000001974455874536f6674776172650041646f626520496d616765526561647971c9653c000003384944415478dabc58cd4e224110ee690631802b1ef66e4c20ab216bc872215e790313dec0a7f20d3c623cf0001b1531640389471fc168f8998181defe3ad5a6b71d666099a192ca34f3d3dfd755d5d55538cd66934971a46648b3c618f793102175413a37c6c225105cf7a4ee93ee11019e10812501cea47aa418072e0101302ff51b5d73442a4909a4fa5227523fb46534817d02ffce39bf0f8280398ec384104cfe565728ee413fed2a4424a2f9ee7c3e67beefb362b1d830aca22c90250279f9c17da55261d56a951d1d1d25bafcb7b737361c0ed9d3d3d3fdc1c1c14f7283cf0d17e4168b452ae010cc89b9f3797858b958c5193722de85c9d2003749b8ae0a2ded7a45c0d1d16efa2c2d592e977aa8b039dbb1d88bfc87405c542792912c0c1ec56e17b27317d8129bed6ab51a2b97cb2b9fbfbfbf2bb3964aa595efdcdcdcacb4b21b1703c7c7c791040f0f0f378e019344ac0bb2d9ec56261e8d46ebef8255e6431e5f57e092f178ac14b97f329944ee82b54e3ce470c442d8ea5e5e5ed8ebeb2bc319824cf7f8f898fc2e0803870c0603767a7aaac620f03fdb38360fd4ebf5d00fdbed363b3b3b63854281b55a2d96cbe558bfdfdf6e1b86ed829393932ff710139ee7b14ea7936e22babcbc0cbd7f777797ce59603fcc64325f26c0ca67b3593aa9d876c1743afdf2c1f3f373a28751640cdcdedeeef638de85841dc7822a545501efb02001a6e0469712a01c47f59a96606e14bed423285c6e742c3e7237d26e1a2474594e16f00973e152af861a7d22b35a03753b52ac7d0a2223ae4ac9b62023ca793e9b1b5c75312adddca0ee089873972ce0e976899a06dd9a39ba419513fe8e3a174cf06eb70ba00bf2b950bee6dc6ecd3c6d01ed021d189ed59cbad433d425895e140980f77a3d80d7c9b201e9aae6541110f492301ac88c450016d997246a7275fd3012c6caf160aa5b2f8b40687bce0cf0e0eaeacad7935e5f5f3b0681a28a5acecfe599ffc72401f0878707743de764e211a94f730a63cef513117da8ada2279dc833a286c203c0508c25782d0e3c342fd03f24b1f9c3b2045af9a2ac88d4c1205bee5f04fa61829365b72bcb2d1799596c2e817fd06f04d4982cb036f826046c127aec5aff7ecc360187fc1560002d4984e33b4f216e0000000049454e44ae426082, '2012-09-10');
INSERT INTO `icon` VALUES(21, 1, 1, 0x89504e470d0a1a0a0000000d494844520000002000000025080600000023b7eb470000000467414d410000afc837058ae90000001974455874536f6674776172650041646f626520496d616765526561647971c9653c000004834944415478dab458cf6f1347147ede5d3b8eedfc1209bfa41638a0722951540e445c909a0a4139544214b820a1724582bfa145554f3df03fd09643458016b93d140ead55410ba85021502ba804888434601c67d7def5f67d9337e9b0ecda9b603fe96977c6b3f37df3de9b37f39c999a9a22960cab2d9a35ded1df0d095903d1a6f11e3a0282678e352f9a1302569708b404b0c1ea8ae2dd7704088005d64179f609a96e8acfeab1d659abda329a405ec0c72ccbaaf8be4f994c86c230246eab27147dd065bb86615b44736cb3d924cff3a8542a4d1a565116c80a81027f50c9eddc49a5ddbbc9deb0a1abcb0f9e3ca1c6952b345b2e57060606b68b1b3ccb70415f100494eb0138047362ee42011e562e5671661911efc064bd003749388e0a2ded7a4520a3a3ddf459afa4d56ae95785edf40ae89dfe7efa74d3a6e5f6978f1e51e5e5cbd716f9ca3eef14d569c56290e3ebd6bdd2f7c9faf5b1184ed2b67913d9d2d7476fe7f3f4f5ecacca3e58e59ff57aecd858179cdbb6ad2b44be9d9beb38269640a55aa5c9c1413af7ec994ae283b64d7b4746e8a7172f6886130a56747074942ecfcf533508d43707d6aca1fb8b8b747361818e8c8dd19d841547adecc4c5c0773c31085cafd5e881eb523f67431098e6153d6e34d4181028f338dd9e1a1aa25f39c8bee73e10b8c544624f25c9a86d2d708f57729b570090b33333349acdaafef1629186791f6765820f98d4350685e498e45becfbed3c06a289adc802a67cc501749ab7d1bb4b994bc9b148647fc804a05ade1f1e560af9db75576f0188f62786229a3fdfbc59ede5bf78e222c7c417dc864b7e7cfe5c8d3fcded1fd8fcf86d1f93fad7f7d36dd9763f220861764c0a79ca018820fcc7f3547b8e4166a4cfe795d539cb8db28b7ee7d869a5cc29563bff3ce4d562f2c31c54b4745890cd5a6242758e7eb4a12a26187088fbb772064cda011db761344b35b97d96cd7f72e346d5fecc48ad90a36bd72ad5f2116f45ccf0c76a09c4c92f9c13306981a3dc6313634ba20d9323e5dafabec56db86a962df62021003bee82a4547c4a2cf0f1ddbbc9f122d9b3dd988e311077187dc313635268528a4e3326096345a761fdffb37cd5635227222d878c55259937cd9876892894385237e03849e3d7b4be37c081195a4695e2e33a8edb6baf0473074ba7a7af712da362f1706fc7d5b91724f4b55c2ce00966e048ad868d5b2f168b93b8b7e7af5ea5ac9c805af2fbf753ff9e3da9c016cb655abc7871b9b8c1535f46d9cd93521d01b3e988055c5d2e49d1a04bb38c2e5079c29ff1ec4402e0f50b1700b44b7c1e2a5f5b56b43473b505b40b7460b891e2d4919a610793b8de8e04c0dd4b9700be432ceb8b2615a781de05bef1f48c6245138045f24c62825777238e84b1f2093475e91521105b9e9301ee8f9c39e3e949e74f9cc818044a2a6a2d6b7c617afa964902e0b5f3e751f58c8b896ba29ecc191a73a64f44f8903f78ed6661dbf60493b8a1dbfc0ef0894ee0b17941fe21e9983f229640295faad56abfe1472eb9df13d0aa092e967db3e338e222338b3519589f3c08a805b1406af095108892d0ef4ee4df8fc64ac021ff09300057791da47e3fce0f0000000049454e44ae426082, '2012-09-10');
INSERT INTO `icon` VALUES(30, 3, 1, 0x89504e470d0a1a0a0000000d494844520000002000000025080600000023b7eb470000000467414d410000afc837058ae90000001974455874536f6674776172650041646f626520496d616765526561647971c9653c000003eb4944415478dab4584b4f1351143e733b2da5b48804c5577c8b181482e2a35163340d1b97ae34ee4c58f9075cb830fe055de8daa00b172e7c9ba8316a0d014a454541028a3c2411116ae9b4338cf75ccf2d9706e8f4759293b93374eef7cd77ceb9f71eb4502804dc34ee2e72b732c6e7c5309bbb459e52c6b64e2078f570f7927b88002b128179024c724f90e3d8d40908017ddc2be95a46a48a692677837b9cfb8c544612f012f81ac658d8344dd0340d6cdb067e2faee8f80c3dadab6daf88a8fe36954a816118e0f7fb838a2a42013711f0f117c2db57eb5057ed852aafaba89f3f9db0a07fca84c8f0af70201068a430184c09419965591c5c2f3a381ace8973fb7c1861116291674cc9781d252b05b84a42d7456ac9d00b029acc763566a5b2f9f9793914d845c9f45d074fc1ce43276162f023441edf719c9890596ad9b27a29abddb6078e9dbd28c6eb7634c0e4f01718fd1c597e45a26a526558969d135bb576e3628005891d59c12bddb7de7742faf89f29e87a700bc6faa339bd5f700e18f1183cba7ed9f1ef8b960328fd81d3e7450e78ca7dd0fbe21e743f6ccfbe2bad94034e6d77b0158267da60435d1378fd95c05c3a6cdf7f3c2f05583e25b7666b1d3cb97105528978faf9eff1efcef6e50c957326e0e672bfbe7d0d36371c04dfaaeaf4f3d1be485e399433814fafeeff57e27028fdcc4a2561a8e775e1049cae0315ab6b60537d73fa7ee45397a886820938ad823afef51a5b7875b0f365de659c5715ec6839911ecfcd4ec3485f17b8dc1ea14c4155e0240458f781eadaf4fd70f4ad28c3d0854b50e60b943e04b8e12c9a8083b7b65d862fe1a730353a5458193a21505e59b5e87ecbbe23107d76972b112e7c297662031d2fa0b2663d589609e303bdf0b5e33924950529d7a558a7a641eca18c65cfc95f3f06e1e9cdab7967bd028e983653ba14138fe3787a2d95e1dc78f0a51e41e032a56331f0dc8e47e7529090c77252c0204c4ba75e0dcfe8f18a8a8a209edbfb26bce076bb174dd058eb81bd6bcb1c817d9834203a61a49b1bbccac3280f7390ba23c44ce9a44042b64bd434c8d64c930d2a9ff00d5eb39140f09ef104021da598db22d68c65b66609a9800c814c8c444673aa53cfd0c24974ae4402c1dfff4c22780b296b922fd79c5ab20a4ce56a28cd8a2480885e4ea2997f5d642912ca97e32e35275baf0c024bb6e7a0809be7f6050c39697befaca610f08bac65ac2932361755492078f7681cbb9e269238466ed09cb632a7f3cd885e94aac849e32e97ab999310c0e838e6e0cdd9c0975c17e83f2459d78f0c25b095f7c762b12efc236fb90f10e88c0a4eca16e5582e955057b11407aea77b4ca8bfa48063f05cf70295841ceb19fffd48e6028ef64f800100bb8da782513c5a160000000049454e44ae426082, '2012-09-10');
INSERT INTO `icon` VALUES(31, 2, 1, 0x89504e470d0a1a0a0000000d494844520000002000000025080600000023b7eb470000000467414d410000afc837058ae90000001974455874536f6674776172650041646f626520496d616765526561647971c9653c000005164944415478dab4586d6c1445187e6776afbdb65709411b3056d48814149ab3f5a3a289c646fb0f10a82226f567d160c468f4879f3ffc00911889ff04aa29052b20313142c0a0f1e312843425989820112c4a63a940bdb6b7bddd19df7776a6aedbebde5ed34ef26677ef6ee779e6793f66de63cdcdcd8083a159da12817bfa7c3a8644f3b4e503f7d2d620742d434b6a2bd304f83411101a700c2da78dee5d5b03116025da55fa5aae494de770d11cb411b421a38c2190d4e0d770ce33aeeb02630ca49480cfea4a469f918deb2a652462f0b7f97c1e1cc781542ad51450452990d0042af1854c4dd9c33037b5022aadf9d3bafc11ef1cf48f1d80d303dd99eaeaeaa5da0d0e0fb8a0dcf33c985b36fde034684e3577257958b958c5190f44bc4d92cd047890846dabd032ae57049889f6a0cf68dcbf8641fb260e8bee8a9f8de90718ac7b71f2e41142985b851d99668bef6430ef4606ab9f894762e9bd0c96b773e8f946c2ac390073e645072684f33c1cd56edebfda18a66b9e8d26b1641983954f73e87c4bc0f95f253cb5c5825b6e9ff8fb30068f6267f4a1772cf4d8aa0d1ceaee9838e96d4d0c56a14a5d9b055cfc13c1dfb5e0d82109992f25dcb7325ab948177cbb4f42de21623e8904c66deb460e0b1bff9bb4b21aa0e5490e7bdf1730784142fb660b8e1f91f0f51e012d6d1c1a1ee45327f0cb4f12f67e20203fe69310584c2ddb2761dc5153cba00cabc8a98c84879ee07002c18f74f9e08bf1371d6f78538f0143e2d3f7848a076ef94a504cb4624c2c6c60d07f562a8237dcca60cf1601877769f0bb19ec7cdd83cb03d13110abde9fee91f0194adcfa1c57b1407310197ade8d7e3fdc2954a69c3929e1ea6bf13b5cd6472f7b3034586216147347f7565f09e50ee12bb1ee250ec3433e20adf6d84109db5f1505c18b66411c125d9b04642ffbab1ccbf91bfda3a8c4ec1a0647bb05f47e27c7d337ce2879bf27993f7953a8d592022efa9fa3231f7b9ec3cdf5a59f5f22eb407854e186ddf60a57158e7cffcf25dc552afcef92557eb15a9066532710b5bf53be3f8e35fea6250c56ace790bd2261c76b1eecdf2660d73b0206cefb2428184b2111cb05152980b52f70b86e0103dcb1e1ab0e01c35740b9817c7ea6175375ab8755b0b812915950c805b47202bfbe8ea97cdf8785a9e7a884b058a400d58bc10bbe5b8844a1bda02417a466f9c1357f91bff2031f0af83933b99bfeea93181b1efcddef937864c3442522d330fce5f2f51adcf5c14f6564d1150dfc0198aa9e52a242c7c4940b9129389f23f8c9ef65ecc02212a4c445bc26ca8b9762a94fa8ea041c1c9d6f8b291fbf88c4b68d5e5410d2e49207ba14978ee3747a9da94173d3c157f7080a97073a1687ceed74749e0912e658ae157034a667eb5e8dcee8235555554d746eef4b7e018944e27f13d426dba0b6626d2cb0bed1ddf0fb68c7787343577318453737e9ee8830f3b6562067da25dd3498d68c99061527fc4111294282c0cf8dec24a065dae752f99af3706b96330a181798c0c8859a535bf70c8d48e278140902efcb7d4ce08d5a5957db64cda967b2c00d5c9d40b362089022492491c6d5f514221158791a1f474deb152250b03d8700b87bcfec838e99f4c74b2d2c4020a5a296f3fab3c33b7a832408fcb7ec76ea7aeab5c4596d8e9e5306e68c7f24a317f10537fcb965596924d1639ef19ec0d3c5c00b163bfd0f49b11156825af954369b3da1f68c54aa41830e05c1b5b29123ee9f10c645c12a9647e03afd4c0135ac15880d5e0a813009736f87fefd182b059cc6bf020c008d7843de3a7e1f650000000049454e44ae426082, '2012-09-10');

-- --------------------------------------------------------

--
-- Table structure for table `property`
--

CREATE TABLE `property` (
  `pid` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL,
  `beds` int(11) NOT NULL,
  `baths` int(11) NOT NULL,
  `area` varchar(20) NOT NULL,
  `price` varchar(20) NOT NULL,
  `icontype` varchar(10) NOT NULL,
  `iconvalue` varchar(10) NOT NULL,
  `location` varchar(200) NOT NULL,
  `street` varchar(200) NOT NULL,
  `city` varchar(100) NOT NULL,
  `country` varchar(100) NOT NULL,
  `zipcode` varchar(20) NOT NULL,
  `lan` varchar(30) NOT NULL,
  `lat` varchar(30) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY  (`pid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=182 ;

--
-- Dumping data for table `property`
--

INSERT INTO `property` VALUES(2, '13300 Doty Ave, Hawthorne, CA 90250, USA', 8, 1, '', '', '', '', '', '', '', '', '', '-118.339424', '33.911664', '0000-00-00');
INSERT INTO `property` VALUES(4, '8614 Saran Dr, Playa Del Rey, CA 90293, USA', 8, 7, '', '', '', '', '', '', '', '', '', '-118.4326173', '33.9595464', '0000-00-00');
INSERT INTO `property` VALUES(8, '13700 Marina Pointe Dr, Marina Del Rey, CA 90292, USA', 8, 0, '', '', '', '', '', '', '', '', '', '-118.44429', '33.984898', '0000-00-00');
INSERT INTO `property` VALUES(9, '949 Lakme Ave, Wilmington, CA 90744, USA', 8, 7, '', '', '', '', '', '', '', '', '', '-118.259961', '33.782836', '0000-00-00');
INSERT INTO `property` VALUES(10, 'Artesia Blvd & Canehill Ave, Bellflower, CA 90706, USA', 7, 14, '', '', '', '', '', '', '', '', '', '-118.1113749', '33.8729396', '0000-00-00');
INSERT INTO `property` VALUES(11, '949 Lakme Ave, Wilmington, CA 90744, USA', 8, 7, '', '', '', '', '', '', '', '', '', '-118.259961', '33.782836', '0000-00-00');
INSERT INTO `property` VALUES(13, '949 Lakme Ave, Wilmington, CA 90744, USA', 8, 7, '', '', '', '', '', '', '', '', '', '-118.259961', '33.782836', '0000-00-00');
INSERT INTO `property` VALUES(16, '26th St & Arizona Ave, Santa Monica, CA 90404, USA', 7, 1, '', '', '', '', '', '', '', '', '', '-118.4758751', '34.0346491', '0000-00-00');
INSERT INTO `property` VALUES(17, '2301 Roscomare Rd, Los Angeles, CA 90077, USA', 8, 12, '', '', '', '', '', '', '', '', '', '-118.464076', '34.115431', '0000-00-00');
INSERT INTO `property` VALUES(18, '1140 Molino Ave, Long Beach, CA 90804, USA', 8, 8, '', '', '', '', '', '', '', '', '', '-118.160816', '33.781609', '0000-00-00');
INSERT INTO `property` VALUES(19, '2, Signal Hill, CA 90755, USA', 6, 1, '', '', '', '', '', '', '', '', '', '-118.1832627', '33.8134812', '0000-00-00');
INSERT INTO `property` VALUES(20, '3155 Geneva St, Los Angeles, CA 90020, USA', 8, 7, '', '', '', '', '', '', '', '', '', '-118.286044', '34.0679329', '0000-00-00');
INSERT INTO `property` VALUES(21, '2124 Clark Ave, Long Beach, CA 90815, USA', 8, 8, '', '', '', '', '', '', '', '', '', '-118.133708', '33.794929', '0000-00-00');
INSERT INTO `property` VALUES(22, '11640 Mayfield Ave, Los Angeles, CA 90049, USA', 8, 4, '', '', '', '', '', '', '', '', '', '-118.462225', '34.052339', '0000-00-00');
INSERT INTO `property` VALUES(24, '647 N Hayworth Ave, Los Angeles, CA 90048, USA', 8, 1, '', '', '', '', '', '', '', '', '', '-118.3628226', '34.0830503', '0000-00-00');
INSERT INTO `property` VALUES(29, '11650 Bellagio Rd, Los Angeles, CA 90049, USA', 8, 5, '', '', '', '', '', '', '', '', '', '-118.467434', '34.076775', '0000-00-00');
INSERT INTO `property` VALUES(30, '1940 N Beverly Glen Blvd, Los Angeles, CA 90077, USA', 8, 12, '', '', '', '', '', '', '', '', '', '-118.4460969', '34.1056972', '0000-00-00');
INSERT INTO `property` VALUES(31, '17621 Pauline Ct, Canyon Country, CA 91387, USA', 8, 0, '', '', '', '', '', '', '', '', '', '-118.443257', '34.413091', '0000-00-00');
INSERT INTO `property` VALUES(34, '411 W 5th St, Los Angeles, CA 90013, USA', 8, 7, '', '', '', '', '', '', '', '', '', '-118.2517841', '34.0490223', '0000-00-00');
INSERT INTO `property` VALUES(37, 'Canoga Ave & Burbank Blvd, Los Angeles, CA 91367, USA', 7, 5, '', '', '', '', '', '', '', '', '', '-118.5973464', '34.173308', '0000-00-00');
INSERT INTO `property` VALUES(38, '20655 Vanowen St, Canoga Park, CA 91303, USA', 8, 16, '', '', '', '', '', '', '', '', '', '-118.6081036', '34.1937458', '0000-00-00');
INSERT INTO `property` VALUES(39, '25399 The Old Rd, Stevenson Ranch, CA 91381, USA', 8, 11, '', '', '', '', '', '', '', '', '', '-118.571749', '34.378207', '0000-00-00');
INSERT INTO `property` VALUES(40, '13300 Doty Ave, Hawthorne, CA 90250, USA', 8, 12, '', '', '', '', '', '', '', '', '', '-118.339424', '33.911664', '0000-00-00');
INSERT INTO `property` VALUES(41, '20655 Vanowen St, Canoga Park, CA 91303, USA', 8, 16, '', '', '', '', '', '', '', '', '', '-118.6081036', '34.1937458', '0000-00-00');
INSERT INTO `property` VALUES(42, '17020 Burbank Blvd, Encino, CA 91316, USA', 8, 16, '', '', '', '', '', '', '', '', '', '-118.503991', '34.171815', '0000-00-00');
INSERT INTO `property` VALUES(43, '17800 Colima Rd, Rowland Heights, CA 91748, USA', 8, 7, '', '', '', '', '', '', '', '', '', '-117.917402', '33.989419', '0000-00-00');
INSERT INTO `property` VALUES(44, '5127 Woodman Ave, Sherman Oaks, CA 91423, USA', 8, 16, '', '', '', '', '', '', '', '', '', '-118.431624', '34.163807', '0000-00-00');
INSERT INTO `property` VALUES(46, '4442 S Centinela Ave, Los Angeles, CA 90066, USA', 8, 8, '', '', '', '', '', '', '', '', '', '-118.4237702', '33.9936186', '0000-00-00');
INSERT INTO `property` VALUES(47, '21021 Vanowen St, Canoga Park, CA 91303, USA', 8, 5, '', '', '', '', '', '', '', '', '', '-118.591259', '34.194245', '0000-00-00');
INSERT INTO `property` VALUES(48, '13300 Doty Ave, Hawthorne, CA 90250, USA', 8, 1, '', '', '', '', '', '', '', '', '', '-118.339424', '33.911664', '0000-00-00');
INSERT INTO `property` VALUES(49, '10930 Palms Blvd, Los Angeles, CA 90034, USA', 8, 1, '', '', '', '', '', '', '', '', '', '-118.417428', '34.021287', '0000-00-00');
INSERT INTO `property` VALUES(52, 'Los Alimos St, Los Angeles, CA 91344, USA', 6, 1, '', '', '', '', '', '', '', '', '', '-118.4994676', '34.2656049', '0000-00-00');
INSERT INTO `property` VALUES(53, '125 S Sierra Madre Blvd, Pasadena, CA 91107, USA', 8, 7, '', '', '', '', '', '', '', '', '', '-118.1018065', '34.1435931', '0000-00-00');
INSERT INTO `property` VALUES(54, '5233 Monte Vista St, Los Angeles, CA 90042, USA', 8, 7, '', '', '', '', '', '', '', '', '', '-118.200157', '34.109274', '0000-00-00');
INSERT INTO `property` VALUES(55, '23825 Anza Ave, Torrance, CA 90505, USA', 8, 12, '', '', '', '', '', '', '', '', '', '-118.358893', '33.809627', '0000-00-00');
INSERT INTO `property` VALUES(56, '22893 Adrienne Ave, Moreno Valley, CA 92553, USA', 8, 1, '', '', '', '', '', '', '', '', '', '-117.263293', '33.917936', '0000-00-00');
INSERT INTO `property` VALUES(57, '1056 S Normandie Ave, Los Angeles, CA 90006, USA', 8, 7, '', '', '', '', '', '', '', '', '', '-118.2998898', '34.051073', '0000-00-00');
INSERT INTO `property` VALUES(58, '13300 Doty Ave, Hawthorne, CA 90250, USA', 8, 1, '', '', '', '', '', '', '', '', '', '-118.339424', '33.911664', '0000-00-00');
INSERT INTO `property` VALUES(59, 'Victory Blvd & Kester Ave, Los Angeles, CA 91411, USA', 7, 11, '', '', '', '', '', '', '', '', '', '-118.457448', '34.186656', '0000-00-00');
INSERT INTO `property` VALUES(61, '360 N Vista St, Los Angeles, CA 90036, USA', 8, 0, '', '', '', '', '', '', '', '', '', '-118.3520904', '34.0778595', '0000-00-00');
INSERT INTO `property` VALUES(62, '1231 S Bundy Dr, Los Angeles, CA 90025, USA', 8, 12, '', '', '', '', '', '', '', '', '', '-118.466834', '34.0431389', '0000-00-00');
INSERT INTO `property` VALUES(63, '8145 Langdon Ave, Van Nuys, CA 91406, USA', 8, 1, '', '', '', '', '', '', '', '', '', '-118.470127', '34.218832', '0000-00-00');
INSERT INTO `property` VALUES(64, '212 S Westlake Ave, Los Angeles, CA 90057, USA', 8, 1, '', '', '', '', '', '', '', '', '', '-118.2697366', '34.0643319', '0000-00-00');
INSERT INTO `property` VALUES(65, '8145 Langdon Ave, Van Nuys, CA 91406, USA', 8, 1, '', '', '', '', '', '', '', '', '', '-118.470127', '34.218832', '0000-00-00');
INSERT INTO `property` VALUES(67, 'E 15th St & N Newport Ave, Long Beach, CA 90804, USA', 7, 7, '', '', '', '', '', '', '', '', '', '-118.1513166', '33.7857749', '0000-00-00');
INSERT INTO `property` VALUES(68, '1056 S Normandie Ave, Los Angeles, CA 90006, USA', 8, 7, '', '', '', '', '', '', '', '', '', '-118.2998898', '34.051073', '0000-00-00');
INSERT INTO `property` VALUES(69, '133rd St, Edwards, CA 93523, USA', 6, 1, '', '', '', '', '', '', '', '', '', '-117.89469', '35.024596', '0000-00-00');
INSERT INTO `property` VALUES(71, '235 S Rampart Blvd, Los Angeles, CA 90057, USA', 8, 1, '', '', '', '', '', '', '', '', '', '-118.278369', '34.0677639', '0000-00-00');
INSERT INTO `property` VALUES(72, '530 E Arbor Vitae St, Inglewood, CA 90301, USA', 8, 1, '', '', '', '', '', '', '', '', '', '-118.347708', '33.952406', '0000-00-00');
INSERT INTO `property` VALUES(73, '4419 W 162nd St, Lawndale, CA 90260, USA', 8, 1, '', '', '', '', '', '', '', '', '', '-118.3534106', '33.8836568', '0000-00-00');
INSERT INTO `property` VALUES(75, '946 S Carondelet St, Los Angeles, CA 90006, USA', 8, 1, '', '', '', '', '', '', '', '', '', '-118.283708', '34.0540023', '0000-00-00');
INSERT INTO `property` VALUES(76, '13300 Doty Ave, Hawthorne, CA 90250, USA', 8, 1, '', '', '', '', '', '', '', '', '', '-118.339424', '33.911664', '0000-00-00');
INSERT INTO `property` VALUES(77, '8735 Imperial Hwy, Downey, CA 90242, USA', 8, 12, '', '', '', '', '', '', '', '', '', '-118.1398722', '33.9179508', '0000-00-00');
INSERT INTO `property` VALUES(78, '2150 State 1, Los Angeles, CA 90744, USA', 8, 1, '', '', '', '', '', '', '', '', '', '-118.2324678', '33.7916727', '0000-00-00');
INSERT INTO `property` VALUES(79, '824 S Myrtle Ave, Inglewood, CA 90301, USA', 8, 12, '', '', '', '', '', '', '', '', '', '-118.348047', '33.953121', '0000-00-00');
INSERT INTO `property` VALUES(86, '235 S Rampart Blvd, Los Angeles, CA 90057, USA', 8, 7, '', '', '', '', '', '', '', '', '', '-118.278369', '34.0677639', '0000-00-00');
INSERT INTO `property` VALUES(88, '446 Landfair Ave, Los Angeles, CA 90024, USA', 8, 1, '', '', '', '', '', '', '', '', '', '-118.4520724', '34.0693717', '0000-00-00');
INSERT INTO `property` VALUES(90, '1622 Ellsmere Ave, Los Angeles, CA 90019, USA', 8, 5, '', '', '', '', '', '', '', '', '', '-118.3618338', '34.0457145', '0000-00-00');
INSERT INTO `property` VALUES(94, '17800 Colima Rd, Industry, CA 91748, USA', 8, 0, '', '', '', '', '', '', '', '', '', '-117.9173725', '33.9900576', '0000-00-00');
INSERT INTO `property` VALUES(101, '234 E 219th St, Carson, CA 90745, USA', 8, 4, '', '', '', '', '', '', '', '', '', '-118.273029', '33.828965', '0000-00-00');
INSERT INTO `property` VALUES(102, '3050 E 5th St, Long Beach, CA 90814, USA', 8, 11, '', '', '', '', '', '', '', '', '', '-118.15559', '33.7723439', '0000-00-00');
INSERT INTO `property` VALUES(104, '531 Esplanade, Redondo Beach, CA 90277, USA', 8, 1, '', '', '', '', '', '', '', '', '', '-118.389606', '33.8351339', '0000-00-00');
INSERT INTO `property` VALUES(105, '14100 Chadron Ave, Hawthorne, CA 90250, USA', 8, 12, '', '', '', '', '', '', '', '', '', '-118.328091', '33.9033019', '0000-00-00');
INSERT INTO `property` VALUES(106, '1217 243rd St, Harbor City, CA 90710, USA', 8, 1, '', '', '', '', '', '', '', '', '', '-118.2978128', '33.804061', '0000-00-00');
INSERT INTO `property` VALUES(107, 'Potomac Ave & Roxanne Ave, Los Angeles, CA 90008, USA', 7, 8, '', '', '', '', '', '', '', '', '', '-118.34864', '34.014819', '0000-00-00');
INSERT INTO `property` VALUES(109, '3856 W 113th St, Inglewood, CA 90303, USA', 8, 8, '', '', '', '', '', '', '', '', '', '-118.341344', '33.931659', '0000-00-00');
INSERT INTO `property` VALUES(111, '101 N Normandie Ave, Los Angeles, CA 90004, USA', 8, 7, '', '', '', '', '', '', '', '', '', '-118.300778', '34.07392', '0000-00-00');
INSERT INTO `property` VALUES(112, '1054 W 164th St, Gardena, CA 90247, USA', 8, 11, '', '', '', '', '', '', '', '', '', '-118.2932959', '33.8822593', '0000-00-00');
INSERT INTO `property` VALUES(113, '820 Alpine St, Los Angeles, CA 90012, USA', 8, 1, '', '', '', '', '', '', '', '', '', '-118.244885', '34.063648', '0000-00-00');
INSERT INTO `property` VALUES(115, 'N Avon St, Burbank, CA, USA', 6, 13, '', '', '', '', '', '', '', '', '', '-118.3480923', '34.1802978', '0000-00-00');
INSERT INTO `property` VALUES(117, 'South, Glendora, CA 91740, USA', 6, 4, '', '', '', '', '', '', '', '', '', '-117.866411', '34.1086619', '0000-00-00');
INSERT INTO `property` VALUES(118, '1030 N Alvarado St, Los Angeles, CA 90026, USA', 8, 7, '', '', '', '', '', '', '', '', '', '-118.263278', '34.07712', '0000-00-00');
INSERT INTO `property` VALUES(119, '695 E 5th St, Azusa, CA 91702, USA', 8, 8, '', '', '', '', '', '', '', '', '', '-117.896848', '34.130096', '0000-00-00');
INSERT INTO `property` VALUES(120, '5710 S Crescent Park E, Los Angeles, CA 90094, USA', 8, 7, '', '', '', '', '', '', '', '', '', '-118.4284112', '33.9717396', '0000-00-00');
INSERT INTO `property` VALUES(121, '1030 N Alvarado St, Los Angeles, CA 90026, USA', 8, 7, '', '', '', '', '', '', '', '', '', '-118.263278', '34.07712', '0000-00-00');
INSERT INTO `property` VALUES(122, '1809 Termino Ave, Long Beach, CA 90815, USA', 8, 12, '', '', '', '', '', '', '', '', '', '-118.145885', '33.7900299', '0000-00-00');
INSERT INTO `property` VALUES(123, 'Kingman Ave, Buena Park, CA 90621, USA', 6, 1, '', '', '', '', '', '', '', '', '', '-118.0011818', '33.8734718', '0000-00-00');
INSERT INTO `property` VALUES(124, '4715 Vista Del Monte Ave, Sherman Oaks, CA 91403, USA', 8, 0, '', '', '', '', '', '', '', '', '', '-118.450167', '34.156363', '0000-00-00');
INSERT INTO `property` VALUES(125, '810 S Spring St, Los Angeles, CA 90014, USA', 8, 11, '', '', '', '', '', '', '', '', '', '-118.253591', '34.04276', '0000-00-00');
INSERT INTO `property` VALUES(126, '1030 N Alvarado St, Los Angeles, CA 90026, USA', 8, 7, '', '', '', '', '', '', '', '', '', '-118.263278', '34.07712', '0000-00-00');
INSERT INTO `property` VALUES(127, '12019 Sycamore St, Norwalk, CA 90650, USA', 8, 1, '', '', '', '', '', '', '', '', '', '-118.07728', '33.90429', '0000-00-00');
INSERT INTO `property` VALUES(130, '3629 W 110th St, Inglewood, CA 90303, USA', 8, 0, '', '', '', '', '', '', '', '', '', '-118.335947', '33.936069', '0000-00-00');
INSERT INTO `property` VALUES(132, '1221 W 3rd St, Los Angeles, CA 90017, USA', 8, 12, '', '', '', '', '', '', '', '', '', '-118.2587235', '34.0571894', '0000-00-00');
INSERT INTO `property` VALUES(133, '505 Gayley Ave, UCLA, Los Angeles, CA 90024, USA', 8, 15, '', '', '', '', '', '', '', '', '', '-118.451304', '34.069619', '0000-00-00');
INSERT INTO `property` VALUES(134, '10216 Felton Ave, Inglewood, CA 90304, USA', 8, 1, '', '', '', '', '', '', '', '', '', '-118.365097', '33.942994', '0000-00-00');
INSERT INTO `property` VALUES(135, '9128 Burke St, Pico Rivera, CA 90660, USA', 8, 7, '', '', '', '', '', '', '', '', '', '-118.102705', '33.9690686', '0000-00-00');
INSERT INTO `property` VALUES(136, 'Downey Ave & Gardendale St, Downey, CA 90242, USA', 7, 1, '', '', '', '', '', '', '', '', '', '-118.1517203', '33.9148944', '0000-00-00');
INSERT INTO `property` VALUES(137, 'W Olympic Blvd & S Orange Grove Ave, Los Angeles, CA 90036, USA', 7, 8, '', '', '', '', '', '', '', '', '', '-118.3628684', '34.0580293', '0000-00-00');
INSERT INTO `property` VALUES(139, '14800 Chadron Ave, Gardena, CA 90249, USA', 8, 12, '', '', '', '', '', '', '', '', '', '-118.32809', '33.897197', '0000-00-00');
INSERT INTO `property` VALUES(140, '21038 Community St, Canoga Park, CA 91304, USA', 8, 0, '', '', '', '', '', '', '', '', '', '-118.592032', '34.221896', '0000-00-00');
INSERT INTO `property` VALUES(142, '1252 W 107th St, Los Angeles, CA 90044, USA', 8, 12, '', '', '', '', '', '', '', '', '', '-118.298125', '33.938476', '0000-00-00');
INSERT INTO `property` VALUES(144, '1 E Ave K, Lancaster, CA 93535, USA', 8, 0, '', '', '', '', '', '', '', '', '', '-118.1300753', '34.6749832', '0000-00-00');
INSERT INTO `property` VALUES(148, '600 S Spring St, Los Angeles, CA 90014, USA', 8, 7, '', '', '', '', '', '', '', '', '', '-118.250881', '34.045516', '0000-00-00');
INSERT INTO `property` VALUES(149, '13608 Kornblum Ave, Hawthorne, CA 90250, USA', 8, 12, '', '', '', '', '', '', '', '', '', '-118.336746', '33.907795', '0000-00-00');
INSERT INTO `property` VALUES(150, '600 S Spring St, Los Angeles, CA 90014, USA', 8, 7, '', '', '', '', '', '', '', '', '', '-118.250881', '34.045516', '0000-00-00');
INSERT INTO `property` VALUES(151, '215 W 6th St, Los Angeles, CA 90013, USA', 8, 11, '', '', '', '', '', '', '', '', '', '-118.251386', '34.0463', '0000-00-00');
INSERT INTO `property` VALUES(153, '550 N Figueroa St, Los Angeles, CA 90012, USA', 8, 0, '', '', '', '', '', '', '', '', '', '-118.246353', '34.060961', '0000-00-00');
INSERT INTO `property` VALUES(155, '740 W 214th St, Torrance, CA 90502, USA', 8, 5, '', '', '', '', '', '', '', '', '', '-118.2885597', '33.8343108', '0000-00-00');
INSERT INTO `property` VALUES(157, 'Loynes Dr & Bixby Village Dr, Long Beach, CA 90803, USA', 7, 7, '', '', '', '', '', '', '', '', '', '-118.1137658', '33.7682237', '0000-00-00');
INSERT INTO `property` VALUES(158, '215 W 6th St, Los Angeles, CA 90013, USA', 8, 4, '', '', '', '', '', '', '', '', '', '-118.251386', '34.0463', '0000-00-00');
INSERT INTO `property` VALUES(159, '3801 E Pacific Coast Hwy, Long Beach, CA 90804, USA', 8, 0, '', '', '', '', '', '', '', '', '', '-118.1478026', '33.790098', '0000-00-00');
INSERT INTO `property` VALUES(160, '23645 Meadowridge Dr, Newhall, CA 91321, USA', 8, 0, '', '', '', '', '', '', '', '', '', '-118.5118189', '34.3687644', '0000-00-00');
INSERT INTO `property` VALUES(162, '13637 Cordary Ave, Hawthorne, CA 90250, USA', 8, 12, '', '', '', '', '', '', '', '', '', '-118.3418093', '33.9072812', '0000-00-00');
INSERT INTO `property` VALUES(163, 'Curtis and King Rd, Norwalk, CA 90650, USA', 7, 16, '', '', '', '', '', '', '', '', '', '-118.107959', '33.9188119', '0000-00-00');
INSERT INTO `property` VALUES(164, '3080 Sedona St, Rosamond, CA 93560, USA', 8, 0, '', '', '', '', '', '', '', '', '', '-118.20783', '34.866023', '0000-00-00');
INSERT INTO `property` VALUES(165, '5659 W 8th St, Los Angeles, CA 90036, USA', 8, 0, '', '', '', '', '', '', '', '', '', '-118.352645', '34.060916', '0000-00-00');
INSERT INTO `property` VALUES(168, 'Usc McCarthy Way, The University of Southern California, Los Angeles, CA 90007, USA', 6, 15, '', '', '', '', '', '', '', '', '', '-118.2809825', '34.0204524', '0000-00-00');
INSERT INTO `property` VALUES(170, '1317 N Bronson Ave, Los Angeles, CA 90028, USA', 8, 8, '', '', '', '', '', '', '', '', '', '-118.318294', '34.094977', '0000-00-00');
INSERT INTO `property` VALUES(171, 'Wilmington Historical Society, 309 W Opp St, Wilmington, CA 90744, USA', 9, 15, '', '', '', '', '', '', '', '', '', '-118.26552', '33.7828155', '0000-00-00');
INSERT INTO `property` VALUES(172, '2664 Lacy St, Los Angeles, CA 90031, USA', 8, 7, '', '', '', '', '', '', '', '', '', '-118.2187266', '34.0831208', '0000-00-00');
INSERT INTO `property` VALUES(176, '505 Gayley Ave, UCLA, Los Angeles, CA 90024, USA', 8, 8, '', '', '', '', '', '', '', '', '', '-118.451304', '34.069619', '0000-00-00');
INSERT INTO `property` VALUES(177, 'Hollywood Blvd & Cosmo St, Los Angeles, CA 90028, USA', 7, 14, '', '', '', '', '', '', '', '', '', '-118.3288067', '34.1016065', '0000-00-00');
INSERT INTO `property` VALUES(178, '1521 S Hayworth Ave, Los Angeles, CA 90035, USA', 8, 12, '', '', '', '', '', '', '', '', '', '-118.3681561', '34.0492507', '0000-00-00');
INSERT INTO `property` VALUES(179, '1241 S Greenwood Ave, Montebello, CA 90640, USA', 8, 0, '', '', '', '', '', '', '', '', '', '-118.123303', '33.989917', '0000-00-00');
INSERT INTO `property` VALUES(181, '160 S Virgil Ave, Los Angeles, CA 90004, USA', 8, 7, '', '', '', '', '', '', '', '', '', '-118.2867639', '34.0718576', '0000-00-00');
